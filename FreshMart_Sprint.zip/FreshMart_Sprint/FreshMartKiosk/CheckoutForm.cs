using System;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FreshMartKiosk.CustomerAuth;

namespace FreshMartKiosk
{
    /// <summary>
    /// Review & Pay screen. Opened with ShowDialog() by FormKiosk and reports back through DialogResult:
    ///   OK     = payment completed
    ///   Abort  = customer cancelled the whole transaction
    ///   Cancel = Back button / window closed (keep shopping)
    /// </summary>
    public partial class CheckoutForm : Form
    {
        private const string ReceiptHint = "email@example.com or +27 00 000 0000";

        private readonly ShoppingCart cart;
        private bool cardAdded;
        private string cardLastFour;
        private TransactionRecord completedTransaction;
        private string completedContact;
        private string receiptPdfPath;
        private bool emailSent;
        private bool smsSent;
        private int smsPartsSent;

        public CheckoutForm(ShoppingCart cart)
        {
            InitializeComponent();
            this.cart = cart;
            FormClosing += CheckoutForm_FormClosing;

            lblDateTime.Text = DateTime.Now.ToString("dddd, MMMM d, yyyy • h:mm tt");

            // Clicking anything inside the payment box (not only its empty background) opens "Add card".
            foreach (Control child in paymentPanel.Controls)
            {
                child.Click += paymentPanel_Click;
                child.Cursor = Cursors.Hand;
            }
            paymentPanel.Cursor = Cursors.Hand;

            // The receipt box shows a grey hint that disappears when the customer taps it.
            txtReceiptContact.Text = ReceiptHint;
            txtReceiptContact.ForeColor = Color.Silver;
            txtReceiptContact.Enter += (s, e) =>
            {
                if (txtReceiptContact.Text == ReceiptHint) { txtReceiptContact.Text = ""; txtReceiptContact.ForeColor = Color.White; }
            };
            txtReceiptContact.Leave += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtReceiptContact.Text)) { txtReceiptContact.Text = ReceiptHint; txtReceiptContact.ForeColor = Color.Silver; }
            };

            RenderOrderSummary();
        }

        private void RenderOrderSummary()
        {
            itemsFlow.Controls.Clear();

            foreach (CartItem item in cart.Items)
            {
                var row = new Panel { Width = 389, Height = 44, Margin = new Padding(0, 0, 0, 6) };

                row.Controls.Add(new Label
                {
                    Text = item.Product.ProductName,
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold),
                    AutoSize = true,
                    Location = new Point(0, 0)
                });
                row.Controls.Add(new Label
                {
                    Text = $"×{item.Quantity} @ R {item.Product.Price:0.00}",
                    ForeColor = Color.Silver,
                    Font = new Font("Segoe UI", 8.5F),
                    AutoSize = true,
                    Location = new Point(0, 20)
                });
                row.Controls.Add(new Label
                {
                    Text = $"R {item.TotalPrice:0.00}",
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold),
                    Size = new Size(97, 20),
                    Location = new Point(292, 0),
                    TextAlign = ContentAlignment.MiddleRight
                });

                itemsFlow.Controls.Add(row);
            }

            lblSubtotalValue.Text = $"R {cart.CalculateSubtotal():0.00}";
            lblTaxValue.Text = $"R {cart.CalculateVat():0.00}";
            lblTotalValue.Text = $"R {cart.CalculateTotal():0.00}";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;   // back to shopping, cart kept
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show(this, "Cancel this transaction?", "Cancel Transaction",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                cart.ClearCart();
                DialogResult = DialogResult.Abort;
                Close();
            }
        }

        private async void btnPrintReceipt_Click(object sender, EventArgs e)
        {
            if (completedTransaction == null)
            {
                MessageBox.Show(this, "Complete payment before creating and sending the final receipt.", "Receipt",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            btnPrintReceipt.Enabled = false;
            try
            {
                if (receiptPdfPath == null)
                {
                    receiptPdfPath = ReceiptOutputService.SaveAsPdf(this, BuildReceiptText(completedTransaction), completedTransaction.Number);
                    if (receiptPdfPath == null) return;
                }

                string deliveryStatus;
                if (string.IsNullOrWhiteSpace(completedContact))
                {
                    deliveryStatus = "No email or phone number was provided, so no message was sent.";
                }
                else if (completedContact.Contains("@"))
                {
                    if (!emailSent)
                    {
                        await ReceiptOutputService.SendEmailAsync(completedContact, completedTransaction.Number,
                            BuildReceiptText(completedTransaction), receiptPdfPath);
                        emailSent = true;
                    }
                    deliveryStatus = "Email sent to " + completedContact + ".";
                }
                else
                {
                    if (!smsSent)
                    {
                        int smsPartCount = await ReceiptOutputService.SendSmsAsync(completedContact,
                            BuildReceiptText(completedTransaction), smsPartsSent, sentParts => smsPartsSent = sentParts);
                        smsSent = true;
                        smsPartsSent = smsPartCount;
                    }
                    deliveryStatus = "SMS sent to " + completedContact + ".";
                }

                MessageBox.Show(this,
                    BuildReceiptText(completedTransaction) + "\nPDF saved to:\n" + receiptPdfPath + "\n\n" + deliveryStatus,
                    "Receipt", MessageBoxButtons.OK, MessageBoxIcon.Information);

                cart.ClearCart();
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                string pdfStatus = receiptPdfPath == null ? "The PDF has not been saved." : "PDF saved to:\n" + receiptPdfPath;
                MessageBox.Show(this, pdfStatus + "\n\nReceipt delivery failed:\n" + ex.Message +
                    "\n\nCorrect the delivery settings and retry.", "Receipt Not Completed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (!IsDisposed) btnPrintReceipt.Enabled = true;
            }
        }

        private void btnCompleteTransaction_Click(object sender, EventArgs e)
        {
            if (completedTransaction != null) return;

            if (!cardAdded)
            {
                MessageBox.Show(this, "Please add a card before completing the transaction.", "Payment Required",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string contact = ReceiptContact();
            if (contact == null)
                contact = CustomerSession.CurrentCustomer?.Email;
            if (contact != null && !IsValidContact(contact))
            {
                MessageBox.Show(this, "Please enter a valid email address or phone number for the receipt,\nor leave the box empty.",
                    "Receipt", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtReceiptContact.Focus();
                return;
            }

            TransactionRecord record;
            try
            {
                // Stock, sale and line items are saved together in one database transaction.
                record = DataStore.CompleteSale(cart, contact);
            }
            catch (SaleFailedException ex)
            {
                MessageBox.Show(this, ex.Message, "Item Unavailable", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "The payment could not be recorded, so nothing was charged:\n" + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            completedTransaction = record;
            completedContact = contact;
            btnCompleteTransaction.Enabled = false;
            btnBack.Enabled = false;
            btnCancel.Enabled = false;
            txtReceiptContact.Enabled = false;
            btnPrintReceipt.Text = "Save PDF & Send Receipt";
            MessageBox.Show(this,
                "Payment approved and the sale has been recorded. Click Save PDF & Send Receipt to create the PDF and deliver the receipt.",
                "Payment Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>What the customer typed in the receipt box, or null if they left it empty.</summary>
        private string ReceiptContact()
        {
            string text = txtReceiptContact.Text.Trim();
            return (text.Length == 0 || text == ReceiptHint) ? null : text;
        }

        /// <summary>Accepts an email address, or a phone number of 10-12 digits (spaces, + and - allowed).</summary>
        private static bool IsValidContact(string text)
        {
            if (text.Contains("@"))
                return System.Text.RegularExpressions.Regex.IsMatch(text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");

            string digits = new string(text.Where(char.IsDigit).ToArray());
            bool onlyPhoneCharacters = text.All(c => char.IsDigit(c) || c == ' ' || c == '+' || c == '-');
            return onlyPhoneCharacters && digits.Length >= 10 && digits.Length <= 12;
        }

        private string BuildReceiptText(TransactionRecord record)
        {
            var sb = new StringBuilder();
            sb.AppendLine("FreshMart Supermarket");
            sb.AppendLine("Receipt: " + record.Number);
            sb.AppendLine("Date: " + record.Date.ToString("yyyy-MM-dd HH:mm:ss"));
            sb.AppendLine();

            CustomerAccount customer = CustomerSession.CurrentCustomer;
            sb.AppendLine("Customer: " + (customer?.FullName ?? "Guest"));
            sb.AppendLine("Username: " + (customer?.Username ?? "Guest"));
            sb.AppendLine("Customer email: " + (customer?.Email ?? "Not provided"));
            sb.AppendLine("Receipt contact: " + (completedContact ?? "Not provided"));
            sb.AppendLine("Payment: Bank card ending in " + (cardLastFour ?? "----"));
            sb.AppendLine();
            sb.AppendLine("Items:");

            foreach (CartItem item in cart.Items)
            {
                sb.AppendLine(item.Product.ProductId + " | " + item.Product.ProductName);
                sb.AppendLine("  Category: " + item.Product.Category + " | Barcode: " + item.Product.Barcode);
                sb.AppendLine($"  Quantity: {item.Quantity} x R {item.Product.Price:0.00} = R {item.TotalPrice:0.00}");
            }

            sb.AppendLine();
            sb.AppendLine($"Items: {record.ItemCount}");
            sb.AppendLine($"Subtotal:   R {record.Subtotal:0.00}");
            sb.AppendLine($"VAT (15%):  R {record.Vat:0.00}");
            sb.AppendLine($"TOTAL:      R {record.Total:0.00}");
            return sb.ToString();
        }

        private void CheckoutForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (completedTransaction == null || DialogResult == DialogResult.OK) return;

            DialogResult answer = MessageBox.Show(this,
                "Payment is already recorded, but the receipt has not been completed. Close checkout without finishing receipt delivery?",
                "Receipt Not Completed", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (answer != DialogResult.Yes)
            {
                e.Cancel = true;
                return;
            }

            cart.ClearCart();
            DialogResult = DialogResult.OK;
        }

        private void paymentPanel_Click(object sender, EventArgs e)
        {
            using (var addCard = new AddCardForm())
            {
                if (addCard.ShowDialog(this) != DialogResult.OK) return;

                string lastFour = addCard.CardNumber.Substring(addCard.CardNumber.Length - 4);
                cardLastFour = lastFour;
                lblCardInfo.Text = "Card ending in " + lastFour + "\nExpires " + addCard.ExpiryDate;
                cardAdded = true;
            }
        }

        // Empty handlers kept because the designer file is wired to them.
        private void lblDate_Click(object sender, EventArgs e) { }
        private void paymentPanel_Paint(object sender, PaintEventArgs e) { }
        private void lblReceiptSub_Click(object sender, EventArgs e) { }
        private void lblPaymentSub_Click(object sender, EventArgs e) { }
    }
}
