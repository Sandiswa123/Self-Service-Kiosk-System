using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using FreshMartKiosk;

namespace Admin
{
    /// <summary>
    /// Admin dashboard. Opened with ShowDialog() from the welcome screen after a successful login.
    /// Closing this form (Exit Admin / Return to Kiosk / Open System) returns to the welcome screen.
    ///
    /// The product rows are built in code from the SAME catalog the kiosk uses
    /// (DataStore.LoadCatalog), so codes, names and prices always match.
    /// </summary>
    public partial class frmAdmin : Form
    {
        private static readonly Color RowColor = Color.FromArgb(29, 46, 70);
        private static readonly Color RowColorOff = Color.FromArgb(28, 22, 40);
        private static readonly Color MenuOn = Color.FromArgb(0, 180, 100);
        private static readonly Color MenuOff = Color.FromArgb(35, 53, 80);

        private List<FreshMartKiosk.Product> products = new List<FreshMartKiosk.Product>();
        private readonly DateTime startTime = DateTime.Now;
        private bool buildingRows;

        public frmAdmin()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;

            // System Control icons (kept as files in Images\Admin, not in the .resx).
            picExit.Image = AppImages.Load("Admin", "exit.png");
            picRestart.Image = AppImages.Load("Admin", "restart.png");
            pictureBox4.Image = AppImages.Load("Admin", "shutdown.png");

            // Leftovers from the designer that shouldn't be visible.
            lblProduct.Visible = false;        // stray "PRODUCT" heading on the System Control panel
            pnlSystemCtrl.Visible = false;     // empty duplicate panel

            flpProducts.Resize += (s, e) => FitRowsToList();

            ReloadData();
            ShowStockManagement();
            timerClock_Tick(this, EventArgs.Empty);
        }

        /// <summary>Loads everything from disk again (also used by "Restart System").</summary>
        private void ReloadData()
        {
            products = DataStore.LoadCatalog();
            BuildProductRows();
            UpdateProductSummary();
            LoadTransactionSummary();
        }

        // ------------------------------------------------------------------
        // Stock management rows
        // ------------------------------------------------------------------

        private void BuildProductRows()
        {
            buildingRows = true;
            flpProducts.SuspendLayout();

            foreach (Control old in flpProducts.Controls.Cast<Control>().ToList())
                old.Dispose();
            flpProducts.Controls.Clear();

            foreach (FreshMartKiosk.Product product in products)
                flpProducts.Controls.Add(CreateProductRow(product));

            flpProducts.ResumeLayout();
            buildingRows = false;
        }

        /// <summary>One row: picture | name + category | code | stock | price | availability button.</summary>
        private Panel CreateProductRow(FreshMartKiosk.Product product)
        {
            // Tag links every control back to its product, so no label-name searching is needed.
            // Column x-positions come from the real heading labels, so rows stay aligned
            // even when Windows scales the designer controls (125%/150% display settings).
            int ColumnX(Control heading) => heading.Left - flpProducts.Left - 5;

            var row = new Panel
            {
                Size = new Size(Math.Max(ColumnX(this.lblStatus) + 200, flpProducts.ClientSize.Width - SystemInformation.VerticalScrollBarWidth - 12), 80),
                Margin = new Padding(5),
                BackColor = RowColor,
                Tag = product
            };

            var pic = new PictureBox
            {
                Location = new Point(15, 12),
                Size = new Size(55, 55),
                SizeMode = PictureBoxSizeMode.Zoom,
                Image = LoadProductImage(product.ProductId)
            };

            var lblName = new Label
            {
                Text = product.ProductName,
                Location = new Point(79, 28),
                AutoSize = true,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10.2F, FontStyle.Bold)
            };

            var lblCategory = new Label
            {
                Text = product.Category,
                Location = new Point(79, 51),
                AutoSize = true,
                ForeColor = Color.LightSteelBlue,
                Font = new Font("Segoe UI", 9F)
            };

            var lblCode = new Label
            {
                Text = product.ProductId,
                Location = new Point(ColumnX(this.lblCode), 30),
                AutoSize = true,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10.2F)
            };

            var numStock = new NumericUpDown
            {
                Location = new Point(ColumnX(this.lblStock), 29),
                Size = new Size(60, 22),
                Minimum = 0,
                Maximum = 1000,
                Value = Math.Min(1000, product.Stock),
                TextAlign = HorizontalAlignment.Center,
                Tag = product
            };
            numStock.ValueChanged += Stock_ValueChanged;

            var lblPrice = new Label
            {
                Text = "R" + product.Price.ToString("0.00"),
                Location = new Point(ColumnX(this.lblPrice), 28),
                AutoSize = true,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10.2F, FontStyle.Bold)
            };

            var btnAvailability = new Button
            {
                Location = new Point(ColumnX(this.lblStatus) - 20, 22),
                Size = new Size(120, 35),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand,
                Tag = product
            };
            btnAvailability.FlatAppearance.BorderSize = 0;
            btnAvailability.Click += AvailabilityButton_Click;

            row.Controls.AddRange(new Control[] { pic, lblName, lblCategory, lblCode, numStock, lblPrice, btnAvailability });
            ApplyAvailabilityStyle(row, numStock, btnAvailability, product.IsAvailable);
            return row;
        }

        /// <summary>Keeps rows as wide as the list, so there is no sideways scrollbar.</summary>
        private void FitRowsToList()
        {
            int width = Math.Max(this.lblStatus.Left - flpProducts.Left + 200,
                                 flpProducts.ClientSize.Width - SystemInformation.VerticalScrollBarWidth - 12);
            foreach (Control row in flpProducts.Controls)
                row.Width = width;
        }

        private static Image LoadProductImage(string productId)
        {
            string path = Path.Combine(Application.StartupPath, "Images", productId + ".jpg");
            if (!File.Exists(path)) return null;

            try
            {
                using (var fromDisk = new Bitmap(path))
                    return new Bitmap(fromDisk, new Size(110, 110));   // small copy = less memory
            }
            catch (ArgumentException) { return null; }
        }

        private static void ApplyAvailabilityStyle(Panel row, NumericUpDown stock, Button button, bool available)
        {
            if (available)
            {
                button.Text = "✓ Available";
                button.BackColor = Color.Green;
                button.ForeColor = Color.White;
                row.BackColor = RowColor;
                stock.Enabled = true;
            }
            else
            {
                button.Text = "✕ Unavailable";
                button.BackColor = Color.FromArgb(90, 25, 35);
                button.ForeColor = Color.FromArgb(255, 80, 90);
                row.BackColor = RowColorOff;
                stock.Enabled = false;
            }
        }

        private void AvailabilityButton_Click(object sender, EventArgs e)
        {
            var button = (Button)sender;
            var product = (FreshMartKiosk.Product)button.Tag;
            var row = (Panel)button.Parent;
            NumericUpDown stock = row.Controls.OfType<NumericUpDown>().First();

            product.IsAvailable = !product.IsAvailable;

            // If staff switch a product back on while its stock is 0, give it 1 so it can be sold.
            if (product.IsAvailable && product.Stock == 0)
                stock.Value = 1;   // triggers Stock_ValueChanged, which saves

            ApplyAvailabilityStyle(row, stock, button, product.IsAvailable);
            SaveProduct(product);
            UpdateProductSummary();
        }

        private void Stock_ValueChanged(object sender, EventArgs e)
        {
            if (buildingRows) return;

            var numStock = (NumericUpDown)sender;
            var product = (FreshMartKiosk.Product)numStock.Tag;
            product.Stock = (int)numStock.Value;

            SaveProduct(product);
            UpdateProductSummary();
        }

        /// <summary>Writes this product's stock and availability to the database straight away.</summary>
        private void SaveProduct(FreshMartKiosk.Product product)
        {
            try
            {
                DataStore.UpdateProduct(product);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not save the change to the database:\n" + ex.Message, "Save Failed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateProductSummary()
        {
            lblProductValue.Text = products.Count.ToString();
            lblOutStockValue.Text = products.Count(p => !p.CanBeSold).ToString();
        }

        private void LoadTransactionSummary()
        {
            List<TransactionRecord> transactions = DataStore.LoadTransactions();
            lblTransactionValue.Text = transactions.Count.ToString();
            lblRevenueValue.Text = "R " + transactions.Sum(t => t.Total).ToString("0.00");
        }

        // ------------------------------------------------------------------
        // Menu
        // ------------------------------------------------------------------

        private void ShowStockManagement()
        {
            btnStockMangement.BackColor = MenuOn;
            btnAnalytics.BackColor = MenuOff;
            btnSystemControl.BackColor = MenuOff;

            pnlSystemControl.Visible = false;

            flpProducts.Visible = true;
            flpProducts.BringToFront();
            SetStockHeadingsVisible(true);
        }

        private void ShowSystemControl()
        {
            btnSystemControl.BackColor = MenuOn;
            btnStockMangement.BackColor = MenuOff;
            btnAnalytics.BackColor = MenuOff;

            flpProducts.Visible = false;
            SetStockHeadingsVisible(false);

            pnlSystemControl.Visible = true;
            pnlSystemControl.BringToFront();
        }

        /// <summary>
        /// FIX: the old code hid lblProduct/lblProductCode (a row label!) here instead of
        /// the real column headings, so the P010 code vanished after visiting System Control.
        /// </summary>
        private void SetStockHeadingsVisible(bool visible)
        {
            lblProductitem.Visible = visible;
            lblCode.Visible = visible;
            lblStock.Visible = visible;
            lblPrice.Visible = visible;
            lblStatus.Visible = visible;
            pnlHeaderLine.Visible = visible;
        }

        private void btnStockMangement_Click(object sender, EventArgs e) => ShowStockManagement();

        private void btnSystemControl_Click(object sender, EventArgs e) => ShowSystemControl();

        private void btnAnalytics_Click(object sender, EventArgs e)
        {
            btnAnalytics.BackColor = MenuOn;

            using (var analytics = new frmAnalytics())
            {
                analytics.ShowDialog(this);
            }

            // Back on the dashboard: refresh numbers and restore the menu colour.
            LoadTransactionSummary();
            if (flpProducts.Visible) ShowStockManagement(); else ShowSystemControl();
        }

        private void btnRestartSystem_Click(object sender, EventArgs e)
        {
            using (var restart = new frmRestart())
            {
                restart.ShowDialog(this);
            }

            // "Restart" = reload everything from disk.
            ReloadData();
            ShowStockManagement();
        }

        private void btnShutdownSystem_Click(object sender, EventArgs e)
        {
            using (var shutdown = new frmShutdown())
            {
                shutdown.ShowDialog(this);
            }

            // "Open System" on the shutdown screen brings the kiosk back to the welcome screen.
            Close();
        }

        private void btnExitAdmin_Click(object sender, EventArgs e) => Close();

        private void btnReturnKiosk_Click(object sender, EventArgs e) => Close();

        private void timerClock_Tick(object sender, EventArgs e)
        {
            lblCurrentTime.Text = DateTime.Now.ToString("hh:mm:ss tt");

            TimeSpan uptime = DateTime.Now - startTime;
            lblUptime.Text = (int)uptime.TotalHours + "h " + uptime.Minutes.ToString("00") + "m";
        }

        private void pnlSystemControl_Paint(object sender, PaintEventArgs e) { }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            timerClock.Stop();
            base.OnFormClosed(e);
        }
    }
}
