using System;
using System.Windows.Forms;

namespace FreshmartAdminLogIn
{
    /// <summary>
    /// Admin login. Opened with ShowDialog() from the welcome screen.
    /// Returns DialogResult.OK only when the username and password are correct.
    /// </summary>
    public partial class frmFreshmartAdminLogin : Form
    {
        private readonly System.Drawing.Color _textLight = System.Drawing.Color.White;
        private readonly System.Drawing.Color _textGray = System.Drawing.Color.FromArgb(148, 163, 184);

        private const string UserNamePlaceholder = "Username";
        private const string PasswordPlaceholder = "Password";
        private bool _userNameShowingPlaceholder = true;
        private bool _passwordShowingPlaceholder = true;

        private const int MaxAttempts = 5;
        private int _failedAttempts;

        public frmFreshmartAdminLogin()
        {
            InitializeComponent();

            AcceptButton = btnLogin;          // Enter key logs in
            ActiveControl = btnLogin;         // so the placeholders stay visible
            lblForgotPassword.Text = "Change password? ";
            lblReset.Text = "Change now";

            // The new wording is longer than the old "Forgot password? Reset now",
            // so size both labels to their text and right-align them with the password box.
            int rightEdge = txtPassword.Right;   // line up with the password box
            lblForgotPassword.AutoSize = true;
            lblReset.AutoSize = true;
            lblReset.Left = rightEdge - lblReset.Width;
            lblForgotPassword.Left = lblReset.Left - lblForgotPassword.Width;
            lblForgotPassword.Top = lblReset.Top;

            // "Remember me" was never implemented; hide it rather than show a box that does nothing.
            chkRememberMe.Visible = false;
        }

        private void UserNameBox_Enter(object sender, EventArgs e)
        {
            if (_userNameShowingPlaceholder)
            {
                txtUserName.Text = string.Empty;
                txtUserName.ForeColor = _textLight;
                _userNameShowingPlaceholder = false;
            }
        }

        private void UserNameBox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUserName.Text))
            {
                _userNameShowingPlaceholder = true;
                txtUserName.Text = UserNamePlaceholder;
                txtUserName.ForeColor = _textGray;
            }
        }

        private void PasswordBox_Enter(object sender, EventArgs e)
        {
            if (_passwordShowingPlaceholder)
            {
                txtPassword.Text = string.Empty;
                txtPassword.ForeColor = _textLight;
                txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;
                _passwordShowingPlaceholder = false;
            }
        }

        private void PasswordBox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                _passwordShowingPlaceholder = true;
                txtPassword.UseSystemPasswordChar = false;
                txtPassword.Text = PasswordPlaceholder;
                txtPassword.ForeColor = _textGray;
            }
        }

        private void ResetLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            using (var resetForm = new frmResetPassword())
            {
                resetForm.ShowDialog(this);
            }
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            string userName = _userNameShowingPlaceholder ? string.Empty : txtUserName.Text.Trim();
            string password = _passwordShowingPlaceholder ? string.Empty : txtPassword.Text;

            if (userName.Length == 0 && password.Length == 0)
            {
                MessageBox.Show(this, "Please enter your username and password.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUserName.Focus();
                return;
            }
            if (userName.Length == 0)
            {
                MessageBox.Show(this, "Please enter your username.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUserName.Focus();
                return;
            }
            if (password.Length == 0)
            {
                MessageBox.Show(this, "Please enter your password.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPassword.Focus();
                return;
            }

            bool isValid;
            try
            {
                isValid = DatabaseHelper.CheckLogin(userName, password);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not read the login database:\n" + ex.Message, "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!isValid)
            {
                _failedAttempts++;
                if (_failedAttempts >= MaxAttempts)
                {
                    MessageBox.Show(this, "Too many failed attempts. Returning to the kiosk.", "Login Locked", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    DialogResult = DialogResult.Cancel;
                    Close();
                    return;
                }

                MessageBox.Show(this, "Incorrect username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Clear();
                txtPassword.Focus();
                return;
            }

            // Success: tell the welcome screen to open the Admin dashboard.
            DialogResult = DialogResult.OK;
            Close();
        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (!_passwordShowingPlaceholder)
                txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;
        }
    }
}
