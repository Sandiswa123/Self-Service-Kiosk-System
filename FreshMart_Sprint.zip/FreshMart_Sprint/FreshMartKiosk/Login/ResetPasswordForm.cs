using System;
using System.Windows.Forms;

namespace FreshmartAdminLogIn
{
    /// <summary>
    /// Change an admin password. The CURRENT password is required, so a customer
    /// at the kiosk can no longer take over the admin account.
    /// </summary>
    public partial class frmResetPassword : Form
    {
        private const int MinPasswordLength = 6;

        public frmResetPassword()
        {
            InitializeComponent();
            AcceptButton = btnResetPassword;
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string currentPassword = txtCurrentPassword.Text;
            string newPassword = txtNewPassword.Text;
            string confirmPassword = txtConfirmPassword.Text;

            if (username.Length == 0)
            {
                Warn("Please enter a username.", txtUsername);
                return;
            }
            if (currentPassword.Length == 0)
            {
                Warn("Please enter your current password.", txtCurrentPassword);
                return;
            }
            if (newPassword.Length == 0 || confirmPassword.Length == 0)
            {
                Warn("Please fill in both new password fields.", newPassword.Length == 0 ? txtNewPassword : txtConfirmPassword);
                return;
            }
            if (newPassword.Length < MinPasswordLength)
            {
                Warn($"The new password must be at least {MinPasswordLength} characters.", txtNewPassword);
                return;
            }
            if (newPassword != confirmPassword)
            {
                txtConfirmPassword.Clear();
                Warn("The new passwords you entered don't match.", txtConfirmPassword);
                return;
            }

            try
            {
                if (!DatabaseHelper.CheckLogin(username, currentPassword))
                {
                    txtCurrentPassword.Clear();
                    MessageBox.Show(this, "Username or current password is incorrect.", "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtCurrentPassword.Focus();
                    return;
                }

                DatabaseHelper.UpdatePassword(username, newPassword);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not save to the database:\n" + ex.Message, "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MessageBox.Show(this, "Your password has been changed.", "Password Changed", MessageBoxButtons.OK, MessageBoxIcon.Information);
            DialogResult = DialogResult.OK;
            Close();
        }

        private void Warn(string message, Control focus)
        {
            MessageBox.Show(this, message, "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            focus.Focus();
        }

        private void BackToLoginLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void chkShowPassowrd_CheckedChanged(object sender, EventArgs e)
        {
            bool hide = !chkShowPassword.Checked;
            txtCurrentPassword.UseSystemPasswordChar = hide;
            txtNewPassword.UseSystemPasswordChar = hide;
            txtConfirmPassword.UseSystemPasswordChar = hide;
        }
    }
}
