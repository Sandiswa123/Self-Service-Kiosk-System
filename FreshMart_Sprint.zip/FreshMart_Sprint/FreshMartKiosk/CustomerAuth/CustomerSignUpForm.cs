using System;
using System.Drawing;
using System.Windows.Forms;

namespace FreshMartKiosk.CustomerAuth
{
    public sealed class CustomerSignUpForm : Form
    {
        private readonly TextBox txtFullName;
        private readonly TextBox txtEmail;
        private readonly TextBox txtUsername;
        private readonly TextBox txtPassword;
        private readonly TextBox txtConfirmPassword;
        private readonly Label lblError;

        public CustomerAccount CreatedCustomer { get; private set; }

        public CustomerSignUpForm()
        {
            Text = "Create FreshMart Account";
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(560, 660);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            BackColor = Color.FromArgb(13, 19, 38);
            ForeColor = Color.White;
            Font = new Font("Segoe UI", 10F);

            Controls.Add(new Label
            {
                Text = "F",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(46, 175, 84),
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(52, 52),
                Location = new Point(34, 28)
            });
            Controls.Add(new Label
            {
                Text = "Create your FreshMart account",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(105, 31)
            });
            Controls.Add(new Label
            {
                Text = "Sign up once, then use your account whenever you shop.",
                ForeColor = Color.Silver,
                AutoSize = true,
                Location = new Point(108, 63)
            });

            int left = 55;
            int width = 450;
            int y = 120;

            txtFullName = AddField("Full name", left, ref y, width, false);
            txtEmail = AddField("Email address", left, ref y, width, false);
            txtUsername = AddField("Username", left, ref y, width, false);
            txtPassword = AddField("Password", left, ref y, width, true);
            txtConfirmPassword = AddField("Confirm password", left, ref y, width, true);

            lblError = new Label
            {
                ForeColor = Color.FromArgb(255, 120, 120),
                AutoSize = false,
                Size = new Size(width, 42),
                Location = new Point(left, y - 6),
                TextAlign = ContentAlignment.MiddleLeft
            };
            Controls.Add(lblError);
            y += 52;

            var btnCreate = new Button
            {
                Text = "CREATE ACCOUNT",
                Location = new Point(left, y),
                Size = new Size(width, 50),
                BackColor = Color.FromArgb(46, 175, 84),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold)
            };
            btnCreate.FlatAppearance.BorderSize = 0;
            btnCreate.Click += CreateAccount_Click;
            Controls.Add(btnCreate);
            AcceptButton = btnCreate;

            var btnCancel = new Button
            {
                Text = "Back to login",
                Location = new Point(left, y + 62),
                Size = new Size(width, 42),
                BackColor = Color.FromArgb(45, 60, 85),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCancel.FlatAppearance.BorderSize = 0;
            btnCancel.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };
            Controls.Add(btnCancel);
            CancelButton = btnCancel;
        }

        private TextBox AddField(string label, int left, ref int y, int width, bool password)
        {
            Controls.Add(new Label
            {
                Text = label,
                ForeColor = Color.Gainsboro,
                AutoSize = true,
                Location = new Point(left, y)
            });
            y += 24;

            var box = new TextBox
            {
                Location = new Point(left, y),
                Width = width,
                Height = 32,
                BackColor = Color.FromArgb(45, 60, 85),
                ForeColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 11F),
                UseSystemPasswordChar = password
            };
            Controls.Add(box);
            y += 50;
            return box;
        }

        private void CreateAccount_Click(object sender, EventArgs e)
        {
            lblError.Text = string.Empty;

            if (txtPassword.Text != txtConfirmPassword.Text)
            {
                lblError.Text = "The two passwords do not match.";
                txtConfirmPassword.Focus();
                txtConfirmPassword.SelectAll();
                return;
            }

            CustomerAccount account;
            string error;
            try
            {
                if (!CustomerAuthService.TryCreateAccount(
                    txtFullName.Text,
                    txtEmail.Text,
                    txtUsername.Text,
                    txtPassword.Text,
                    out account,
                    out error))
                {
                    lblError.Text = error;
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this,
                    "The account could not be created.\n\n" + ex.Message,
                    "FreshMart Account",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            CreatedCustomer = account;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
