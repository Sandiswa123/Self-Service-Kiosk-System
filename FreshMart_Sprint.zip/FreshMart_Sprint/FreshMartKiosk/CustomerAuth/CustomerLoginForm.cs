using System;
using System.Drawing;
using System.Windows.Forms;

namespace FreshMartKiosk.CustomerAuth
{
    public sealed class CustomerLoginForm : Form
    {
        private readonly TextBox txtLogin;
        private readonly TextBox txtPassword;
        private readonly Label lblError;

        public CustomerLoginForm()
        {
            Text = "FreshMart Customer Login";
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(620, 470);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            BackColor = Color.FromArgb(13, 19, 38);
            ForeColor = Color.White;
            Font = new Font("Segoe UI", 10F);

            Controls.Add(new Label
            {
                Text = "F",
                Font = new Font("Segoe UI", 20, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(46, 175, 84),
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(58, 58),
                Location = new Point(42, 34)
            });
            Controls.Add(new Label
            {
                Text = "Welcome to FreshMart",
                Font = new Font("Segoe UI", 21, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(122, 37)
            });
            Controls.Add(new Label
            {
                Text = "Log in to start your self-checkout shopping session.",
                ForeColor = Color.Silver,
                AutoSize = true,
                Location = new Point(126, 75)
            });

            Controls.Add(new Label
            {
                Text = "Username or email",
                ForeColor = Color.Gainsboro,
                AutoSize = true,
                Location = new Point(70, 135)
            });
            txtLogin = new TextBox
            {
                Location = new Point(73, 161),
                Width = 474,
                Font = new Font("Segoe UI", 12F),
                BackColor = Color.FromArgb(45, 60, 85),
                ForeColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            Controls.Add(txtLogin);

            Controls.Add(new Label
            {
                Text = "Password",
                ForeColor = Color.Gainsboro,
                AutoSize = true,
                Location = new Point(70, 211)
            });
            txtPassword = new TextBox
            {
                Location = new Point(73, 237),
                Width = 474,
                Font = new Font("Segoe UI", 12F),
                BackColor = Color.FromArgb(45, 60, 85),
                ForeColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                UseSystemPasswordChar = true
            };
            Controls.Add(txtPassword);

            lblError = new Label
            {
                ForeColor = Color.FromArgb(255, 120, 120),
                AutoSize = false,
                Size = new Size(474, 34),
                Location = new Point(73, 278)
            };
            Controls.Add(lblError);

            var btnLogin = new Button
            {
                Text = "LOG IN",
                Location = new Point(73, 319),
                Size = new Size(474, 50),
                BackColor = Color.FromArgb(46, 175, 84),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold)
            };
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.Click += Login_Click;
            Controls.Add(btnLogin);
            AcceptButton = btnLogin;

            var btnSignUp = new Button
            {
                Text = "NEW CUSTOMER? CREATE AN ACCOUNT",
                Location = new Point(73, 380),
                Size = new Size(474, 43),
                BackColor = Color.FromArgb(45, 60, 85),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
            };
            btnSignUp.FlatAppearance.BorderSize = 0;
            btnSignUp.Click += SignUp_Click;
            Controls.Add(btnSignUp);

            var btnClose = new Button { DialogResult = DialogResult.Cancel, Visible = false };
            Controls.Add(btnClose);
            CancelButton = btnClose;
        }

        private void Login_Click(object sender, EventArgs e)
        {
            lblError.Text = string.Empty;
            if (string.IsNullOrWhiteSpace(txtLogin.Text))
            {
                lblError.Text = "Please enter your username or email.";
                txtLogin.Focus();
                return;
            }
            if (txtPassword.Text.Length == 0)
            {
                lblError.Text = "Please enter your password.";
                txtPassword.Focus();
                return;
            }

            try
            {
                CustomerAccount customer = CustomerAuthService.Authenticate(txtLogin.Text, txtPassword.Text);
                if (customer == null)
                {
                    lblError.Text = "Incorrect username/email or password.";
                    txtPassword.Clear();
                    txtPassword.Focus();
                    return;
                }

                CustomerSession.SignIn(customer);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this,
                    "FreshMart could not log you in.\n\n" + ex.Message,
                    "Customer Login",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void SignUp_Click(object sender, EventArgs e)
        {
            using (var signUp = new CustomerSignUpForm())
            {
                if (signUp.ShowDialog(this) != DialogResult.OK || signUp.CreatedCustomer == null)
                    return;

                CustomerSession.SignIn(signUp.CreatedCustomer);
                DialogResult = DialogResult.OK;
                Close();
            }
        }
    }
}
