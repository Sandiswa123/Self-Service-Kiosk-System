using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace FreshmartAdminLogIn
{

    public static class DatabaseHelper
    {

        private static readonly string FilePath =
            Path.Combine(Application.StartupPath, "FreshMartDataBase.txt");

        private const char FieldSeparator = '|';

        public static bool CheckLogin(string username, string password)
        {
            List<UserRecord> users = LoadUsers();

            foreach (UserRecord user in users)
            {
                if (user.Username == username && user.Password == password)
                {
                    return true;
                }
            }

            return false;
        }

        public static bool UsernameExists(string username)
        {
            List<UserRecord> users = LoadUsers();

            foreach (UserRecord user in users)
            {
                if (user.Username == username)
                {
                    return true;
                }
            }

            return false;
        }

        public static void SaveOrUpdatePassword(string username, string newPassword)
        {
            List<UserRecord> users = LoadUsers();
            bool found = false;

            for (int i = 0; i < users.Count; i++)
            {
                if (users[i].Username == username)
                {
                    users[i] = new UserRecord(username, newPassword);
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                users.Add(new UserRecord(username, newPassword));
            }

            SaveUsers(users);
        }

        public static void EnsureDatabaseExists()
        {
            if (!File.Exists(FilePath))
            {
                List<UserRecord> startingUsers = new List<UserRecord>();
                startingUsers.Add(new UserRecord("admin", "admin123"));
                SaveUsers(startingUsers);
            }
        }

        private static List<UserRecord> LoadUsers()
        {
            List<UserRecord> users = new List<UserRecord>();

            if (!File.Exists(FilePath))
            {
                return users;
            }

            string[] lines = File.ReadAllLines(FilePath);

            foreach (string line in lines)
            {
                if (string.IsNullOrWhiteSpace(line))
                {
                    continue;
                }

                string[] parts = line.Split(FieldSeparator);

                if (parts.Length == 2)
                {
                    users.Add(new UserRecord(parts[0], parts[1]));
                }
            }

            return users;
        }

        private static void SaveUsers(List<UserRecord> users)
        {
            List<string> lines = new List<string>();

            foreach (UserRecord user in users)
            {
                lines.Add(user.Username + FieldSeparator + user.Password);
            }

            File.WriteAllLines(FilePath, lines.ToArray());
        }

        private struct UserRecord
        {
            public string Username;
            public string Password;

            public UserRecord(string username, string password)
            {
                Username = username;
                Password = password;
            }
        }
    }
}
