using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("FreshmartAdminLogIn")]
[assembly: AssemblyDescription("WebKreeda Admin Login screen")]
[assembly: AssemblyProduct("FreshmartAdminLogIn")]
[assembly: ComVisible(false)]
[assembly: Guid("4F2B8E31-7C9A-4E15-9D2C-6A8B1F3E5C90")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
