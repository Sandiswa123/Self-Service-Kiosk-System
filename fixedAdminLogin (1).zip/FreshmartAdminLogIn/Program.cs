using System;
using System.Windows.Forms;

namespace FreshmartAdminLogIn
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            DatabaseHelper.EnsureDatabaseExists();
            Application.Run(new frmFreshmartAdminLogin());
        }
    }
}
