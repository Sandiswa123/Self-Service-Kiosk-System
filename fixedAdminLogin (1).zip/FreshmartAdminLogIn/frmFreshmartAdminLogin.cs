using System;
using System.Windows.Forms;

namespace FreshmartAdminLogIn
{
    public partial class frmFreshmartAdminLogin : Form
    {
        private readonly System.Drawing.Color _textLight = System.Drawing.Color.White;
        private readonly System.Drawing.Color _textGray = System.Drawing.Color.FromArgb(148, 163, 184);

        private const string UserNamePlaceholder = "Username";
        private const string PasswordPlaceholder = "Password";
        private bool _userNameShowingPlaceholder = true;
        private bool _passwordShowingPlaceholder = true;

        public frmFreshmartAdminLogin()
        {
            InitializeComponent();

            ActiveControl = btnLogin;
        }

        private void UserNameBox_Enter(object sender, EventArgs e)
        {
            if (_userNameShowingPlaceholder)
            {
                txtUserName.Text = string.Empty;
                txtUserName.ForeColor = _textLight;
                _userNameShowingPlaceholder = false;
            }
        }

        private void UserNameBox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUserName.Text))
            {
                _userNameShowingPlaceholder = true;
                txtUserName.Text = UserNamePlaceholder;
                txtUserName.ForeColor = _textGray;
            }
        }

        private void PasswordBox_Enter(object sender, EventArgs e)
        {
            if (_passwordShowingPlaceholder)
            {
                txtPassword.Text = string.Empty;
                txtPassword.ForeColor = _textLight;
                txtPassword.UseSystemPasswordChar = true;
                _passwordShowingPlaceholder = false;
            }
        }

        private void PasswordBox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                _passwordShowingPlaceholder = true;
                txtPassword.UseSystemPasswordChar = false;
                txtPassword.Text = PasswordPlaceholder;
                txtPassword.ForeColor = _textGray;
            }
        }

        private void ResetLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            using (var resetForm = new frmResetPassword())
            {
                resetForm.ShowDialog(this);
            }
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            string userName;
            if (_userNameShowingPlaceholder)
            {
                userName = string.Empty;
            }
            else
            {
                userName = txtUserName.Text.Trim();
            }

            string password;
            if (_passwordShowingPlaceholder)
            {
                password = string.Empty;
            }
            else
            {
                password = txtPassword.Text;
            }

            bool userNameEmpty = string.IsNullOrEmpty(userName);
            bool passwordEmpty = string.IsNullOrEmpty(password);

            if (userNameEmpty && passwordEmpty)
            {
                MessageBox.Show(this, "Please enter your username and password.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUserName.Focus();
                return;
            }

            if (userNameEmpty)
            {
                MessageBox.Show(this, "Please enter your username.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUserName.Focus();
                return;
            }

            if (passwordEmpty)
            {
                MessageBox.Show(this, "Please enter your password.","Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPassword.Focus();
                return;
            }

            bool isValid;
            try
            {
                isValid = DatabaseHelper.CheckLogin(userName, password);
            }
            catch (Exception ex)
            {

                MessageBox.Show(this, "Could not connect to the database:\n" + ex.Message, "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!isValid)
            {
                MessageBox.Show(this, "Incorrect username or password.","Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Clear();
                txtPassword.Focus();
                return;
            }

            MessageBox.Show(this, "Login successful! Welcome, " + userName + ".","FreshMart Supermarket - Admin Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtPassword.Clear();
            txtUserName.Clear();
            txtUserName.Focus();

        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowPassword.Checked)
            {
                txtPassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = true;
            }
        }
    }
}
