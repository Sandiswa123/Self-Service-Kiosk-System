namespace FreshmartAdminLogIn
{
    partial class frmFreshmartAdminLogin
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlAdminLogin = new System.Windows.Forms.Panel();
            this.pnlLeftPanel = new System.Windows.Forms.Panel();
            this.lblLogo = new System.Windows.Forms.Label();
            this.wordmarkLabel = new System.Windows.Forms.Label();
            this.wordmarkSubLabel = new System.Windows.Forms.Label();
            this.lblAdminLogin = new System.Windows.Forms.Label();
            this.lblSubHeading = new System.Windows.Forms.Label();
            this.lblWelcomeBack = new System.Windows.Forms.Label();
            this.lblSubTitle = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.chkRememberMe = new System.Windows.Forms.CheckBox();
            this.lblForgotPassword = new System.Windows.Forms.Label();
            this.lblReset = new System.Windows.Forms.LinkLabel();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lblLoginProtected = new System.Windows.Forms.Label();
            this.chkShowPassword = new System.Windows.Forms.CheckBox();
            this.pnlAdminLogin.SuspendLayout();
            this.pnlLeftPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlAdminLogin
            // 
            this.pnlAdminLogin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlAdminLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(30)))), ((int)(((byte)(50)))));
            this.pnlAdminLogin.Controls.Add(this.chkShowPassword);
            this.pnlAdminLogin.Controls.Add(this.pnlLeftPanel);
            this.pnlAdminLogin.Controls.Add(this.lblWelcomeBack);
            this.pnlAdminLogin.Controls.Add(this.lblSubTitle);
            this.pnlAdminLogin.Controls.Add(this.txtUserName);
            this.pnlAdminLogin.Controls.Add(this.txtPassword);
            this.pnlAdminLogin.Controls.Add(this.chkRememberMe);
            this.pnlAdminLogin.Controls.Add(this.lblForgotPassword);
            this.pnlAdminLogin.Controls.Add(this.lblReset);
            this.pnlAdminLogin.Controls.Add(this.btnLogin);
            this.pnlAdminLogin.Controls.Add(this.lblLoginProtected);
            this.pnlAdminLogin.Location = new System.Drawing.Point(60, 60);
            this.pnlAdminLogin.Name = "pnlAdminLogin";
            this.pnlAdminLogin.Size = new System.Drawing.Size(980, 560);
            this.pnlAdminLogin.TabIndex = 0;
            // 
            // pnlLeftPanel
            // 
            this.pnlLeftPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(42)))));
            this.pnlLeftPanel.Controls.Add(this.lblLogo);
            this.pnlLeftPanel.Controls.Add(this.wordmarkLabel);
            this.pnlLeftPanel.Controls.Add(this.wordmarkSubLabel);
            this.pnlLeftPanel.Controls.Add(this.lblAdminLogin);
            this.pnlLeftPanel.Controls.Add(this.lblSubHeading);
            this.pnlLeftPanel.Location = new System.Drawing.Point(0, 0);
            this.pnlLeftPanel.Name = "pnlLeftPanel";
            this.pnlLeftPanel.Size = new System.Drawing.Size(380, 560);
            this.pnlLeftPanel.TabIndex = 0;
            // 
            // lblLogo
            // 
            this.lblLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(197)))), ((int)(((byte)(94)))));
            this.lblLogo.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.lblLogo.ForeColor = System.Drawing.Color.White;
            this.lblLogo.Location = new System.Drawing.Point(40, 60);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(60, 60);
            this.lblLogo.TabIndex = 0;
            this.lblLogo.Text = "F";
            this.lblLogo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wordmarkLabel
            // 
            this.wordmarkLabel.AutoSize = true;
            this.wordmarkLabel.BackColor = System.Drawing.Color.Transparent;
            this.wordmarkLabel.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.wordmarkLabel.ForeColor = System.Drawing.Color.White;
            this.wordmarkLabel.Location = new System.Drawing.Point(40, 132);
            this.wordmarkLabel.Name = "wordmarkLabel";
            this.wordmarkLabel.Size = new System.Drawing.Size(149, 37);
            this.wordmarkLabel.TabIndex = 1;
            this.wordmarkLabel.Text = "FreshMart";
            // 
            // wordmarkSubLabel
            // 
            this.wordmarkSubLabel.AutoSize = true;
            this.wordmarkSubLabel.BackColor = System.Drawing.Color.Transparent;
            this.wordmarkSubLabel.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.wordmarkSubLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.wordmarkSubLabel.Location = new System.Drawing.Point(42, 172);
            this.wordmarkSubLabel.Name = "wordmarkSubLabel";
            this.wordmarkSubLabel.Size = new System.Drawing.Size(185, 17);
            this.wordmarkSubLabel.TabIndex = 2;
            this.wordmarkSubLabel.Text = "SELF-SERVICE KIOSK SYSTEM";
            // 
            // lblAdminLogin
            // 
            this.lblAdminLogin.AutoSize = true;
            this.lblAdminLogin.BackColor = System.Drawing.Color.Transparent;
            this.lblAdminLogin.Font = new System.Drawing.Font("Segoe UI", 27F, System.Drawing.FontStyle.Bold);
            this.lblAdminLogin.ForeColor = System.Drawing.Color.White;
            this.lblAdminLogin.Location = new System.Drawing.Point(40, 270);
            this.lblAdminLogin.Name = "lblAdminLogin";
            this.lblAdminLogin.Size = new System.Drawing.Size(236, 48);
            this.lblAdminLogin.TabIndex = 3;
            this.lblAdminLogin.Text = "Admin Login";
            // 
            // lblSubHeading
            // 
            this.lblSubHeading.BackColor = System.Drawing.Color.Transparent;
            this.lblSubHeading.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSubHeading.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(163)))), ((int)(((byte)(184)))));
            this.lblSubHeading.Location = new System.Drawing.Point(42, 326);
            this.lblSubHeading.Name = "lblSubHeading";
            this.lblSubHeading.Size = new System.Drawing.Size(300, 40);
            this.lblSubHeading.TabIndex = 4;
            this.lblSubHeading.Text = "Enter your credentials to access the dashboard.";
            // 
            // lblWelcomeBack
            // 
            this.lblWelcomeBack.AutoSize = true;
            this.lblWelcomeBack.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcomeBack.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblWelcomeBack.ForeColor = System.Drawing.Color.White;
            this.lblWelcomeBack.Location = new System.Drawing.Point(460, 70);
            this.lblWelcomeBack.Name = "lblWelcomeBack";
            this.lblWelcomeBack.Size = new System.Drawing.Size(203, 37);
            this.lblWelcomeBack.TabIndex = 1;
            this.lblWelcomeBack.Text = "Welcome Back";
            // 
            // lblSubTitle
            // 
            this.lblSubTitle.AutoSize = true;
            this.lblSubTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblSubTitle.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSubTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(163)))), ((int)(((byte)(184)))));
            this.lblSubTitle.Location = new System.Drawing.Point(462, 112);
            this.lblSubTitle.Name = "lblSubTitle";
            this.lblSubTitle.Size = new System.Drawing.Size(269, 19);
            this.lblSubTitle.TabIndex = 2;
            this.lblSubTitle.Text = "Sign in to manage FreshMart Supermarket";
            // 
            // txtUserName
            // 
            this.txtUserName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(42)))));
            this.txtUserName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUserName.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtUserName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(163)))), ((int)(((byte)(184)))));
            this.txtUserName.Location = new System.Drawing.Point(460, 176);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(480, 27);
            this.txtUserName.TabIndex = 3;
            this.txtUserName.Text = "Username";
            this.txtUserName.Enter += new System.EventHandler(this.UserNameBox_Enter);
            this.txtUserName.Leave += new System.EventHandler(this.UserNameBox_Leave);
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(23)))), ((int)(((byte)(42)))));
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(163)))), ((int)(((byte)(184)))));
            this.txtPassword.Location = new System.Drawing.Point(460, 238);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(480, 27);
            this.txtPassword.TabIndex = 4;
            this.txtPassword.Text = "Password";
            this.txtPassword.Enter += new System.EventHandler(this.PasswordBox_Enter);
            this.txtPassword.Leave += new System.EventHandler(this.PasswordBox_Leave);
            // 
            // chkRememberMe
            // 
            this.chkRememberMe.AutoSize = true;
            this.chkRememberMe.BackColor = System.Drawing.Color.Transparent;
            this.chkRememberMe.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.chkRememberMe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(163)))), ((int)(((byte)(184)))));
            this.chkRememberMe.Location = new System.Drawing.Point(460, 300);
            this.chkRememberMe.Name = "chkRememberMe";
            this.chkRememberMe.Size = new System.Drawing.Size(113, 21);
            this.chkRememberMe.TabIndex = 5;
            this.chkRememberMe.Text = "Remember me";
            this.chkRememberMe.UseVisualStyleBackColor = false;
            // 
            // lblForgotPassword
            // 
            this.lblForgotPassword.AutoSize = true;
            this.lblForgotPassword.BackColor = System.Drawing.Color.Transparent;
            this.lblForgotPassword.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblForgotPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(163)))), ((int)(((byte)(184)))));
            this.lblForgotPassword.Location = new System.Drawing.Point(772, 301);
            this.lblForgotPassword.Name = "lblForgotPassword";
            this.lblForgotPassword.Size = new System.Drawing.Size(118, 17);
            this.lblForgotPassword.TabIndex = 6;
            this.lblForgotPassword.Text = "Forgot password? ";
            // 
            // lblReset
            // 
            this.lblReset.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(197)))), ((int)(((byte)(94)))));
            this.lblReset.AutoSize = true;
            this.lblReset.BackColor = System.Drawing.Color.Transparent;
            this.lblReset.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblReset.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(199)))), ((int)(((byte)(219)))));
            this.lblReset.Location = new System.Drawing.Point(886, 301);
            this.lblReset.Name = "lblReset";
            this.lblReset.Size = new System.Drawing.Size(71, 17);
            this.lblReset.TabIndex = 7;
            this.lblReset.TabStop = true;
            this.lblReset.Text = "Reset now";
            this.lblReset.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ResetLinkLabel_LinkClicked);
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(197)))), ((int)(((byte)(94)))));
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnLogin.ForeColor = System.Drawing.Color.White;
            this.btnLogin.Location = new System.Drawing.Point(460, 356);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(480, 50);
            this.btnLogin.TabIndex = 8;
            this.btnLogin.Text = "LOG IN";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.LoginButton_Click);
            // 
            // lblLoginProtected
            // 
            this.lblLoginProtected.AutoSize = true;
            this.lblLoginProtected.BackColor = System.Drawing.Color.Transparent;
            this.lblLoginProtected.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblLoginProtected.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(163)))), ((int)(((byte)(184)))));
            this.lblLoginProtected.Location = new System.Drawing.Point(460, 426);
            this.lblLoginProtected.Name = "lblLoginProtected";
            this.lblLoginProtected.Size = new System.Drawing.Size(129, 15);
            this.lblLoginProtected.TabIndex = 9;
            this.lblLoginProtected.Text = "Your login is protected.";
            // 
            // chkShowPassword
            // 
            this.chkShowPassword.AutoSize = true;
            this.chkShowPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(163)))), ((int)(((byte)(184)))));
            this.chkShowPassword.Location = new System.Drawing.Point(822, 270);
            this.chkShowPassword.Name = "chkShowPassword";
            this.chkShowPassword.Size = new System.Drawing.Size(118, 21);
            this.chkShowPassword.TabIndex = 10;
            this.chkShowPassword.Text = "Show Password";
            this.chkShowPassword.UseVisualStyleBackColor = true;
            this.chkShowPassword.CheckedChanged += new System.EventHandler(this.chkShowPassword_CheckedChanged);
            // 
            // frmFreshmartAdminLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(15)))), ((int)(((byte)(28)))));
            this.ClientSize = new System.Drawing.Size(1100, 680);
            this.Controls.Add(this.pnlAdminLogin);
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmFreshmartAdminLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Admin Login";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnlAdminLogin.ResumeLayout(false);
            this.pnlAdminLogin.PerformLayout();
            this.pnlLeftPanel.ResumeLayout(false);
            this.pnlLeftPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAdminLogin;
        private System.Windows.Forms.Panel pnlLeftPanel;
        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.Label wordmarkLabel;
        private System.Windows.Forms.Label wordmarkSubLabel;
        private System.Windows.Forms.Label lblAdminLogin;
        private System.Windows.Forms.Label lblSubHeading;
        private System.Windows.Forms.Label lblWelcomeBack;
        private System.Windows.Forms.Label lblSubTitle;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.CheckBox chkRememberMe;
        private System.Windows.Forms.Label lblForgotPassword;
        private System.Windows.Forms.LinkLabel lblReset;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label lblLoginProtected;
        private System.Windows.Forms.CheckBox chkShowPassword;
    }
}
