using FreshMart_AddCard;
using System;
using System.Windows.Forms;

namespace SelfServiceKiosk
{
    public partial class frmCheckoutForm : Form
    {
        public frmCheckoutForm()
        {
            InitializeComponent();
            lblDateTime.Text = DateTime.Now.ToString("dddd, MMMM d, yyyy • h:mm tt");
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Back to Cart clicked.", "Self-Service Kiosk");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show(
                "Cancel this transaction?",
                "Cancel Transaction",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
                Close();
        }

        private void btnPrintReceipt_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Receipt printing is simulated for this project.", "Receipt");
        }

        private void btnCompleteTransaction_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Payment approved. Transaction completed successfully.",
                "Payment Complete",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void lblDate_Click(object sender, EventArgs e)
        {

        }

        private void paymentPanel_Paint(object sender, PaintEventArgs e)
        {

        } 

        private void lblReceiptSub_Click(object sender, EventArgs e)
        {

        }

        private void lblPaymentSub_Click(object sender, EventArgs e)
        {

        }

        private void paymentPanel_Click(object sender, EventArgs e)
        {

            AddCardForm addCard = new AddCardForm();

            if (addCard.ShowDialog() == DialogResult.OK)
            {
                string cardNumber = addCard.CardNumber;
                string expiry = addCard.ExpiryDate;

                string lastFour =
                    cardNumber.Substring(cardNumber.Length - 4);

                lblCardInfo.Text =
                    "Card ending in " + lastFour +
                    "\nExpires " + expiry;
            }
        }
    }
}
