using System;
using System.Linq;
using System.Windows.Forms;

namespace FreshMart_AddCard
{
    public partial class AddCardForm : Form
    {
        public string CardholderName { get; private set; }
        public string CardNumber { get; private set; }
        public string ExpiryDate { get; private set; }

        public AddCardForm()
        {
            InitializeComponent();
        }

        private void txtCardName_TextChanged(object sender, EventArgs e)
        {
            lblPreviewName.Text = string.IsNullOrWhiteSpace(txtCardName.Text)
                ? "CARDHOLDER NAME"
                : txtCardName.Text.Trim().ToUpper();
        }

        private void txtCardNumber_TextChanged(object sender, EventArgs e)
        {
            string digits = new string(txtCardNumber.Text.Where(char.IsDigit).ToArray());

            if (digits.Length > 16)
                digits = digits.Substring(0, 16);

            string formatted = "";
            for (int i = 0; i < digits.Length; i++)
            {
                if (i > 0 && i % 4 == 0)
                    formatted += " ";
                formatted += digits[i];
            }

            if (txtCardNumber.Text != formatted)
            {
                txtCardNumber.Text = formatted;
                txtCardNumber.SelectionStart = txtCardNumber.Text.Length;
            }

            lblPreviewNumber.Text = string.IsNullOrEmpty(formatted)
                ? "0000 0000 0000 0000"
                : formatted;
        }

        private void txtExpiry_TextChanged(object sender, EventArgs e)
        {
            string digits = new string(txtExpiry.Text.Where(char.IsDigit).ToArray());

            if (digits.Length > 4)
                digits = digits.Substring(0, 4);

            string formatted = digits.Length > 2
                ? digits.Substring(0, 2) + "/" + digits.Substring(2)
                : digits;

            if (txtExpiry.Text != formatted)
            {
                txtExpiry.Text = formatted;
                txtExpiry.SelectionStart = txtExpiry.Text.Length;
            }

            lblPreviewExpiry.Text = string.IsNullOrEmpty(formatted)
                ? "MM/YY"
                : formatted;
        }

        private void txtCVV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private bool ValidExpiry(string expiry)
        {
            if (expiry.Length != 5 || expiry[2] != '/')
                return false;

            int month;
            int year;

            if (!int.TryParse(expiry.Substring(0, 2), out month) ||
                !int.TryParse(expiry.Substring(3, 2), out year))
                return false;

            if (month < 1 || month > 12)
                return false;

            int currentYear = DateTime.Now.Year % 100;
            return year > currentYear ||
                   (year == currentYear && month >= DateTime.Now.Month);
        }

        private bool LuhnCheck(string number)
        {
            int sum = 0;
            bool alternate = false;

            for (int i = number.Length - 1; i >= 0; i--)
            {
                int n = number[i] - '0';

                if (alternate)
                {
                    n *= 2;
                    if (n > 9)
                        n -= 9;
                }

                sum += n;
                alternate = !alternate;
            }

            return sum % 10 == 0;
        }

        private void btnAddCard_Click(object sender, EventArgs e)
        {
            string name = txtCardName.Text.Trim();
            string number = new string(txtCardNumber.Text.Where(char.IsDigit).ToArray());
            string expiry = txtExpiry.Text.Trim();
            string cvv = txtCVV.Text.Trim();

            if (name.Length < 2)
            {
                MessageBox.Show("Please enter the cardholder name.");
                txtCardName.Focus();
                return;
            }

            if (number.Length != 16 || !LuhnCheck(number))
            {
                MessageBox.Show("Please enter a valid 16-digit card number.");
                txtCardNumber.Focus();
                return;
            }

            if (!ValidExpiry(expiry))
            {
                MessageBox.Show("Please enter a valid future expiry date (MM/YY).");
                txtExpiry.Focus();
                return;
            }

            if (cvv.Length != 3)
            {
                MessageBox.Show("Please enter a valid 3-digit CVV.");
                txtCVV.Focus();
                return;
            }

            CardholderName = name;
            CardNumber = number;
            ExpiryDate = expiry;

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void lblCardName_Click(object sender, EventArgs e)
        {

        }
    }
}
