namespace SelfServiceKiosk
{
    partial class frmCheckoutForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.headerPanel = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblHeader = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblOrderSummary = new System.Windows.Forms.Label();
            this.orderPanel = new System.Windows.Forms.Panel();
            this.lblTotalValue = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblTaxValue = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.lblSubtotalValue = new System.Windows.Forms.Label();
            this.lblSubtotal = new System.Windows.Forms.Label();
            this.divider2 = new System.Windows.Forms.Label();
            this.lblApplePrice = new System.Windows.Forms.Label();
            this.lblAppleSub = new System.Windows.Forms.Label();
            this.lblApple = new System.Windows.Forms.Label();
            this.lblEggPrice = new System.Windows.Forms.Label();
            this.lblEggSub = new System.Windows.Forms.Label();
            this.lblEggs = new System.Windows.Forms.Label();
            this.lblMilkPrice = new System.Windows.Forms.Label();
            this.lblMilkSub = new System.Windows.Forms.Label();
            this.lblMilk = new System.Windows.Forms.Label();
            this.divider1 = new System.Windows.Forms.Label();
            this.lblDateTime = new System.Windows.Forms.Label();
            this.lblStore = new System.Windows.Forms.Label();
            this.lblPaymentMethod = new System.Windows.Forms.Label();
            this.paymentPanel = new System.Windows.Forms.Panel();
            this.lblPaymentSub = new System.Windows.Forms.Label();
            this.lblCard = new System.Windows.Forms.Label();
            this.lblCardIcon = new System.Windows.Forms.Label();
            this.receiptPanel = new System.Windows.Forms.Panel();
            this.btnPrintReceipt = new System.Windows.Forms.Button();
            this.lblOr = new System.Windows.Forms.Label();
            this.txtReceiptContact = new System.Windows.Forms.TextBox();
            this.lblReceiptSub = new System.Windows.Forms.Label();
            this.lblReceiptOptions = new System.Windows.Forms.Label();
            this.btnCompleteTransaction = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.lblCardInfo = new System.Windows.Forms.Label();
            this.headerPanel.SuspendLayout();
            this.orderPanel.SuspendLayout();
            this.paymentPanel.SuspendLayout();
            this.receiptPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // headerPanel
            // 
            this.headerPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(46)))), ((int)(((byte)(66)))));
            this.headerPanel.Controls.Add(this.btnCancel);
            this.headerPanel.Controls.Add(this.lblHeader);
            this.headerPanel.Controls.Add(this.btnBack);
            this.headerPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerPanel.Location = new System.Drawing.Point(0, 0);
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.Size = new System.Drawing.Size(1280, 58);
            this.headerPanel.TabIndex = 0;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(98)))), ((int)(((byte)(98)))));
            this.btnCancel.Location = new System.Drawing.Point(1192, 12);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(76, 34);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblHeader
            // 
            this.lblHeader.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.White;
            this.lblHeader.Location = new System.Drawing.Point(592, 17);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(125, 21);
            this.lblHeader.TabIndex = 1;
            this.lblHeader.Text = "Review And Pay";
            // 
            // btnBack
            // 
            this.btnBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnBack.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnBack.Location = new System.Drawing.Point(18, 11);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(115, 35);
            this.btnBack.TabIndex = 0;
            this.btnBack.Text = "← Back to Cart";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblOrderSummary
            // 
            this.lblOrderSummary.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblOrderSummary.AutoSize = true;
            this.lblOrderSummary.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold);
            this.lblOrderSummary.ForeColor = System.Drawing.Color.White;
            this.lblOrderSummary.Location = new System.Drawing.Point(68, 92);
            this.lblOrderSummary.Name = "lblOrderSummary";
            this.lblOrderSummary.Size = new System.Drawing.Size(157, 28);
            this.lblOrderSummary.TabIndex = 1;
            this.lblOrderSummary.Text = "Order Summary";
            // 
            // orderPanel
            // 
            this.orderPanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.orderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(47)))), ((int)(((byte)(67)))));
            this.orderPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.orderPanel.Controls.Add(this.lblTotalValue);
            this.orderPanel.Controls.Add(this.lblTotal);
            this.orderPanel.Controls.Add(this.lblTaxValue);
            this.orderPanel.Controls.Add(this.lblTax);
            this.orderPanel.Controls.Add(this.lblSubtotalValue);
            this.orderPanel.Controls.Add(this.lblSubtotal);
            this.orderPanel.Controls.Add(this.divider2);
            this.orderPanel.Controls.Add(this.lblApplePrice);
            this.orderPanel.Controls.Add(this.lblAppleSub);
            this.orderPanel.Controls.Add(this.lblApple);
            this.orderPanel.Controls.Add(this.lblEggPrice);
            this.orderPanel.Controls.Add(this.lblEggSub);
            this.orderPanel.Controls.Add(this.lblEggs);
            this.orderPanel.Controls.Add(this.lblMilkPrice);
            this.orderPanel.Controls.Add(this.lblMilkSub);
            this.orderPanel.Controls.Add(this.lblMilk);
            this.orderPanel.Controls.Add(this.divider1);
            this.orderPanel.Controls.Add(this.lblDateTime);
            this.orderPanel.Controls.Add(this.lblStore);
            this.orderPanel.Location = new System.Drawing.Point(72, 136);
            this.orderPanel.Name = "orderPanel";
            this.orderPanel.Size = new System.Drawing.Size(430, 392);
            this.orderPanel.TabIndex = 2;
            // 
            // lblTotalValue
            // 
            this.lblTotalValue.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold);
            this.lblTotalValue.ForeColor = System.Drawing.Color.White;
            this.lblTotalValue.Location = new System.Drawing.Point(285, 338);
            this.lblTotalValue.Name = "lblTotalValue";
            this.lblTotalValue.Size = new System.Drawing.Size(122, 30);
            this.lblTotalValue.TabIndex = 18;
            this.lblTotalValue.Text = "R 18.14";
            this.lblTotalValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold);
            this.lblTotal.ForeColor = System.Drawing.Color.White;
            this.lblTotal.Location = new System.Drawing.Point(18, 339);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(69, 28);
            this.lblTotal.TabIndex = 17;
            this.lblTotal.Text = "TOTAL";
            // 
            // lblTaxValue
            // 
            this.lblTaxValue.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTaxValue.ForeColor = System.Drawing.Color.Silver;
            this.lblTaxValue.Location = new System.Drawing.Point(305, 308);
            this.lblTaxValue.Name = "lblTaxValue";
            this.lblTaxValue.Size = new System.Drawing.Size(102, 20);
            this.lblTaxValue.TabIndex = 16;
            this.lblTaxValue.Text = "R 2.37";
            this.lblTaxValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTax
            // 
            this.lblTax.AutoSize = true;
            this.lblTax.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTax.ForeColor = System.Drawing.Color.Silver;
            this.lblTax.Location = new System.Drawing.Point(18, 308);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(93, 19);
            this.lblTax.TabIndex = 15;
            this.lblTax.Text = "Tax (15% VAT)";
            // 
            // lblSubtotalValue
            // 
            this.lblSubtotalValue.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSubtotalValue.ForeColor = System.Drawing.Color.Silver;
            this.lblSubtotalValue.Location = new System.Drawing.Point(305, 282);
            this.lblSubtotalValue.Name = "lblSubtotalValue";
            this.lblSubtotalValue.Size = new System.Drawing.Size(102, 20);
            this.lblSubtotalValue.TabIndex = 14;
            this.lblSubtotalValue.Text = "R 15.77";
            this.lblSubtotalValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSubtotal
            // 
            this.lblSubtotal.AutoSize = true;
            this.lblSubtotal.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSubtotal.ForeColor = System.Drawing.Color.Silver;
            this.lblSubtotal.Location = new System.Drawing.Point(18, 282);
            this.lblSubtotal.Name = "lblSubtotal";
            this.lblSubtotal.Size = new System.Drawing.Size(60, 19);
            this.lblSubtotal.TabIndex = 13;
            this.lblSubtotal.Text = "Subtotal";
            // 
            // divider2
            // 
            this.divider2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(94)))), ((int)(((byte)(113)))));
            this.divider2.Location = new System.Drawing.Point(18, 267);
            this.divider2.Name = "divider2";
            this.divider2.Size = new System.Drawing.Size(389, 1);
            this.divider2.TabIndex = 12;
            // 
            // lblApplePrice
            // 
            this.lblApplePrice.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.lblApplePrice.ForeColor = System.Drawing.Color.White;
            this.lblApplePrice.Location = new System.Drawing.Point(310, 226);
            this.lblApplePrice.Name = "lblApplePrice";
            this.lblApplePrice.Size = new System.Drawing.Size(97, 20);
            this.lblApplePrice.TabIndex = 11;
            this.lblApplePrice.Text = "R 4.99";
            this.lblApplePrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblAppleSub
            // 
            this.lblAppleSub.AutoSize = true;
            this.lblAppleSub.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblAppleSub.ForeColor = System.Drawing.Color.Silver;
            this.lblAppleSub.Location = new System.Drawing.Point(58, 246);
            this.lblAppleSub.Name = "lblAppleSub";
            this.lblAppleSub.Size = new System.Drawing.Size(69, 15);
            this.lblAppleSub.TabIndex = 10;
            this.lblAppleSub.Text = "×1 @ R 4.99";
            // 
            // lblApple
            // 
            this.lblApple.AutoSize = true;
            this.lblApple.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.lblApple.ForeColor = System.Drawing.Color.White;
            this.lblApple.Location = new System.Drawing.Point(58, 226);
            this.lblApple.Name = "lblApple";
            this.lblApple.Size = new System.Drawing.Size(132, 19);
            this.lblApple.TabIndex = 9;
            this.lblApple.Text = "🍎 Gala Apples 1kg";
            // 
            // lblEggPrice
            // 
            this.lblEggPrice.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.lblEggPrice.ForeColor = System.Drawing.Color.White;
            this.lblEggPrice.Location = new System.Drawing.Point(310, 174);
            this.lblEggPrice.Name = "lblEggPrice";
            this.lblEggPrice.Size = new System.Drawing.Size(97, 20);
            this.lblEggPrice.TabIndex = 8;
            this.lblEggPrice.Text = "R 5.79";
            this.lblEggPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblEggSub
            // 
            this.lblEggSub.AutoSize = true;
            this.lblEggSub.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblEggSub.ForeColor = System.Drawing.Color.Silver;
            this.lblEggSub.Location = new System.Drawing.Point(58, 194);
            this.lblEggSub.Name = "lblEggSub";
            this.lblEggSub.Size = new System.Drawing.Size(69, 15);
            this.lblEggSub.TabIndex = 7;
            this.lblEggSub.Text = "×1 @ R 5.79";
            // 
            // lblEggs
            // 
            this.lblEggs.AutoSize = true;
            this.lblEggs.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.lblEggs.ForeColor = System.Drawing.Color.White;
            this.lblEggs.Location = new System.Drawing.Point(58, 174);
            this.lblEggs.Name = "lblEggs";
            this.lblEggs.Size = new System.Drawing.Size(163, 19);
            this.lblEggs.TabIndex = 6;
            this.lblEggs.Text = "🥚 Free Range Eggs ×12";
            // 
            // lblMilkPrice
            // 
            this.lblMilkPrice.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.lblMilkPrice.ForeColor = System.Drawing.Color.White;
            this.lblMilkPrice.Location = new System.Drawing.Point(310, 122);
            this.lblMilkPrice.Name = "lblMilkPrice";
            this.lblMilkPrice.Size = new System.Drawing.Size(97, 20);
            this.lblMilkPrice.TabIndex = 5;
            this.lblMilkPrice.Text = "R 4.99";
            this.lblMilkPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblMilkSub
            // 
            this.lblMilkSub.AutoSize = true;
            this.lblMilkSub.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblMilkSub.ForeColor = System.Drawing.Color.Silver;
            this.lblMilkSub.Location = new System.Drawing.Point(58, 142);
            this.lblMilkSub.Name = "lblMilkSub";
            this.lblMilkSub.Size = new System.Drawing.Size(69, 15);
            this.lblMilkSub.TabIndex = 4;
            this.lblMilkSub.Text = "×1 @ R 4.99";
            // 
            // lblMilk
            // 
            this.lblMilk.AutoSize = true;
            this.lblMilk.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.lblMilk.ForeColor = System.Drawing.Color.White;
            this.lblMilk.Location = new System.Drawing.Point(58, 122);
            this.lblMilk.Name = "lblMilk";
            this.lblMilk.Size = new System.Drawing.Size(179, 19);
            this.lblMilk.TabIndex = 3;
            this.lblMilk.Text = "🥛 Organic Whole Milk 2L";
            // 
            // divider1
            // 
            this.divider1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(94)))), ((int)(((byte)(113)))));
            this.divider1.Location = new System.Drawing.Point(18, 86);
            this.divider1.Name = "divider1";
            this.divider1.Size = new System.Drawing.Size(389, 1);
            this.divider1.TabIndex = 2;
            // 
            // lblDateTime
            // 
            this.lblDateTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDateTime.AutoSize = true;
            this.lblDateTime.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblDateTime.ForeColor = System.Drawing.Color.Silver;
            this.lblDateTime.Location = new System.Drawing.Point(120, 54);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(215, 15);
            this.lblDateTime.TabIndex = 1;
            this.lblDateTime.Text = "Thursday, September 3, 2026 · 11:42 PM";
            this.lblDateTime.Click += new System.EventHandler(this.lblDate_Click);
            // 
            // lblStore
            // 
            this.lblStore.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblStore.AutoSize = true;
            this.lblStore.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold);
            this.lblStore.ForeColor = System.Drawing.Color.White;
            this.lblStore.Location = new System.Drawing.Point(111, 24);
            this.lblStore.Name = "lblStore";
            this.lblStore.Size = new System.Drawing.Size(209, 25);
            this.lblStore.TabIndex = 0;
            this.lblStore.Text = "FreshMart Supermarket";
            // 
            // lblPaymentMethod
            // 
            this.lblPaymentMethod.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPaymentMethod.AutoSize = true;
            this.lblPaymentMethod.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold);
            this.lblPaymentMethod.ForeColor = System.Drawing.Color.White;
            this.lblPaymentMethod.Location = new System.Drawing.Point(535, 92);
            this.lblPaymentMethod.Name = "lblPaymentMethod";
            this.lblPaymentMethod.Size = new System.Drawing.Size(169, 28);
            this.lblPaymentMethod.TabIndex = 3;
            this.lblPaymentMethod.Text = "Payment Method";
            // 
            // paymentPanel
            // 
            this.paymentPanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.paymentPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(47)))), ((int)(((byte)(67)))));
            this.paymentPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paymentPanel.Controls.Add(this.lblCardInfo);
            this.paymentPanel.Controls.Add(this.lblPaymentSub);
            this.paymentPanel.Controls.Add(this.lblCard);
            this.paymentPanel.Controls.Add(this.lblCardIcon);
            this.paymentPanel.Location = new System.Drawing.Point(540, 136);
            this.paymentPanel.Name = "paymentPanel";
            this.paymentPanel.Size = new System.Drawing.Size(330, 151);
            this.paymentPanel.TabIndex = 4;
            this.paymentPanel.Click += new System.EventHandler(this.paymentPanel_Click);
            this.paymentPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.paymentPanel_Paint);
            // 
            // lblPaymentSub
            // 
            this.lblPaymentSub.AutoSize = true;
            this.lblPaymentSub.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPaymentSub.ForeColor = System.Drawing.Color.Silver;
            this.lblPaymentSub.Location = new System.Drawing.Point(74, 87);
            this.lblPaymentSub.Name = "lblPaymentSub";
            this.lblPaymentSub.Size = new System.Drawing.Size(198, 15);
            this.lblPaymentSub.TabIndex = 2;
            this.lblPaymentSub.Text = "Terminal ready — awaiting payment";
            this.lblPaymentSub.Click += new System.EventHandler(this.lblPaymentSub_Click);
            // 
            // lblCard
            // 
            this.lblCard.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCard.AutoSize = true;
            this.lblCard.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.lblCard.ForeColor = System.Drawing.Color.White;
            this.lblCard.Location = new System.Drawing.Point(113, 67);
            this.lblCard.Name = "lblCard";
            this.lblCard.Size = new System.Drawing.Size(107, 20);
            this.lblCard.TabIndex = 1;
            this.lblCard.Text = "Add your card";
            // 
            // lblCardIcon
            // 
            this.lblCardIcon.AutoSize = true;
            this.lblCardIcon.Font = new System.Drawing.Font("Segoe UI Emoji", 27F);
            this.lblCardIcon.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(210)))), ((int)(((byte)(230)))));
            this.lblCardIcon.Location = new System.Drawing.Point(140, 3);
            this.lblCardIcon.Name = "lblCardIcon";
            this.lblCardIcon.Size = new System.Drawing.Size(69, 48);
            this.lblCardIcon.TabIndex = 0;
            this.lblCardIcon.Text = "💳";
            // 
            // receiptPanel
            // 
            this.receiptPanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.receiptPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(47)))), ((int)(((byte)(67)))));
            this.receiptPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.receiptPanel.Controls.Add(this.btnPrintReceipt);
            this.receiptPanel.Controls.Add(this.lblOr);
            this.receiptPanel.Controls.Add(this.txtReceiptContact);
            this.receiptPanel.Controls.Add(this.lblReceiptSub);
            this.receiptPanel.Controls.Add(this.lblReceiptOptions);
            this.receiptPanel.Location = new System.Drawing.Point(540, 303);
            this.receiptPanel.Name = "receiptPanel";
            this.receiptPanel.Size = new System.Drawing.Size(330, 190);
            this.receiptPanel.TabIndex = 5;
            // 
            // btnPrintReceipt
            // 
            this.btnPrintReceipt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPrintReceipt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(73)))), ((int)(((byte)(96)))));
            this.btnPrintReceipt.FlatAppearance.BorderSize = 0;
            this.btnPrintReceipt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrintReceipt.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnPrintReceipt.ForeColor = System.Drawing.Color.White;
            this.btnPrintReceipt.Location = new System.Drawing.Point(17, 133);
            this.btnPrintReceipt.Name = "btnPrintReceipt";
            this.btnPrintReceipt.Size = new System.Drawing.Size(294, 39);
            this.btnPrintReceipt.TabIndex = 4;
            this.btnPrintReceipt.Text = "🖨 Print Receipt";
            this.btnPrintReceipt.UseVisualStyleBackColor = false;
            this.btnPrintReceipt.Click += new System.EventHandler(this.btnPrintReceipt_Click);
            // 
            // lblOr
            // 
            this.lblOr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblOr.AutoSize = true;
            this.lblOr.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.lblOr.ForeColor = System.Drawing.Color.Silver;
            this.lblOr.Location = new System.Drawing.Point(145, 111);
            this.lblOr.Name = "lblOr";
            this.lblOr.Size = new System.Drawing.Size(46, 13);
            this.lblOr.TabIndex = 3;
            this.lblOr.Text = "— or —";
            // 
            // txtReceiptContact
            // 
            this.txtReceiptContact.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtReceiptContact.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(67)))), ((int)(((byte)(88)))));
            this.txtReceiptContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtReceiptContact.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtReceiptContact.ForeColor = System.Drawing.Color.White;
            this.txtReceiptContact.Location = new System.Drawing.Point(17, 78);
            this.txtReceiptContact.Name = "txtReceiptContact";
            this.txtReceiptContact.Size = new System.Drawing.Size(294, 25);
            this.txtReceiptContact.TabIndex = 2;
            this.txtReceiptContact.Text = "email@example.com or +27 00 000 0000";
            // 
            // lblReceiptSub
            // 
            this.lblReceiptSub.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblReceiptSub.AutoSize = true;
            this.lblReceiptSub.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblReceiptSub.ForeColor = System.Drawing.Color.Silver;
            this.lblReceiptSub.Location = new System.Drawing.Point(17, 50);
            this.lblReceiptSub.Name = "lblReceiptSub";
            this.lblReceiptSub.Size = new System.Drawing.Size(177, 15);
            this.lblReceiptSub.TabIndex = 1;
            this.lblReceiptSub.Text = "Send receipt to (email or phone)";
            this.lblReceiptSub.Click += new System.EventHandler(this.lblReceiptSub_Click);
            // 
            // lblReceiptOptions
            // 
            this.lblReceiptOptions.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblReceiptOptions.AutoSize = true;
            this.lblReceiptOptions.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.lblReceiptOptions.ForeColor = System.Drawing.Color.White;
            this.lblReceiptOptions.Location = new System.Drawing.Point(16, 18);
            this.lblReceiptOptions.Name = "lblReceiptOptions";
            this.lblReceiptOptions.Size = new System.Drawing.Size(116, 20);
            this.lblReceiptOptions.TabIndex = 0;
            this.lblReceiptOptions.Text = "Receipt Options";
            // 
            // btnCompleteTransaction
            // 
            this.btnCompleteTransaction.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCompleteTransaction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(184)))), ((int)(((byte)(82)))));
            this.btnCompleteTransaction.FlatAppearance.BorderSize = 0;
            this.btnCompleteTransaction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCompleteTransaction.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.btnCompleteTransaction.ForeColor = System.Drawing.Color.White;
            this.btnCompleteTransaction.Location = new System.Drawing.Point(540, 510);
            this.btnCompleteTransaction.Name = "btnCompleteTransaction";
            this.btnCompleteTransaction.Size = new System.Drawing.Size(330, 52);
            this.btnCompleteTransaction.TabIndex = 6;
            this.btnCompleteTransaction.Text = "Complete Transaction";
            this.btnCompleteTransaction.UseVisualStyleBackColor = false;
            this.btnCompleteTransaction.Click += new System.EventHandler(this.btnCompleteTransaction_Click);
            // 
            // lblCardInfo
            // 
            this.lblCardInfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCardInfo.AutoSize = true;
            this.lblCardInfo.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.lblCardInfo.ForeColor = System.Drawing.Color.White;
            this.lblCardInfo.Location = new System.Drawing.Point(113, 120);
            this.lblCardInfo.Name = "lblCardInfo";
            this.lblCardInfo.Size = new System.Drawing.Size(111, 20);
            this.lblCardInfo.TabIndex = 3;
            this.lblCardInfo.Text = "No card added";
            // 
            // frmCheckoutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(25)))), ((int)(((byte)(45)))));
            this.ClientSize = new System.Drawing.Size(1280, 720);
            this.Controls.Add(this.btnCompleteTransaction);
            this.Controls.Add(this.receiptPanel);
            this.Controls.Add(this.paymentPanel);
            this.Controls.Add(this.lblPaymentMethod);
            this.Controls.Add(this.orderPanel);
            this.Controls.Add(this.lblOrderSummary);
            this.Controls.Add(this.headerPanel);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmCheckoutForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FreshMart - Review & Pay";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.headerPanel.ResumeLayout(false);
            this.headerPanel.PerformLayout();
            this.orderPanel.ResumeLayout(false);
            this.orderPanel.PerformLayout();
            this.paymentPanel.ResumeLayout(false);
            this.paymentPanel.PerformLayout();
            this.receiptPanel.ResumeLayout(false);
            this.receiptPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel headerPanel;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblOrderSummary;
        private System.Windows.Forms.Panel orderPanel;
        private System.Windows.Forms.Label lblStore;
        private System.Windows.Forms.Label lblDateTime;
        private System.Windows.Forms.Label divider1;
        private System.Windows.Forms.Label lblMilk;
        private System.Windows.Forms.Label lblMilkSub;
        private System.Windows.Forms.Label lblMilkPrice;
        private System.Windows.Forms.Label lblEggs;
        private System.Windows.Forms.Label lblEggSub;
        private System.Windows.Forms.Label lblEggPrice;
        private System.Windows.Forms.Label lblApple;
        private System.Windows.Forms.Label lblAppleSub;
        private System.Windows.Forms.Label lblApplePrice;
        private System.Windows.Forms.Label divider2;
        private System.Windows.Forms.Label lblSubtotal;
        private System.Windows.Forms.Label lblSubtotalValue;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Label lblTaxValue;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblTotalValue;
        private System.Windows.Forms.Label lblPaymentMethod;
        private System.Windows.Forms.Panel paymentPanel;
        private System.Windows.Forms.Label lblCardIcon;
        private System.Windows.Forms.Label lblCard;
        private System.Windows.Forms.Label lblPaymentSub;
        private System.Windows.Forms.Panel receiptPanel;
        private System.Windows.Forms.Label lblReceiptOptions;
        private System.Windows.Forms.Label lblReceiptSub;
        private System.Windows.Forms.TextBox txtReceiptContact;
        private System.Windows.Forms.Label lblOr;
        private System.Windows.Forms.Button btnPrintReceipt;
        private System.Windows.Forms.Button btnCompleteTransaction;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label lblCardInfo;
    }
}
