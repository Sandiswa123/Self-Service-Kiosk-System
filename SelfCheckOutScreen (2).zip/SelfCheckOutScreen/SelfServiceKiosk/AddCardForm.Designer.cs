namespace FreshMart_AddCard
{
    partial class AddCardForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblSubtitle;
        private System.Windows.Forms.Panel pnlCardPreview;
        private System.Windows.Forms.Label lblPreviewBrand;
        private System.Windows.Forms.Label lblPreviewNumber;
        private System.Windows.Forms.Label lblPreviewName;
        private System.Windows.Forms.Label lblPreviewExpiry;
        private System.Windows.Forms.Label lblCardName;
        private System.Windows.Forms.TextBox txtCardName;
        private System.Windows.Forms.Label lblCardNumber;
        private System.Windows.Forms.TextBox txtCardNumber;
        private System.Windows.Forms.Label lblExpiry;
        private System.Windows.Forms.TextBox txtExpiry;
        private System.Windows.Forms.Label lblCVV;
        private System.Windows.Forms.TextBox txtCVV;
        private System.Windows.Forms.Button btnAddCard;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblSecure;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblSubtitle = new System.Windows.Forms.Label();
            this.pnlCardPreview = new System.Windows.Forms.Panel();
            this.lblPreviewBrand = new System.Windows.Forms.Label();
            this.lblPreviewNumber = new System.Windows.Forms.Label();
            this.lblPreviewName = new System.Windows.Forms.Label();
            this.lblPreviewExpiry = new System.Windows.Forms.Label();
            this.lblCardName = new System.Windows.Forms.Label();
            this.txtCardName = new System.Windows.Forms.TextBox();
            this.lblCardNumber = new System.Windows.Forms.Label();
            this.txtCardNumber = new System.Windows.Forms.TextBox();
            this.lblExpiry = new System.Windows.Forms.Label();
            this.txtExpiry = new System.Windows.Forms.TextBox();
            this.lblCVV = new System.Windows.Forms.Label();
            this.txtCVV = new System.Windows.Forms.TextBox();
            this.btnAddCard = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblSecure = new System.Windows.Forms.Label();
            this.pnlMain.SuspendLayout();
            this.pnlCardPreview.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(25)))), ((int)(((byte)(45)))));
            this.pnlMain.Controls.Add(this.lblTitle);
            this.pnlMain.Controls.Add(this.lblSubtitle);
            this.pnlMain.Controls.Add(this.pnlCardPreview);
            this.pnlMain.Controls.Add(this.lblCardName);
            this.pnlMain.Controls.Add(this.txtCardName);
            this.pnlMain.Controls.Add(this.lblCardNumber);
            this.pnlMain.Controls.Add(this.txtCardNumber);
            this.pnlMain.Controls.Add(this.lblExpiry);
            this.pnlMain.Controls.Add(this.txtExpiry);
            this.pnlMain.Controls.Add(this.lblCVV);
            this.pnlMain.Controls.Add(this.txtCVV);
            this.pnlMain.Controls.Add(this.btnAddCard);
            this.pnlMain.Controls.Add(this.btnCancel);
            this.pnlMain.Controls.Add(this.lblSecure);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Margin = new System.Windows.Forms.Padding(2);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(570, 528);
            this.pnlMain.TabIndex = 0;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblTitle.Location = new System.Drawing.Point(30, 20);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(159, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Add a Card";
            // 
            // lblSubtitle
            // 
            this.lblSubtitle.AutoSize = true;
            this.lblSubtitle.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSubtitle.ForeColor = System.Drawing.Color.Gray;
            this.lblSubtitle.Location = new System.Drawing.Point(32, 55);
            this.lblSubtitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSubtitle.Name = "lblSubtitle";
            this.lblSubtitle.Size = new System.Drawing.Size(322, 19);
            this.lblSubtitle.TabIndex = 1;
            this.lblSubtitle.Text = "Enter your card details to continue with your order.";
            // 
            // pnlCardPreview
            // 
            this.pnlCardPreview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(47)))), ((int)(((byte)(86)))));
            this.pnlCardPreview.Controls.Add(this.lblPreviewBrand);
            this.pnlCardPreview.Controls.Add(this.lblPreviewNumber);
            this.pnlCardPreview.Controls.Add(this.lblPreviewName);
            this.pnlCardPreview.Controls.Add(this.lblPreviewExpiry);
            this.pnlCardPreview.Location = new System.Drawing.Point(32, 85);
            this.pnlCardPreview.Margin = new System.Windows.Forms.Padding(2);
            this.pnlCardPreview.Name = "pnlCardPreview";
            this.pnlCardPreview.Size = new System.Drawing.Size(506, 118);
            this.pnlCardPreview.TabIndex = 2;
            // 
            // lblPreviewBrand
            // 
            this.lblPreviewBrand.AutoSize = true;
            this.lblPreviewBrand.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblPreviewBrand.ForeColor = System.Drawing.Color.White;
            this.lblPreviewBrand.Location = new System.Drawing.Point(15, 12);
            this.lblPreviewBrand.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPreviewBrand.Name = "lblPreviewBrand";
            this.lblPreviewBrand.Size = new System.Drawing.Size(124, 25);
            this.lblPreviewBrand.TabIndex = 0;
            this.lblPreviewBrand.Text = "FRESHMART";
            // 
            // lblPreviewNumber
            // 
            this.lblPreviewNumber.AutoSize = true;
            this.lblPreviewNumber.Font = new System.Drawing.Font("Consolas", 16F, System.Drawing.FontStyle.Bold);
            this.lblPreviewNumber.ForeColor = System.Drawing.Color.White;
            this.lblPreviewNumber.Location = new System.Drawing.Point(15, 50);
            this.lblPreviewNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPreviewNumber.Name = "lblPreviewNumber";
            this.lblPreviewNumber.Size = new System.Drawing.Size(240, 26);
            this.lblPreviewNumber.TabIndex = 1;
            this.lblPreviewNumber.Text = "0000 0000 0000 0000";
            // 
            // lblPreviewName
            // 
            this.lblPreviewName.AutoSize = true;
            this.lblPreviewName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPreviewName.ForeColor = System.Drawing.Color.White;
            this.lblPreviewName.Location = new System.Drawing.Point(15, 88);
            this.lblPreviewName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPreviewName.Name = "lblPreviewName";
            this.lblPreviewName.Size = new System.Drawing.Size(120, 15);
            this.lblPreviewName.TabIndex = 2;
            this.lblPreviewName.Text = "CARDHOLDER NAME";
            // 
            // lblPreviewExpiry
            // 
            this.lblPreviewExpiry.AutoSize = true;
            this.lblPreviewExpiry.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPreviewExpiry.ForeColor = System.Drawing.Color.White;
            this.lblPreviewExpiry.Location = new System.Drawing.Point(412, 88);
            this.lblPreviewExpiry.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPreviewExpiry.Name = "lblPreviewExpiry";
            this.lblPreviewExpiry.Size = new System.Drawing.Size(48, 15);
            this.lblPreviewExpiry.TabIndex = 3;
            this.lblPreviewExpiry.Text = "MM/YY";
            // 
            // lblCardName
            // 
            this.lblCardName.AutoSize = true;
            this.lblCardName.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblCardName.ForeColor = System.Drawing.Color.White;
            this.lblCardName.Location = new System.Drawing.Point(32, 219);
            this.lblCardName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCardName.Name = "lblCardName";
            this.lblCardName.Size = new System.Drawing.Size(104, 15);
            this.lblCardName.TabIndex = 3;
            this.lblCardName.Text = "Cardholder Name";
            this.lblCardName.Click += new System.EventHandler(this.lblCardName_Click);
            // 
            // txtCardName
            // 
            this.txtCardName.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtCardName.Location = new System.Drawing.Point(32, 239);
            this.txtCardName.Margin = new System.Windows.Forms.Padding(2);
            this.txtCardName.MaxLength = 50;
            this.txtCardName.Name = "txtCardName";
            this.txtCardName.Size = new System.Drawing.Size(506, 27);
            this.txtCardName.TabIndex = 4;
            this.txtCardName.TextChanged += new System.EventHandler(this.txtCardName_TextChanged);
            // 
            // lblCardNumber
            // 
            this.lblCardNumber.AutoSize = true;
            this.lblCardNumber.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblCardNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblCardNumber.Location = new System.Drawing.Point(32, 274);
            this.lblCardNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCardNumber.Name = "lblCardNumber";
            this.lblCardNumber.Size = new System.Drawing.Size(81, 15);
            this.lblCardNumber.TabIndex = 5;
            this.lblCardNumber.Text = "Card Number";
            // 
            // txtCardNumber
            // 
            this.txtCardNumber.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtCardNumber.Location = new System.Drawing.Point(32, 293);
            this.txtCardNumber.Margin = new System.Windows.Forms.Padding(2);
            this.txtCardNumber.MaxLength = 19;
            this.txtCardNumber.Name = "txtCardNumber";
            this.txtCardNumber.Size = new System.Drawing.Size(506, 27);
            this.txtCardNumber.TabIndex = 6;
            this.txtCardNumber.TextChanged += new System.EventHandler(this.txtCardNumber_TextChanged);
            // 
            // lblExpiry
            // 
            this.lblExpiry.AutoSize = true;
            this.lblExpiry.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblExpiry.ForeColor = System.Drawing.Color.White;
            this.lblExpiry.Location = new System.Drawing.Point(32, 330);
            this.lblExpiry.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblExpiry.Name = "lblExpiry";
            this.lblExpiry.Size = new System.Drawing.Size(71, 15);
            this.lblExpiry.TabIndex = 7;
            this.lblExpiry.Text = "Expiry Date";
            // 
            // txtExpiry
            // 
            this.txtExpiry.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtExpiry.Location = new System.Drawing.Point(32, 349);
            this.txtExpiry.Margin = new System.Windows.Forms.Padding(2);
            this.txtExpiry.MaxLength = 5;
            this.txtExpiry.Name = "txtExpiry";
            this.txtExpiry.Size = new System.Drawing.Size(241, 27);
            this.txtExpiry.TabIndex = 8;
            this.txtExpiry.TextChanged += new System.EventHandler(this.txtExpiry_TextChanged);
            // 
            // lblCVV
            // 
            this.lblCVV.AutoSize = true;
            this.lblCVV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblCVV.ForeColor = System.Drawing.Color.White;
            this.lblCVV.Location = new System.Drawing.Point(298, 330);
            this.lblCVV.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCVV.Name = "lblCVV";
            this.lblCVV.Size = new System.Drawing.Size(30, 15);
            this.lblCVV.TabIndex = 9;
            this.lblCVV.Text = "CVV";
            // 
            // txtCVV
            // 
            this.txtCVV.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtCVV.Location = new System.Drawing.Point(298, 349);
            this.txtCVV.Margin = new System.Windows.Forms.Padding(2);
            this.txtCVV.MaxLength = 3;
            this.txtCVV.Name = "txtCVV";
            this.txtCVV.PasswordChar = '*';
            this.txtCVV.Size = new System.Drawing.Size(241, 27);
            this.txtCVV.TabIndex = 10;
            this.txtCVV.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCVV_KeyPress);
            // 
            // btnAddCard
            // 
            this.btnAddCard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(47)))), ((int)(((byte)(86)))));
            this.btnAddCard.FlatAppearance.BorderSize = 0;
            this.btnAddCard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddCard.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnAddCard.ForeColor = System.Drawing.Color.White;
            this.btnAddCard.Location = new System.Drawing.Point(32, 398);
            this.btnAddCard.Margin = new System.Windows.Forms.Padding(2);
            this.btnAddCard.Name = "btnAddCard";
            this.btnAddCard.Size = new System.Drawing.Size(506, 37);
            this.btnAddCard.TabIndex = 11;
            this.btnAddCard.Text = "Add Card";
            this.btnAddCard.UseVisualStyleBackColor = false;
            this.btnAddCard.Click += new System.EventHandler(this.btnAddCard_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(47)))), ((int)(((byte)(86)))));
            this.btnCancel.Location = new System.Drawing.Point(225, 445);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(120, 28);
            this.btnCancel.TabIndex = 12;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblSecure
            // 
            this.lblSecure.AutoSize = true;
            this.lblSecure.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblSecure.ForeColor = System.Drawing.Color.Gray;
            this.lblSecure.Location = new System.Drawing.Point(202, 488);
            this.lblSecure.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSecure.Name = "lblSecure";
            this.lblSecure.Size = new System.Drawing.Size(170, 15);
            this.lblSecure.TabIndex = 13;
            this.lblSecure.Text = "Your card details are protected.";
            // 
            // AddCardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(570, 528);
            this.Controls.Add(this.pnlMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddCardForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FreshMart - Add Card";
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.pnlCardPreview.ResumeLayout(false);
            this.pnlCardPreview.PerformLayout();
            this.ResumeLayout(false);

        }
    }
}
