using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SelfServiceKiosk")]
[assembly: AssemblyDescription("Editable Windows Forms self-service kiosk payment screen")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SelfServiceKiosk")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("8c377a9a-7e32-41c0-94fc-1e59db77db2f")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
