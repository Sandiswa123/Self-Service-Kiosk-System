﻿# FreshMart Self-Service Kiosk

A self-service supermarket kiosk with an admin dashboard, built with
C# Windows Forms (.NET Framework 4.7.2) and a **SQLite** database.

## Running the project

1. Open `FreshMartKiosk.sln` in Visual Studio 2019 or 2022.
2. Restore NuGet packages, then press **F5**. The project uses `System.Data.SQLite.Core`
  and `PDFsharp` (an internet connection is needed for the initial restore).
3. The database is created automatically on first run — no setup required.

If the build says the package is missing: right-click the solution →
**Restore NuGet Packages**, then rebuild.

## Admin login

| Username | Password   |
|----------|------------|
| `Admin`  | `12345`    |

Click **Admin Access** (bottom-right of the welcome screen).
"Change now" on the login screen changes a password; it needs the current password.

## Customer sign-up and login

The working kiosk now has a customer account gate before shopping:

1. Click **TAP TO SIGN IN & START SHOPPING**.
2. Existing customers log in with their **username or email + password**.
3. New customers click **NEW CUSTOMER? CREATE AN ACCOUNT**, enter full name, email, username and password, and are signed in immediately after successful registration.
4. Closing/cancelling/completing the shopping session signs the customer out before returning to the welcome screen.

Customer passwords are salted and hashed with PBKDF2; plain-text customer passwords are never stored.

## Receipts

After payment is recorded, click **Save PDF & Send Receipt** and choose a location for
the PDF. The PDF is attached to an email; when a phone number is entered instead, the
full receipt is sent by SMS. If the contact field is left empty, the signed-in
customer's email address is used. Receipts include customer identity, transaction and
payment information, every product, quantity, unit price, line total, VAT and grand total.

Configure these Windows environment variables on the kiosk for email delivery:

| Variable | Value |
|----------|-------|
| `FRESHMART_SMTP_HOST` | SMTP server hostname |
| `FRESHMART_SMTP_PORT` | SMTP port (default `587`) |
| `FRESHMART_SMTP_SSL` | `true` or `false` (default `true`) |
| `FRESHMART_SMTP_USERNAME` | SMTP login username |
| `FRESHMART_SMTP_PASSWORD` | SMTP password or app password |
| `FRESHMART_SMTP_FROM` | Sender email address |

Configure these variables for SMS delivery through Twilio:

| Variable | Value |
|----------|-------|
| `TWILIO_ACCOUNT_SID` | Twilio account SID |
| `TWILIO_AUTH_TOKEN` | Twilio auth token |
| `TWILIO_FROM_NUMBER` | Twilio-enabled sending number in E.164 format |

Keep credentials in Windows Environment Variables, not in source code. Start the kiosk
after setting them so the process receives the new values.

## Help assistant (floating "?" button)

Every screen has a small round green **?** button in the bottom-left corner (you can also press **F1**).
It opens a help chat on top of the current screen. The chat starts on the topic that matches the screen
(sign-in, shopping, checkout or admin) and answers only questions about what the kiosk offers.
Customers can tap a suggested question, switch topic, or type their own question. **Esc** or **Close** returns to the screen.

Screens with the button: Welcome, Customer Login, Create Account, Shopping, Checkout, Add Card,
Admin Login, Change Password, Admin dashboard and Analytics. (The brief Restart and Shut Down screens do not have it.)

To change what it says, edit `Help\HelpKnowledge.cs` (one entry per question: category, question, keywords, answer).
To add it to a new screen, put one line at the end of that form's constructor:

    HelpAssistant.Attach(this, HelpKnowledge.Shopping);   // or GettingStarted / Checkout / Staff

## How the screens connect

    Welcome ──> Customer Login ──> Shopping ──> Checkout ──(paid / cancelled)──> Welcome
                    │
                    └──> Create Account ──(success)──> Shopping
       │
       └──"Admin Access"──> Admin Login ──> Admin dashboard ──> Welcome
                                                   ├─ Stock Management
                                                   ├─ Analytics (by hour / day / month)
                                                   └─ System Control (restart / shut down)

The welcome screen is the main window; press **Alt+F4** on it to quit.

## Database

File: `Documents\FreshMart\freshmart.db` (Documents is used because Program Files
is read-only for normal Windows users). Full schema: `Docs\database-schema.sql`.

| Table              | Holds                                   | Key points                                   |
|--------------------|-----------------------------------------|----------------------------------------------|
| `Products`         | 16 products, stock, availability        | PK `ProductId`; CHECK stock ≥ 0              |
| `Transactions`     | one row per completed sale              | unique readable number `TXN-20260922-00001`  |
| `TransactionItems` | products in each sale                   | FKs to `Transactions` and `Products`         |
| `Users`            | admin logins                            | salted PBKDF2 hash — no plain-text passwords |
| `CustomerAccounts` | customer sign-up/login accounts          | unique email + username; salted PBKDF2 hash  |

Design decisions:

* **Money is stored as whole cents (INTEGER)** — SQLite has no exact decimal type,
  and floating point would cause rounding errors.
* **A sale is one database transaction.** Stock is reduced *only if* the item is still
  available and in stock; then the sale and its line items are inserted. If any step
  fails the whole sale is rolled back, so stock and sales can never disagree.
* **All SQL uses parameters** (`@id`, `@qty`, …) — no string concatenation, so no SQL injection.
* **Foreign keys are switched on** for every connection (SQLite has them off by default).
* Only `Data\SqliteProvider.cs` mentions the SQLite library; everything else uses the
  standard ADO.NET classes (`DbConnection`, `DbCommand`, `DbDataReader`).

To reset all data, close the app and delete `freshmart.db`. It is recreated with
16 products (50 in stock each) and the default admin account.

Data from the earlier text-file version (`inventory.txt`, `transactions.txt`, user files)
is imported automatically the first time, and the old files are renamed to `*.imported`.

## Project layout

| Path                   | Purpose                                                  |
|------------------------|----------------------------------------------------------|
| `Data\Database.cs`     | Connection, table creation, seeding, one-time import     |
| `Data\DataStore.cs`    | Products, sales and transaction queries                  |
| `Data\SqliteProvider.cs` | The single line that creates a SQLite connection       |
| `FormWelcome`, `FormKiosk`, `CheckoutForm`, `AddCardForm` | Customer screens      |
| `ShoppingCart.cs`, `Product.cs`, `CartItem.cs` | Cart rules (max 10 items, stock limits, VAT) |
| `Login\`               | Admin login and admin password changes                   |
| `CustomerAuth\`        | Customer sign-up, login, session and secure auth service |
| `Admin\`               | Dashboard, analytics, restart, shutdown screens          |
| `Images\`              | Banner and product photos, and `Images\Admin` icons (copied next to the .exe) |
| `AppImages.cs`         | Loads those images at runtime                            |
| `Help\`                | Help assistant: floating ? button, chat window, question bank |

## Test checklist

| # | Do this | Expected |
|---|---------|----------|
| 1 | Start the app | Welcome screen with rotating banner and live clock |
| 2 | Tap to start | Customer login screen appears before shopping |
| 3 | Create a new customer account | Account is saved to SQLite and shopping opens |
| 4 | Return to welcome, start again, log in with that account | Login succeeds and shopping opens |
| 5 | Click a product | Added to cart; totals and VAT update |
| 6 | Type `P999` and press Enter | "No product found" message (no crash) |
| 7 | Add 11 items | "Cart limit reached! Max 10 items only." |
| 8 | Use `−` and `X` in the cart | Removes one unit / the whole line |
| 9 | Checkout → Complete without a card | "Please add a card…" |
| 10 | Add card `4111 1111 1111 1111`, a future expiry, any 3-digit CVV → Complete → Save PDF & Send Receipt | PDF saved; receipt emailed or texted to the selected contact |
| 11 | Admin Access → wrong password 5 times | Login closes |
| 12 | Log in as admin | Dashboard: transaction count and revenue include the sale from step 10 |
| 13 | Stock Management → set a product Unavailable → Exit Admin → shop | Product shows SOLD OUT |
| 14 | Switch it back to Available | Product can be bought again |
| 15 | Analytics → By Hour / Day / Month | Sale from step 10 listed with correct totals |
| 16 | Change password without the current password | Refused |
| 17 | On any screen click the green **?** (or press F1), pick a suggested question, type `how do I add a card`, then press Esc | Chat opens, answers appear, window closes and the screen is unchanged |

## Notes

* All pictures are normal image files, none are stored inside `.resx` files. This is on purpose:
  Visual Studio refuses to build `.resx` files containing images when a project has been
  downloaded ("mark of the web" error), so keeping them as files means a downloaded copy builds first time.

* VAT: prices are treated as **excluding** VAT and 15% is added at checkout.
  (South African shelf prices usually include VAT — change `CalculateVat` in
  `ShoppingCart.cs` if your brief requires VAT-inclusive prices.)
* Card payment is simulated; no real payment is made. Receipt email and SMS use the configured SMTP and Twilio accounts.
