﻿-- FreshMart Self-Service Kiosk - SQLite database schema
-- The application creates these tables automatically on first run
-- (see FreshMartKiosk/Data/Database.cs). This file is for documentation.
--
-- Location: Documents\FreshMart\freshmart.db
-- Money columns are INTEGER cents (R 32.99 is stored as 3299).
--
--   Products 1 ──< TransactionItems >── 1 Transactions
--   Users (stand-alone admin accounts)
--   CustomerAccounts (stand-alone customer accounts)

CREATE TABLE IF NOT EXISTS Products (
    ProductId    TEXT    PRIMARY KEY,
    ProductName  TEXT    NOT NULL,
    Category     TEXT    NOT NULL,
    PriceCents   INTEGER NOT NULL CHECK (PriceCents >= 0),
    Barcode      TEXT    NOT NULL UNIQUE,
    Stock        INTEGER NOT NULL DEFAULT 50 CHECK (Stock >= 0),
    IsAvailable  INTEGER NOT NULL DEFAULT 1  CHECK (IsAvailable IN (0, 1))
);

CREATE TABLE IF NOT EXISTS Transactions (
    TransactionId     INTEGER PRIMARY KEY AUTOINCREMENT,
    TransactionNumber TEXT    NOT NULL UNIQUE,
    CreatedAt         TEXT    NOT NULL,          -- 'yyyy-MM-dd HH:mm:ss' local time
    SubtotalCents     INTEGER NOT NULL,
    VatCents          INTEGER NOT NULL,
    TotalCents        INTEGER NOT NULL,
    ItemCount         INTEGER NOT NULL CHECK (ItemCount >= 0),
    ReceiptContact    TEXT    NULL
);

CREATE INDEX IF NOT EXISTS IX_Transactions_CreatedAt ON Transactions (CreatedAt);

CREATE TABLE IF NOT EXISTS TransactionItems (
    TransactionId  INTEGER NOT NULL REFERENCES Transactions (TransactionId) ON DELETE CASCADE,
    ProductId      TEXT    NOT NULL REFERENCES Products (ProductId),
    Quantity       INTEGER NOT NULL CHECK (Quantity > 0),
    UnitPriceCents INTEGER NOT NULL,
    PRIMARY KEY (TransactionId, ProductId)
);

CREATE TABLE IF NOT EXISTS Users (
    Username     TEXT PRIMARY KEY COLLATE NOCASE,
    PasswordSalt TEXT NOT NULL,
    PasswordHash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS CustomerAccounts (
    CustomerId   INTEGER PRIMARY KEY AUTOINCREMENT,
    FullName     TEXT    NOT NULL,
    Email        TEXT    NOT NULL COLLATE NOCASE UNIQUE,
    Username     TEXT    NOT NULL COLLATE NOCASE UNIQUE,
    PasswordSalt TEXT    NOT NULL,
    PasswordHash TEXT    NOT NULL,
    CreatedAt    TEXT    NOT NULL,
    LastLoginAt  TEXT    NULL
);

-- Useful queries ---------------------------------------------------------

-- Today's sales
-- SELECT TransactionNumber, CreatedAt, TotalCents / 100.0 AS Total
-- FROM Transactions WHERE date(CreatedAt) = date('now', 'localtime');

-- Best sellers
-- SELECT p.ProductName, SUM(i.Quantity) AS Sold
-- FROM TransactionItems i JOIN Products p ON p.ProductId = i.ProductId
-- GROUP BY p.ProductId ORDER BY Sold DESC;
