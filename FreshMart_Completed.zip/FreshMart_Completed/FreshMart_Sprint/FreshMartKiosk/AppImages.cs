using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace FreshMartKiosk
{
    /// <summary>
    /// Loads pictures from the Images folder next to the .exe.
    ///
    /// Images are kept as normal files rather than inside .resx files on purpose:
    /// Visual Studio refuses to build .resx files that contain images when the project
    /// was downloaded ("mark of the web"), which would stop a downloaded copy building.
    /// </summary>
    public static class AppImages
    {
        /// <summary>
        /// Returns the image, or null if the file is missing or unreadable.
        /// Example: AppImages.Load("Admin", "exit.png") reads Images\Admin\exit.png
        /// </summary>
        public static Image Load(params string[] pathInsideImagesFolder)
        {
            string path = Path.Combine(Application.StartupPath, "Images");
            foreach (string part in pathInsideImagesFolder)
                path = Path.Combine(path, part);
            if (!File.Exists(path)) return null;

            try
            {
                // Copy into memory so the file isn't locked while the app runs.
                using (var fromDisk = new Bitmap(path))
                    return new Bitmap(fromDisk);
            }
            catch (ArgumentException)
            {
                return null;
            }
        }
    }
}
