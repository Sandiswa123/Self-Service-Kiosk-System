namespace FreshMartKiosk
{
    partial class CheckoutForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.headerPanel = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblHeader = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblOrderSummary = new System.Windows.Forms.Label();
            this.orderPanel = new System.Windows.Forms.Panel();
            this.totalsPanel = new System.Windows.Forms.Panel();
            this.lblTotalValue = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblTaxValue = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.lblSubtotalValue = new System.Windows.Forms.Label();
            this.lblSubtotal = new System.Windows.Forms.Label();
            this.divider2 = new System.Windows.Forms.Label();
            this.itemsFlow = new System.Windows.Forms.FlowLayoutPanel();
            this.storeHeaderPanel = new System.Windows.Forms.Panel();
            this.divider1 = new System.Windows.Forms.Label();
            this.lblDateTime = new System.Windows.Forms.Label();
            this.lblStore = new System.Windows.Forms.Label();
            this.lblPaymentMethod = new System.Windows.Forms.Label();
            this.paymentPanel = new System.Windows.Forms.Panel();
            this.lblCardInfo = new System.Windows.Forms.Label();
            this.lblPaymentSub = new System.Windows.Forms.Label();
            this.lblCard = new System.Windows.Forms.Label();
            this.lblCardIcon = new System.Windows.Forms.Label();
            this.receiptPanel = new System.Windows.Forms.Panel();
            this.btnPrintReceipt = new System.Windows.Forms.Button();
            this.lblOr = new System.Windows.Forms.Label();
            this.txtReceiptContact = new System.Windows.Forms.TextBox();
            this.lblReceiptSub = new System.Windows.Forms.Label();
            this.lblReceiptOptions = new System.Windows.Forms.Label();
            this.btnCompleteTransaction = new System.Windows.Forms.Button();
            this.headerPanel.SuspendLayout();
            this.orderPanel.SuspendLayout();
            this.totalsPanel.SuspendLayout();
            this.storeHeaderPanel.SuspendLayout();
            this.paymentPanel.SuspendLayout();
            this.receiptPanel.SuspendLayout();
            this.SuspendLayout();
            //
            // headerPanel
            //
            this.headerPanel.BackColor = System.Drawing.Color.FromArgb(30, 46, 66);
            this.headerPanel.Controls.Add(this.btnCancel);
            this.headerPanel.Controls.Add(this.lblHeader);
            this.headerPanel.Controls.Add(this.btnBack);
            this.headerPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerPanel.Location = new System.Drawing.Point(0, 0);
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.Size = new System.Drawing.Size(1280, 58);
            this.headerPanel.TabIndex = 0;
            //
            // btnCancel
            //
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(255, 98, 98);
            this.btnCancel.Location = new System.Drawing.Point(1192, 12);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(76, 34);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            //
            // lblHeader
            //
            this.lblHeader.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.White;
            this.lblHeader.Location = new System.Drawing.Point(592, 17);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(125, 21);
            this.lblHeader.TabIndex = 1;
            this.lblHeader.Text = "Review And Pay";
            //
            // btnBack
            //
            this.btnBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnBack.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnBack.Location = new System.Drawing.Point(18, 11);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(115, 35);
            this.btnBack.TabIndex = 0;
            this.btnBack.Text = "← Back to Cart";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            //
            // lblOrderSummary
            //
            this.lblOrderSummary.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblOrderSummary.AutoSize = true;
            this.lblOrderSummary.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold);
            this.lblOrderSummary.ForeColor = System.Drawing.Color.White;
            this.lblOrderSummary.Location = new System.Drawing.Point(68, 92);
            this.lblOrderSummary.Name = "lblOrderSummary";
            this.lblOrderSummary.Size = new System.Drawing.Size(157, 28);
            this.lblOrderSummary.TabIndex = 1;
            this.lblOrderSummary.Text = "Order Summary";
            //
            // orderPanel (now holds: storeHeaderPanel [top] / itemsFlow [fill, scrolls] / totalsPanel [bottom])
            //
            this.orderPanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.orderPanel.BackColor = System.Drawing.Color.FromArgb(31, 47, 67);
            this.orderPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.orderPanel.Controls.Add(this.itemsFlow);
            this.orderPanel.Controls.Add(this.totalsPanel);
            this.orderPanel.Controls.Add(this.storeHeaderPanel);
            this.orderPanel.Location = new System.Drawing.Point(72, 136);
            this.orderPanel.Name = "orderPanel";
            this.orderPanel.Size = new System.Drawing.Size(430, 460);
            this.orderPanel.TabIndex = 2;
            //
            // storeHeaderPanel
            //
            this.storeHeaderPanel.Controls.Add(this.lblStore);
            this.storeHeaderPanel.Controls.Add(this.lblDateTime);
            this.storeHeaderPanel.Controls.Add(this.divider1);
            this.storeHeaderPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.storeHeaderPanel.Height = 88;
            this.storeHeaderPanel.Name = "storeHeaderPanel";
            this.storeHeaderPanel.TabIndex = 0;
            //
            // divider1
            //
            this.divider1.BackColor = System.Drawing.Color.FromArgb(77, 94, 113);
            this.divider1.Location = new System.Drawing.Point(18, 86);
            this.divider1.Name = "divider1";
            this.divider1.Size = new System.Drawing.Size(389, 1);
            this.divider1.TabIndex = 2;
            //
            // lblDateTime
            //
            this.lblDateTime.AutoSize = true;
            this.lblDateTime.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblDateTime.ForeColor = System.Drawing.Color.Silver;
            this.lblDateTime.Location = new System.Drawing.Point(18, 54);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(215, 15);
            this.lblDateTime.TabIndex = 1;
            this.lblDateTime.Text = "Thursday, September 3, 2026 · 11:42 PM";
            this.lblDateTime.Click += new System.EventHandler(this.lblDate_Click);
            //
            // lblStore
            //
            this.lblStore.AutoSize = true;
            this.lblStore.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold);
            this.lblStore.ForeColor = System.Drawing.Color.White;
            this.lblStore.Location = new System.Drawing.Point(18, 20);
            this.lblStore.Name = "lblStore";
            this.lblStore.Size = new System.Drawing.Size(209, 25);
            this.lblStore.TabIndex = 0;
            this.lblStore.Text = "FreshMart Supermarket";
            //
            // itemsFlow (one row generated per cart item at runtime)
            //
            this.itemsFlow.AutoScroll = true;
            this.itemsFlow.BackColor = System.Drawing.Color.FromArgb(31, 47, 67);
            this.itemsFlow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.itemsFlow.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.itemsFlow.WrapContents = false;
            this.itemsFlow.Name = "itemsFlow";
            this.itemsFlow.Padding = new System.Windows.Forms.Padding(18, 8, 12, 8);
            this.itemsFlow.TabIndex = 1;
            //
            // totalsPanel
            //
            this.totalsPanel.Controls.Add(this.divider2);
            this.totalsPanel.Controls.Add(this.lblSubtotal);
            this.totalsPanel.Controls.Add(this.lblSubtotalValue);
            this.totalsPanel.Controls.Add(this.lblTax);
            this.totalsPanel.Controls.Add(this.lblTaxValue);
            this.totalsPanel.Controls.Add(this.lblTotal);
            this.totalsPanel.Controls.Add(this.lblTotalValue);
            this.totalsPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.totalsPanel.Height = 110;
            this.totalsPanel.Name = "totalsPanel";
            this.totalsPanel.TabIndex = 2;
            //
            // divider2
            //
            this.divider2.BackColor = System.Drawing.Color.FromArgb(77, 94, 113);
            this.divider2.Location = new System.Drawing.Point(18, 4);
            this.divider2.Name = "divider2";
            this.divider2.Size = new System.Drawing.Size(389, 1);
            this.divider2.TabIndex = 0;
            //
            // lblSubtotal
            //
            this.lblSubtotal.AutoSize = true;
            this.lblSubtotal.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSubtotal.ForeColor = System.Drawing.Color.Silver;
            this.lblSubtotal.Location = new System.Drawing.Point(18, 18);
            this.lblSubtotal.Name = "lblSubtotal";
            this.lblSubtotal.Size = new System.Drawing.Size(60, 19);
            this.lblSubtotal.TabIndex = 1;
            this.lblSubtotal.Text = "Subtotal";
            //
            // lblSubtotalValue
            //
            this.lblSubtotalValue.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSubtotalValue.ForeColor = System.Drawing.Color.Silver;
            this.lblSubtotalValue.Location = new System.Drawing.Point(305, 18);
            this.lblSubtotalValue.Name = "lblSubtotalValue";
            this.lblSubtotalValue.Size = new System.Drawing.Size(102, 20);
            this.lblSubtotalValue.TabIndex = 2;
            this.lblSubtotalValue.Text = "R 0.00";
            this.lblSubtotalValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            //
            // lblTax
            //
            this.lblTax.AutoSize = true;
            this.lblTax.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTax.ForeColor = System.Drawing.Color.Silver;
            this.lblTax.Location = new System.Drawing.Point(18, 44);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(93, 19);
            this.lblTax.TabIndex = 3;
            this.lblTax.Text = "Tax (15% VAT)";
            //
            // lblTaxValue
            //
            this.lblTaxValue.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTaxValue.ForeColor = System.Drawing.Color.Silver;
            this.lblTaxValue.Location = new System.Drawing.Point(305, 44);
            this.lblTaxValue.Name = "lblTaxValue";
            this.lblTaxValue.Size = new System.Drawing.Size(102, 20);
            this.lblTaxValue.TabIndex = 4;
            this.lblTaxValue.Text = "R 0.00";
            this.lblTaxValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            //
            // lblTotal
            //
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold);
            this.lblTotal.ForeColor = System.Drawing.Color.White;
            this.lblTotal.Location = new System.Drawing.Point(18, 74);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(69, 28);
            this.lblTotal.TabIndex = 5;
            this.lblTotal.Text = "TOTAL";
            //
            // lblTotalValue
            //
            this.lblTotalValue.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold);
            this.lblTotalValue.ForeColor = System.Drawing.Color.White;
            this.lblTotalValue.Location = new System.Drawing.Point(285, 73);
            this.lblTotalValue.Name = "lblTotalValue";
            this.lblTotalValue.Size = new System.Drawing.Size(122, 30);
            this.lblTotalValue.TabIndex = 6;
            this.lblTotalValue.Text = "R 0.00";
            this.lblTotalValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            //
            // lblPaymentMethod
            //
            this.lblPaymentMethod.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPaymentMethod.AutoSize = true;
            this.lblPaymentMethod.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold);
            this.lblPaymentMethod.ForeColor = System.Drawing.Color.White;
            this.lblPaymentMethod.Location = new System.Drawing.Point(535, 92);
            this.lblPaymentMethod.Name = "lblPaymentMethod";
            this.lblPaymentMethod.Size = new System.Drawing.Size(169, 28);
            this.lblPaymentMethod.TabIndex = 3;
            this.lblPaymentMethod.Text = "Payment Method";
            //
            // paymentPanel
            //
            this.paymentPanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.paymentPanel.BackColor = System.Drawing.Color.FromArgb(31, 47, 67);
            this.paymentPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paymentPanel.Controls.Add(this.lblCardInfo);
            this.paymentPanel.Controls.Add(this.lblPaymentSub);
            this.paymentPanel.Controls.Add(this.lblCard);
            this.paymentPanel.Controls.Add(this.lblCardIcon);
            this.paymentPanel.Location = new System.Drawing.Point(540, 136);
            this.paymentPanel.Name = "paymentPanel";
            this.paymentPanel.Size = new System.Drawing.Size(330, 151);
            this.paymentPanel.TabIndex = 4;
            this.paymentPanel.Click += new System.EventHandler(this.paymentPanel_Click);
            this.paymentPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.paymentPanel_Paint);
            //
            // lblCardInfo
            //
            this.lblCardInfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCardInfo.AutoSize = true;
            this.lblCardInfo.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.lblCardInfo.ForeColor = System.Drawing.Color.White;
            this.lblCardInfo.Location = new System.Drawing.Point(113, 120);
            this.lblCardInfo.Name = "lblCardInfo";
            this.lblCardInfo.Size = new System.Drawing.Size(111, 20);
            this.lblCardInfo.TabIndex = 3;
            this.lblCardInfo.Text = "No card added";
            //
            // lblPaymentSub
            //
            this.lblPaymentSub.AutoSize = true;
            this.lblPaymentSub.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPaymentSub.ForeColor = System.Drawing.Color.Silver;
            this.lblPaymentSub.Location = new System.Drawing.Point(74, 87);
            this.lblPaymentSub.Name = "lblPaymentSub";
            this.lblPaymentSub.Size = new System.Drawing.Size(198, 15);
            this.lblPaymentSub.TabIndex = 2;
            this.lblPaymentSub.Text = "Terminal ready — awaiting payment";
            this.lblPaymentSub.Click += new System.EventHandler(this.lblPaymentSub_Click);
            //
            // lblCard
            //
            this.lblCard.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCard.AutoSize = true;
            this.lblCard.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.lblCard.ForeColor = System.Drawing.Color.White;
            this.lblCard.Location = new System.Drawing.Point(113, 67);
            this.lblCard.Name = "lblCard";
            this.lblCard.Size = new System.Drawing.Size(107, 20);
            this.lblCard.TabIndex = 1;
            this.lblCard.Text = "Add your card";
            //
            // lblCardIcon
            //
            this.lblCardIcon.AutoSize = true;
            this.lblCardIcon.Font = new System.Drawing.Font("Segoe UI Emoji", 27F);
            this.lblCardIcon.ForeColor = System.Drawing.Color.FromArgb(70, 210, 230);
            this.lblCardIcon.Location = new System.Drawing.Point(140, 3);
            this.lblCardIcon.Name = "lblCardIcon";
            this.lblCardIcon.Size = new System.Drawing.Size(69, 48);
            this.lblCardIcon.TabIndex = 0;
            this.lblCardIcon.Text = "💳";
            //
            // receiptPanel
            //
            this.receiptPanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.receiptPanel.BackColor = System.Drawing.Color.FromArgb(31, 47, 67);
            this.receiptPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.receiptPanel.Controls.Add(this.btnPrintReceipt);
            this.receiptPanel.Controls.Add(this.lblOr);
            this.receiptPanel.Controls.Add(this.txtReceiptContact);
            this.receiptPanel.Controls.Add(this.lblReceiptSub);
            this.receiptPanel.Controls.Add(this.lblReceiptOptions);
            this.receiptPanel.Location = new System.Drawing.Point(540, 303);
            this.receiptPanel.Name = "receiptPanel";
            this.receiptPanel.Size = new System.Drawing.Size(330, 190);
            this.receiptPanel.TabIndex = 5;
            //
            // btnPrintReceipt
            //
            this.btnPrintReceipt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPrintReceipt.BackColor = System.Drawing.Color.FromArgb(55, 73, 96);
            this.btnPrintReceipt.FlatAppearance.BorderSize = 0;
            this.btnPrintReceipt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrintReceipt.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnPrintReceipt.ForeColor = System.Drawing.Color.White;
            this.btnPrintReceipt.Location = new System.Drawing.Point(17, 133);
            this.btnPrintReceipt.Name = "btnPrintReceipt";
            this.btnPrintReceipt.Size = new System.Drawing.Size(294, 39);
            this.btnPrintReceipt.TabIndex = 4;
            this.btnPrintReceipt.Text = "🖨 Print Receipt";
            this.btnPrintReceipt.UseVisualStyleBackColor = false;
            this.btnPrintReceipt.Click += new System.EventHandler(this.btnPrintReceipt_Click);
            //
            // lblOr
            //
            this.lblOr.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblOr.AutoSize = true;
            this.lblOr.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.lblOr.ForeColor = System.Drawing.Color.Silver;
            this.lblOr.Location = new System.Drawing.Point(145, 111);
            this.lblOr.Name = "lblOr";
            this.lblOr.Size = new System.Drawing.Size(46, 13);
            this.lblOr.TabIndex = 3;
            this.lblOr.Text = "— or —";
            //
            // txtReceiptContact
            //
            this.txtReceiptContact.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtReceiptContact.BackColor = System.Drawing.Color.FromArgb(49, 67, 88);
            this.txtReceiptContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtReceiptContact.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtReceiptContact.ForeColor = System.Drawing.Color.White;
            this.txtReceiptContact.Location = new System.Drawing.Point(17, 78);
            this.txtReceiptContact.Name = "txtReceiptContact";
            this.txtReceiptContact.Size = new System.Drawing.Size(294, 25);
            this.txtReceiptContact.TabIndex = 2;
            this.txtReceiptContact.Text = "email@example.com or +27 00 000 0000";
            //
            // lblReceiptSub
            //
            this.lblReceiptSub.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblReceiptSub.AutoSize = true;
            this.lblReceiptSub.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblReceiptSub.ForeColor = System.Drawing.Color.Silver;
            this.lblReceiptSub.Location = new System.Drawing.Point(17, 50);
            this.lblReceiptSub.Name = "lblReceiptSub";
            this.lblReceiptSub.Size = new System.Drawing.Size(177, 15);
            this.lblReceiptSub.TabIndex = 1;
            this.lblReceiptSub.Text = "Send receipt to (email or phone)";
            this.lblReceiptSub.Click += new System.EventHandler(this.lblReceiptSub_Click);
            //
            // lblReceiptOptions
            //
            this.lblReceiptOptions.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblReceiptOptions.AutoSize = true;
            this.lblReceiptOptions.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.lblReceiptOptions.ForeColor = System.Drawing.Color.White;
            this.lblReceiptOptions.Location = new System.Drawing.Point(16, 18);
            this.lblReceiptOptions.Name = "lblReceiptOptions";
            this.lblReceiptOptions.Size = new System.Drawing.Size(116, 20);
            this.lblReceiptOptions.TabIndex = 0;
            this.lblReceiptOptions.Text = "Receipt Options";
            //
            // btnCompleteTransaction
            //
            this.btnCompleteTransaction.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCompleteTransaction.BackColor = System.Drawing.Color.FromArgb(0, 184, 82);
            this.btnCompleteTransaction.FlatAppearance.BorderSize = 0;
            this.btnCompleteTransaction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCompleteTransaction.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.btnCompleteTransaction.ForeColor = System.Drawing.Color.White;
            this.btnCompleteTransaction.Location = new System.Drawing.Point(540, 510);
            this.btnCompleteTransaction.Name = "btnCompleteTransaction";
            this.btnCompleteTransaction.Size = new System.Drawing.Size(330, 52);
            this.btnCompleteTransaction.TabIndex = 6;
            this.btnCompleteTransaction.Text = "Complete Transaction";
            this.btnCompleteTransaction.UseVisualStyleBackColor = false;
            this.btnCompleteTransaction.Click += new System.EventHandler(this.btnCompleteTransaction_Click);
            //
            // CheckoutForm
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(13, 25, 45);
            this.ClientSize = new System.Drawing.Size(1280, 720);
            this.Controls.Add(this.btnCompleteTransaction);
            this.Controls.Add(this.receiptPanel);
            this.Controls.Add(this.paymentPanel);
            this.Controls.Add(this.lblPaymentMethod);
            this.Controls.Add(this.orderPanel);
            this.Controls.Add(this.lblOrderSummary);
            this.Controls.Add(this.headerPanel);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "CheckoutForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FreshMart - Review & Pay";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.headerPanel.ResumeLayout(false);
            this.headerPanel.PerformLayout();
            this.orderPanel.ResumeLayout(false);
            this.totalsPanel.ResumeLayout(false);
            this.totalsPanel.PerformLayout();
            this.storeHeaderPanel.ResumeLayout(false);
            this.storeHeaderPanel.PerformLayout();
            this.paymentPanel.ResumeLayout(false);
            this.paymentPanel.PerformLayout();
            this.receiptPanel.ResumeLayout(false);
            this.receiptPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel headerPanel;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblOrderSummary;
        private System.Windows.Forms.Panel orderPanel;
        private System.Windows.Forms.Panel storeHeaderPanel;
        private System.Windows.Forms.Label lblStore;
        private System.Windows.Forms.Label lblDateTime;
        private System.Windows.Forms.Label divider1;
        private System.Windows.Forms.FlowLayoutPanel itemsFlow;
        private System.Windows.Forms.Panel totalsPanel;
        private System.Windows.Forms.Label divider2;
        private System.Windows.Forms.Label lblSubtotal;
        private System.Windows.Forms.Label lblSubtotalValue;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Label lblTaxValue;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblTotalValue;
        private System.Windows.Forms.Label lblPaymentMethod;
        private System.Windows.Forms.Panel paymentPanel;
        private System.Windows.Forms.Label lblCardIcon;
        private System.Windows.Forms.Label lblCard;
        private System.Windows.Forms.Label lblPaymentSub;
        private System.Windows.Forms.Panel receiptPanel;
        private System.Windows.Forms.Label lblReceiptOptions;
        private System.Windows.Forms.Label lblReceiptSub;
        private System.Windows.Forms.TextBox txtReceiptContact;
        private System.Windows.Forms.Label lblOr;
        private System.Windows.Forms.Button btnPrintReceipt;
        private System.Windows.Forms.Button btnCompleteTransaction;
        private System.Windows.Forms.Label lblCardInfo;
    }
}
