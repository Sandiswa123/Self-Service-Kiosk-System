﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using FreshMartKiosk.CustomerAuth;

namespace FreshMartKiosk
{
    /// <summary>Main shopping screen: product grid on the left, cart on the right.</summary>
    public class FormKiosk : Form
    {
        private const string SearchPlaceholder = "Enter item code (e.g. P001) and press Enter...";

        private static readonly Color Background = Color.FromArgb(13, 19, 38);
        private static readonly Color CartBackground = Color.FromArgb(20, 28, 58);
        private static readonly Color Green = Color.FromArgb(46, 204, 113);
        private static readonly Color ChipOff = Color.FromArgb(30, 42, 74);

        private readonly ShoppingCart cart = new ShoppingCart();
        private readonly Timer clockTimer = new Timer { Interval = 1000 };

        private TextBox txtSearch;
        private FlowLayoutPanel productsFlow, cartFlow, catPanel;
        private Label lblSubtotal, lblTax, lblTotal, lblCount, lblTime, lblCancel;
        private Panel header;

        public FormKiosk()
        {
            Text = "FreshMart Kiosk";
            WindowState = FormWindowState.Maximized;
            BackColor = Background;
            KeyPreview = true;

            BuildUI();
            cart.LoadProductAvailability();
            LoadProducts("All");
            RenderCart();

            clockTimer.Tick += (s, e) => { lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt"); LayoutHeader(); };
            clockTimer.Start();

            Shown += (s, e) => txtSearch.Focus();

            HelpAssistant.Attach(this, HelpKnowledge.Shopping);
        }

        /// <summary>Closes the shopping screen. The welcome screen re-appears automatically.</summary>
        public void ReturnToWelcome()
        {
            Close();
        }

        /// <summary>Refreshes the cart panel.</summary>
        public void RefreshCart() => RenderCart();

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            clockTimer.Stop();
            base.OnFormClosed(e);
        }

        // ------------------------------------------------------------------
        // Building the screen
        // ------------------------------------------------------------------

        private void BuildUI()
        {
            // --- Top header: logo, clock, cancel ------------------------------
            header = new Panel { Dock = DockStyle.Top, Height = 45, BackColor = Background };

            var circleF = new Panel { Width = 28, Height = 28, Left = 14, Top = 8, BackColor = Background };
            circleF.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using (var brush = new SolidBrush(Green))
                using (var font = new Font("Segoe UI", 10, FontStyle.Bold))
                {
                    e.Graphics.FillEllipse(brush, 0, 0, 28, 28);
                    e.Graphics.DrawString("F", font, Brushes.White, 7, 3);
                }
            };

            var lblBrand = new Label { Text = "FreshMart", ForeColor = Color.White, Font = new Font("Segoe UI", 11, FontStyle.Bold), Left = 50, Top = 11, AutoSize = true };
            var lblCustomer = new Label
            {
                Text = CustomerSession.IsSignedIn ? "Shopping as " + CustomerSession.CurrentCustomer.DisplayName : "Customer",
                ForeColor = Color.Silver,
                Font = new Font("Segoe UI", 8.5f),
                Left = 145,
                Top = 14,
                AutoSize = true
            };
            lblTime = new Label { Text = DateTime.Now.ToString("hh:mm:ss tt"), ForeColor = Color.White, Font = new Font("Consolas", 10), AutoSize = true, Top = 13 };
            lblCancel = new Label { Text = "X Cancel Transaction", ForeColor = Color.FromArgb(255, 100, 100), Font = new Font("Segoe UI", 9), AutoSize = true, Cursor = Cursors.Hand, Top = 14 };
            lblCancel.Click += (s, e) => CancelTransaction();

            header.Controls.Add(lblCancel);
            header.Controls.Add(lblTime);
            header.Controls.Add(lblBrand);
            header.Controls.Add(lblCustomer);
            header.Controls.Add(circleF);
            header.Resize += (s, e) => LayoutHeader();

            // --- Search bar + cart title ---------------------------------------
            var secondBar = new Panel { Dock = DockStyle.Top, Height = 52, BackColor = Background };

            var cartHeader = new Panel { Dock = DockStyle.Right, Width = 380, BackColor = CartBackground };
            cartHeader.Controls.Add(new Label { Text = "Your Cart", ForeColor = Color.White, Font = new Font("Segoe UI", 11, FontStyle.Bold), Left = 12, Top = 15, AutoSize = true });
            lblCount = new Label { Text = "0/10 items", ForeColor = Color.Gray, Left = 280, Top = 18, AutoSize = true, Font = new Font("Segoe UI", 8) };
            cartHeader.Controls.Add(lblCount);

            var leftSearch = new Panel { Dock = DockStyle.Fill, BackColor = Background, Padding = new Padding(14, 8, 8, 8) };
            var btnScan = MakeFlatButton("Scan", Color.FromArgb(0, 140, 255));
            var btnAdd = MakeFlatButton("Add Item", Green);

            txtSearch = new TextBox
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(45, 60, 85),
                ForeColor = Color.Silver,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 10),
                Text = SearchPlaceholder
            };
            txtSearch.GotFocus += (s, e) =>
            {
                if (txtSearch.Text == SearchPlaceholder) { txtSearch.Text = ""; txtSearch.ForeColor = Color.White; }
            };
            txtSearch.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtSearch.Text)) { txtSearch.Text = SearchPlaceholder; txtSearch.ForeColor = Color.Silver; }
            };
            txtSearch.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter) { HandleScan(txtSearch.Text); e.SuppressKeyPress = true; }
            };
            btnAdd.Click += (s, e) => HandleScan(txtSearch.Text);
            btnScan.Click += (s, e) => HandleScan(txtSearch.Text);

            leftSearch.Controls.Add(txtSearch);
            leftSearch.Controls.Add(btnAdd);
            leftSearch.Controls.Add(btnScan);
            secondBar.Controls.Add(leftSearch);
            secondBar.Controls.Add(cartHeader);

            // --- Category chips ------------------------------------------------
            var catBar = new Panel { Dock = DockStyle.Top, Height = 38, BackColor = Background, Padding = new Padding(14, 4, 0, 4) };
            catPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, BackColor = Background };

            string[] cats = { "All", "Dairy", "Bakery", "Produce", "Meat", "Seafood", "Beverages", "Pantry", "Snacks" };
            foreach (string c in cats)
            {
                var chip = new Button
                {
                    Text = c,
                    Height = 28,
                    AutoSize = true,
                    BackColor = c == "All" ? Green : ChipOff,
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 8),
                    Margin = new Padding(0, 0, 6, 0),
                    Padding = new Padding(10, 0, 10, 0)
                };
                chip.FlatAppearance.BorderSize = 0;
                string category = c;
                chip.Click += (s, e) =>
                {
                    foreach (Button other in catPanel.Controls) other.BackColor = ChipOff;
                    ((Button)s).BackColor = Green;
                    LoadProducts(category);
                };
                catPanel.Controls.Add(chip);
            }
            catBar.Controls.Add(catPanel);

            // --- Main area: products + cart ------------------------------------
            var main = new Panel { Dock = DockStyle.Fill, BackColor = Background };
            var cartPanel = new Panel { Dock = DockStyle.Right, Width = 380, BackColor = CartBackground };

            var summary = new Panel { Dock = DockStyle.Bottom, Height = 150, BackColor = CartBackground, Padding = new Padding(12, 8, 12, 12) };
            lblSubtotal = new Label { Dock = DockStyle.Top, Height = 22, ForeColor = Color.Gray, Font = new Font("Segoe UI", 8) };
            lblTax = new Label { Dock = DockStyle.Top, Height = 22, ForeColor = Color.Gray, Font = new Font("Segoe UI", 8) };
            var sep = new Panel { Dock = DockStyle.Top, Height = 1, BackColor = Color.FromArgb(40, 50, 80) };
            lblTotal = new Label { Dock = DockStyle.Top, Height = 30, ForeColor = Color.White, Font = new Font("Segoe UI", 11, FontStyle.Bold) };

            var btnCheckout = new Button
            {
                Text = "Proceed to Checkout",
                Dock = DockStyle.Bottom,
                Height = 38,
                BackColor = Green,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };
            btnCheckout.FlatAppearance.BorderSize = 0;
            btnCheckout.Click += (s, e) => GoToCheckout();

            summary.Controls.Add(btnCheckout);
            summary.Controls.Add(lblTotal);
            summary.Controls.Add(sep);
            summary.Controls.Add(lblTax);
            summary.Controls.Add(lblSubtotal);

            cartFlow = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, BackColor = CartBackground, Padding = new Padding(8) };
            cartPanel.Controls.Add(cartFlow);
            cartPanel.Controls.Add(summary);

            productsFlow = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Background, Padding = new Padding(10) };
            main.Controls.Add(productsFlow);
            main.Controls.Add(cartPanel);

            Controls.Add(main);
            Controls.Add(catBar);
            Controls.Add(secondBar);
            Controls.Add(header);
        }

        private static Button MakeFlatButton(string text, Color color)
        {
            var b = new Button
            {
                Text = text,
                Width = 85,
                Height = 32,
                Dock = DockStyle.Right,
                BackColor = color,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8, FontStyle.Bold)
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        /// <summary>Centre the clock and right-align "Cancel" for the real window width.</summary>
        private void LayoutHeader()
        {
            if (header == null) return;
            lblTime.Left = (header.ClientSize.Width - lblTime.Width) / 2;
            lblCancel.Left = header.ClientSize.Width - lblCancel.Width - 16;
        }

        // ------------------------------------------------------------------
        // Product grid
        // ------------------------------------------------------------------

        private void LoadProducts(string category)
        {
            productsFlow.SuspendLayout();

            foreach (Control old in productsFlow.Controls.Cast<Control>().ToList())
                old.Dispose();
            productsFlow.Controls.Clear();

            var list = category == "All"
                ? cart.Catalog
                : cart.Catalog.Where(p => p.Category == category).ToList();

            foreach (Product p in list)
                productsFlow.Controls.Add(CreateCard(p));

            productsFlow.ResumeLayout();
        }

        private Panel CreateCard(Product p)
        {
            bool soldOut = !p.CanBeSold;

            var card = new Panel
            {
                Width = 230,
                Height = 220,
                BackColor = soldOut ? Color.FromArgb(55, 55, 60) : Color.FromArgb(22, 32, 61),
                Margin = new Padding(6),
                Cursor = soldOut ? Cursors.No : Cursors.Hand
            };

            var pic = new PictureBox { Dock = DockStyle.Top, Height = 155, SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.White };
            Image image = LoadProductImage(p.ProductId);
            pic.Image = (soldOut && image != null) ? MakeDarkGrey(image) : image;

            if (soldOut)
            {
                var lblSoldOut = new Label
                {
                    Text = "SOLD OUT",
                    ForeColor = Color.White,
                    BackColor = Color.FromArgb(190, 40, 40),
                    Font = new Font("Segoe UI", 12, FontStyle.Bold),
                    TextAlign = ContentAlignment.MiddleCenter,
                    Size = new Size(120, 35),
                    Location = new Point(55, 60)
                };
                pic.Controls.Add(lblSoldOut);
                lblSoldOut.Click += (s, e) => ShowSoldOutPopup(p, pic.Image);
            }

            var lblPrice = new Label { Text = $"R {p.Price:0.00}", ForeColor = Green, Dock = DockStyle.Top, Height = 18, Padding = new Padding(6, 0, 0, 0), Font = new Font("Segoe UI", 8, FontStyle.Bold) };
            var lblName = new Label { Text = p.ProductName, ForeColor = Color.White, Dock = DockStyle.Top, Height = 24, Padding = new Padding(6, 2, 0, 0), Font = new Font("Segoe UI", 7, FontStyle.Bold) };

            card.Controls.Add(lblPrice);
            card.Controls.Add(lblName);
            card.Controls.Add(pic);

            EventHandler add = (s, e) =>
            {
                if (soldOut) ShowSoldOutPopup(p, pic.Image);
                else TryAdd(p);
            };
            card.Click += add;
            pic.Click += add;
            lblName.Click += add;
            lblPrice.Click += add;

            return card;
        }

        private static Image LoadProductImage(string productId)
        {
            string folder = Path.Combine(Application.StartupPath, "Images");
            foreach (string ext in new[] { ".jpg", ".jpeg", ".png" })
            {
                string path = Path.Combine(folder, productId + ext);
                if (!File.Exists(path)) continue;

                try
                {
                    using (var fromDisk = new Bitmap(path))
                        return new Bitmap(fromDisk);
                }
                catch (ArgumentException) { }
            }
            return null;
        }

        /// <summary>
        /// Draws the image through a grayscale colour matrix in one step.
        /// (Much faster than GetPixel/SetPixel on every pixel.)
        /// </summary>
        private static Image MakeDarkGrey(Image original)
        {
            var result = new Bitmap(original.Width, original.Height);
            const float d = 0.55f / 3f;   // average of R,G,B, darkened to 55%

            var matrix = new ColorMatrix(new[]
            {
                new[] { d, d, d, 0f, 0f },
                new[] { d, d, d, 0f, 0f },
                new[] { d, d, d, 0f, 0f },
                new[] { 0f, 0f, 0f, 1f, 0f },
                new[] { 0f, 0f, 0f, 0f, 1f }
            });

            using (var g = Graphics.FromImage(result))
            using (var attributes = new ImageAttributes())
            {
                attributes.SetColorMatrix(matrix);
                g.DrawImage(original, new Rectangle(0, 0, result.Width, result.Height),
                    0, 0, original.Width, original.Height, GraphicsUnit.Pixel, attributes);
            }

            original.Dispose();
            return result;
        }

        private void ShowSoldOutPopup(Product product, Image productImage)
        {
            using (var popup = new Form
            {
                FormBorderStyle = FormBorderStyle.None,
                StartPosition = FormStartPosition.CenterParent,
                Size = new Size(470, 470),
                BackColor = Color.FromArgb(31, 45, 68),
                ShowInTaskbar = false
            })
            {
                var picture = new PictureBox { Size = new Size(150, 150), Location = new Point(160, 30), SizeMode = PictureBoxSizeMode.Zoom, Image = productImage };
                var soldLabel = new Label { Text = "SOLD OUT", Size = new Size(90, 30), Location = new Point(190, 145), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.FromArgb(239, 68, 68), ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
                var productName = new Label { Text = product.ProductName, Location = new Point(30, 205), Size = new Size(410, 35), TextAlign = ContentAlignment.MiddleCenter, ForeColor = Color.White, Font = new Font("Segoe UI", 14, FontStyle.Bold) };
                var message = new Label { Text = "This item is currently out of stock at this location.", Location = new Point(30, 245), Size = new Size(410, 30), TextAlign = ContentAlignment.MiddleCenter, ForeColor = Color.LightGray, Font = new Font("Segoe UI", 10) };

                var btnFindStore = new Button { Text = "📍  Find This Product at a Nearest Store", Location = new Point(40, 300), Size = new Size(390, 60), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(0, 190, 100), ForeColor = Color.White, Font = new Font("Segoe UI", 11, FontStyle.Bold) };
                btnFindStore.FlatAppearance.BorderSize = 0;
                btnFindStore.Click += (s, e) =>
                {
                    string url = "https://www.google.com/maps/search/?api=1&query=" + Uri.EscapeDataString("supermarkets near me");
                    try
                    {
                        Process.Start(new ProcessStartInfo { FileName = url, UseShellExecute = true });
                    }
                    catch (Exception)
                    {
                        MessageBox.Show(popup, "Could not open the map on this kiosk.", "Find a Store", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                };

                var btnContinue = new Button { Text = "Continue Shopping", Location = new Point(40, 380), Size = new Size(390, 60), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(55, 73, 99), ForeColor = Color.White, Font = new Font("Segoe UI", 11, FontStyle.Bold) };
                btnContinue.FlatAppearance.BorderSize = 0;
                btnContinue.Click += (s, e) => popup.Close();

                popup.Controls.AddRange(new Control[] { picture, soldLabel, productName, message, btnFindStore, btnContinue });
                soldLabel.BringToFront();
                popup.ShowDialog(this);
            }
        }

        // ------------------------------------------------------------------
        // Adding / scanning
        // ------------------------------------------------------------------

        private void HandleScan(string code)
        {
            if (string.IsNullOrWhiteSpace(code) || code == SearchPlaceholder) return;

            // FIX: an unknown code used to fall through with product == null and crash.
            Product product = cart.FindProductByBarcode(code);
            if (product == null)
            {
                MessageBox.Show(this, $"No product found with code \"{code.Trim()}\".", "Not Found",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                TryAdd(product);
            }

            txtSearch.Clear();
            txtSearch.ForeColor = Color.White;
            txtSearch.Focus();
        }

        private void TryAdd(Product product, bool allowExisting = false)
        {
            if (!allowExisting && cart.Items.Any(i => i.Product.ProductId == product.ProductId))
            {
                MessageBox.Show(this, "This item is already in your cart. Use the + button to increase its quantity.",
                    "Already in Cart", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            switch (cart.AddProduct(product, 1))
            {
                case AddResult.Added:
                    RenderCart();
                    break;

                case AddResult.Unavailable:
                    MessageBox.Show(this, "This product is currently unavailable.", "Sold Out",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;

                case AddResult.CartFull:
                    MessageBox.Show(this, $"Cart limit reached! Max {ShoppingCart.MaxItems} items only.", "Limit",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;

                case AddResult.NotEnoughStock:
                    MessageBox.Show(this, $"Sorry, only {product.Stock} of this item in stock.", "Stock",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
            }
        }

        private void CancelTransaction()
        {
            if (cart.Items.Count > 0)
            {
                var answer = MessageBox.Show(this, "Cancel this transaction and empty the cart?", "Cancel Transaction",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (answer != DialogResult.Yes) return;
            }

            cart.ClearCart();
            ReturnToWelcome();
        }

        private void GoToCheckout()
        {
            if (cart.Items.Count == 0)
            {
                MessageBox.Show(this, "Your cart is empty.", "Checkout", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult result;
            Hide();
            using (var checkout = new CheckoutForm(cart))
            {
                result = checkout.ShowDialog();
            }

            // OK = paid, Abort = cancelled: go back to the welcome screen.
            // Anything else (Back button, or the window's X): keep shopping.
            if (result == DialogResult.OK || result == DialogResult.Abort)
            {
                ReturnToWelcome();
            }
            else
            {
                RenderCart();
                Show();
            }
        }

        // ------------------------------------------------------------------
        // Cart panel
        // ------------------------------------------------------------------

        private void RenderCart()
        {
            cartFlow.SuspendLayout();
            foreach (Control old in cartFlow.Controls.Cast<Control>().ToList())
                old.Dispose();
            cartFlow.Controls.Clear();

            if (cart.Items.Count == 0)
            {
                var empty = new Panel { Width = 350, Height = 250, BackColor = CartBackground };
                empty.Controls.Add(new Label { Text = "🛒", Font = new Font("Segoe UI", 28), ForeColor = Color.FromArgb(80, 90, 110), Width = 350, Height = 50, Top = 30, TextAlign = ContentAlignment.MiddleCenter });
                empty.Controls.Add(new Label { Text = "Your cart is empty", ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold), Width = 350, Top = 85, Height = 24, TextAlign = ContentAlignment.MiddleCenter });
                cartFlow.Controls.Add(empty);
            }
            else
            {
                foreach (CartItem item in cart.Items)
                    cartFlow.Controls.Add(CreateCartRow(item));
            }
            cartFlow.ResumeLayout();

            int count = cart.ItemCount;
            lblCount.Text = $"{count}/{ShoppingCart.MaxItems} items";
            lblSubtotal.Text = $"Subtotal ({count} items)".PadRight(25) + $"R {cart.CalculateSubtotal():0.00}";
            lblTax.Text = "Tax (15% VAT)".PadRight(28) + $"R {cart.CalculateVat():0.00}";
            lblTotal.Text = "Total".PadRight(32) + $"R {cart.CalculateTotal():0.00}";
        }

        private Panel CreateCartRow(CartItem item)
        {
            var row = new Panel { Width = 345, Height = 45, BackColor = ChipOff, Margin = new Padding(0, 0, 0, 5) };
            string id = item.Product.ProductId;

            row.Controls.Add(new Label
            {
                Text = $"{item.Product.ProductName} x{item.Quantity} = R {item.TotalPrice:0.00}",
                ForeColor = Color.White,
                Dock = DockStyle.Fill,
                Padding = new Padding(6, 6, 0, 0),
                Font = new Font("Segoe UI", 8)
            });

            var btnPlus = new Button { Text = "+", Width = 30, Dock = DockStyle.Right, FlatStyle = FlatStyle.Flat, ForeColor = Color.White };
            btnPlus.FlatAppearance.BorderSize = 0;
            btnPlus.Click += (s, e) =>
            {
                DialogResult answer = MessageBox.Show(this,
                    $"Do you want to add another {item.Product.ProductName} to your cart?",
                    "Add Item", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (answer == DialogResult.Yes)
                    BeginInvoke((Action)(() => TryAdd(item.Product, allowExisting: true)));
            };

            var btnMinus = new Button { Text = "−", Width = 30, Dock = DockStyle.Right, FlatStyle = FlatStyle.Flat, ForeColor = Color.White };
            btnMinus.FlatAppearance.BorderSize = 0;
            btnMinus.Click += (s, e) =>
            {
                DialogResult answer = MessageBox.Show(this,
                    $"Do you want to remove one {item.Product.ProductName} from your cart?",
                    "Remove Item", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (answer == DialogResult.Yes)
                {
                    cart.RemoveOne(id);
                    BeginInvoke((Action)RenderCart);
                }
            };

            var btnRemove = new Button { Text = "X", Width = 30, Dock = DockStyle.Right, FlatStyle = FlatStyle.Flat, ForeColor = Color.FromArgb(255, 80, 80) };
            btnRemove.FlatAppearance.BorderSize = 0;
            btnRemove.Click += (s, e) => { cart.RemoveProduct(id); BeginInvoke((Action)RenderCart); };

            row.Controls.Add(btnPlus);
            row.Controls.Add(btnMinus);
            row.Controls.Add(btnRemove);
            return row;
        }
    }
}
