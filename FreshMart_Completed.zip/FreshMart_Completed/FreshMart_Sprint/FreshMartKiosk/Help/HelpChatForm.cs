using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace FreshMartKiosk
{
    /// <summary>
    /// The help chat window. Opened (modally) from the floating "?" button that
    /// <see cref="HelpAssistant"/> adds to every screen. Built in code, like the login screens.
    /// </summary>
    internal sealed class HelpChatForm : Form
    {
        private static readonly Color Background = Color.FromArgb(13, 19, 38);
        private static readonly Color PanelColor = Color.FromArgb(20, 28, 58);
        private static readonly Color ChipOff = Color.FromArgb(30, 42, 74);
        private static readonly Color Green = Color.FromArgb(46, 204, 113);
        private static readonly Color ButtonGreen = Color.FromArgb(46, 175, 84);

        private const int SuggestionWidth = 575;

        private readonly Font bodyFont = new Font("Segoe UI", 10.5F);
        private readonly Font boldFont = new Font("Segoe UI", 10.5F, FontStyle.Bold);
        private readonly Font labelFont = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        private readonly Font spacerFont = new Font("Segoe UI", 5F);

        private RichTextBox chat;
        private TextBox txtInput;
        private FlowLayoutPanel topicsFlow;
        private FlowLayoutPanel suggestFlow;
        private Label suggestTitle;

        private string category;

        public HelpChatForm(string startCategory)
        {
            category = HelpKnowledge.Categories.Contains(startCategory) ? startCategory : HelpKnowledge.AllTopics;

            Text = "FreshMart Help";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(640, 680);
            ShowInTaskbar = false;
            BackColor = Green;                 // shows as a thin green border around the panels
            Padding = new Padding(2);
            ForeColor = Color.White;
            Font = new Font("Segoe UI", 10F);

            BuildUI();

            // Handles exist by the time Load runs, so formatting the chat text is safe here.
            Load += (s, e) =>
            {
                RefreshTopicChips();
                AppendMessage(false, GreetingFor(category));
                RefreshSuggestions(null);
                txtInput.Focus();
            };
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                bodyFont.Dispose();
                boldFont.Dispose();
                labelFont.Dispose();
                spacerFont.Dispose();
            }
            base.Dispose(disposing);
        }

        // ------------------------------------------------------------------
        // Building the window
        // ------------------------------------------------------------------

        private void BuildUI()
        {
            // --- Header --------------------------------------------------------
            var header = new Panel { Dock = DockStyle.Top, Height = 64, BackColor = Color.FromArgb(20, 20, 20) };

            var logo = new Label
            {
                Text = "?",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = ButtonGreen,
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(42, 42),
                Location = new Point(14, 11)
            };
            var title = new Label
            {
                Text = "FreshMart Helper",
                Font = new Font("Segoe UI", 13, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(66, 10)
            };
            var subtitle = new Label
            {
                Text = "Ask how to use this kiosk",
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.Gainsboro,
                AutoSize = true,
                Location = new Point(68, 36)
            };
            var btnClose = new Button
            {
                Text = "\u2715  Close",
                Dock = DockStyle.Right,
                Width = 110,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(90, 25, 35),
                ForeColor = Color.FromArgb(255, 120, 130),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                DialogResult = DialogResult.Cancel,    // also makes Esc close the window
                Cursor = Cursors.Hand
            };
            btnClose.FlatAppearance.BorderSize = 0;
            header.Controls.Add(logo);
            header.Controls.Add(title);
            header.Controls.Add(subtitle);
            header.Controls.Add(btnClose);
            CancelButton = btnClose;

            // --- Topic buttons -------------------------------------------------
            topicsFlow = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 48,
                BackColor = PanelColor,
                Padding = new Padding(10, 9, 0, 0),
                WrapContents = false
            };
            foreach (string name in HelpKnowledge.Categories)
            {
                string topicName = name;
                var chip = new Button
                {
                    Text = topicName,
                    Tag = topicName,
                    AutoSize = true,
                    AutoSizeMode = AutoSizeMode.GrowAndShrink,
                    MinimumSize = new Size(0, 30),
                    Padding = new Padding(8, 0, 8, 0),
                    Margin = new Padding(0, 0, 6, 0),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = ChipOff,
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 9),
                    UseMnemonic = false,               // so the "&" in "Checkout & receipt" shows
                    Cursor = Cursors.Hand
                };
                chip.FlatAppearance.BorderSize = 0;
                chip.Click += (s, e) =>
                {
                    category = topicName;
                    RefreshTopicChips();
                    RefreshSuggestions(null);
                };
                topicsFlow.Controls.Add(chip);
            }

            // --- Conversation --------------------------------------------------
            chat = new RichTextBox
            {
                Dock = DockStyle.Fill,
                BorderStyle = BorderStyle.None,
                BackColor = Background,
                ForeColor = Color.Gainsboro,
                Font = bodyFont,
                ScrollBars = RichTextBoxScrollBars.Vertical,
                DetectUrls = false,
                TabStop = false,
                Cursor = Cursors.Arrow,
                ReadOnly = true
            };
            chat.BackColor = Background;               // ReadOnly can reset the colour, so set it again

            // --- Suggested questions ------------------------------------------
            var suggestPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 190,
                BackColor = PanelColor,
                Padding = new Padding(10, 6, 10, 6)
            };
            suggestFlow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true,
                BackColor = PanelColor
            };
            suggestTitle = new Label
            {
                Text = "Suggested questions",
                Dock = DockStyle.Top,
                Height = 22,
                ForeColor = Color.FromArgb(150, 160, 185),
                Font = labelFont
            };
            suggestPanel.Controls.Add(suggestFlow);    // Fill goes in first,
            suggestPanel.Controls.Add(suggestTitle);   // then the edge control

            // --- Typing box ----------------------------------------------------
            var inputPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 66,
                BackColor = Background,
                Padding = new Padding(10, 10, 10, 10)
            };
            txtInput = new TextBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 12F),
                BackColor = Color.FromArgb(45, 60, 85),
                ForeColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            var btnSend = new Button
            {
                Text = "Send",
                Dock = DockStyle.Right,
                Width = 100,
                FlatStyle = FlatStyle.Flat,
                BackColor = ButtonGreen,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10.5F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnSend.FlatAppearance.BorderSize = 0;
            btnSend.Click += (s, e) => SendTyped();
            inputPanel.Controls.Add(txtInput);
            inputPanel.Controls.Add(btnSend);
            AcceptButton = btnSend;                    // Enter sends the question

            // Fill control first, then the edge controls (the last one added sits outermost).
            Controls.Add(chat);
            Controls.Add(suggestPanel);
            Controls.Add(inputPanel);
            Controls.Add(topicsFlow);
            Controls.Add(header);
        }

        // ------------------------------------------------------------------
        // Asking and answering
        // ------------------------------------------------------------------

        private void SendTyped()
        {
            string text = txtInput.Text.Trim();
            if (text.Length == 0) return;

            txtInput.Clear();
            Ask(text, null);
            txtInput.Focus();
        }

        private void Ask(string text, HelpTopic knownTopic)
        {
            AppendMessage(true, text);

            HelpTopic topic = knownTopic ?? HelpKnowledge.Find(text);
            if (topic == null)
            {
                AppendMessage(false,
                    "Sorry, I can only help with using the FreshMart kiosk: signing in, shopping, the cart, checkout, receipts and the admin tools.\n" +
                    "Please pick one of the suggested questions below, or try asking in different words.");
            }
            else
            {
                AppendMessage(false, topic.Answer);
                category = topic.Category;
                RefreshTopicChips();
            }

            RefreshSuggestions(topic);
        }

        private static string GreetingFor(string forCategory)
        {
            switch (forCategory)
            {
                case HelpKnowledge.GettingStarted:
                    return "Hi! I'm the FreshMart helper. I can show you how to sign in, create an account and start shopping.";
                case HelpKnowledge.Shopping:
                    return "Hi! I'm the FreshMart helper. Ask me how to add items, use your cart or find products.";
                case HelpKnowledge.Checkout:
                    return "Hi! I'm the FreshMart helper. I can walk you through paying and getting your receipt.";
                case HelpKnowledge.Staff:
                    return "Hi! I'm the FreshMart helper. I can explain stock management, analytics and system control.";
                default:
                    return "Hi! I'm the FreshMart helper. Pick a question below, choose a topic, or type your own.";
            }
        }

        // ------------------------------------------------------------------
        // Topic buttons and suggestions
        // ------------------------------------------------------------------

        private void RefreshTopicChips()
        {
            foreach (Button chip in topicsFlow.Controls.OfType<Button>())
                chip.BackColor = (string)chip.Tag == category ? ButtonGreen : ChipOff;
        }

        private void RefreshSuggestions(HelpTopic justAsked)
        {
            suggestTitle.Text = category == HelpKnowledge.AllTopics
                ? "Suggested questions"
                : "Suggested questions \u00B7 " + category;

            suggestFlow.SuspendLayout();
            foreach (Control old in suggestFlow.Controls.Cast<Control>().ToList())
                old.Dispose();
            suggestFlow.Controls.Clear();

            IEnumerable<HelpTopic> list = HelpKnowledge.Topics
                .Where(t => category == HelpKnowledge.AllTopics || t.Category == category)
                .Where(t => t != justAsked);

            foreach (HelpTopic topic in list)
                suggestFlow.Controls.Add(MakeSuggestion(topic));

            suggestFlow.ResumeLayout();
        }

        private Button MakeSuggestion(HelpTopic topic)
        {
            var button = new Button
            {
                Text = "\U0001F4AC  " + topic.Question,
                Size = new Size(SuggestionWidth, 34),
                Margin = new Padding(0, 0, 0, 5),
                Padding = new Padding(8, 0, 0, 0),
                TextAlign = ContentAlignment.MiddleLeft,
                FlatStyle = FlatStyle.Flat,
                BackColor = ChipOff,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9.5F),
                UseMnemonic = false,
                Cursor = Cursors.Hand
            };
            button.FlatAppearance.BorderSize = 0;

            // BeginInvoke: the buttons are rebuilt while answering, so let this click finish first.
            button.Click += (s, e) => BeginInvoke((Action)(() => Ask(topic.Question, topic)));
            return button;
        }

        // ------------------------------------------------------------------
        // Writing into the conversation
        // ------------------------------------------------------------------

        /// <summary>Adds one chat message (speaker name, then the text) and scrolls to it.</summary>
        private void AppendMessage(bool fromUser, string markup)
        {
            int messageStart = chat.TextLength;

            AppendLine(fromUser ? "You" : "FreshMart Helper", labelFont, labelFont,
                fromUser ? Green : Color.FromArgb(130, 200, 160),
                fromUser ? HorizontalAlignment.Right : HorizontalAlignment.Left,
                fromUser ? 120 : 8, 0);

            foreach (string raw in markup.Split('\n'))
            {
                string line = raw;
                int indent = fromUser ? 120 : 8;
                int hanging = 0;

                if (!fromUser)
                {
                    if (line.StartsWith("- "))
                    {
                        line = "\u2022  " + line.Substring(2);
                        indent = 16;
                        hanging = 16;
                    }
                    else if (line.Length > 2 && char.IsDigit(line[0]) && line[1] == '.')
                    {
                        indent = 16;
                        hanging = 18;
                    }
                }

                AppendLine(line, bodyFont, boldFont,
                    fromUser ? Color.White : Color.Gainsboro,
                    fromUser ? HorizontalAlignment.Right : HorizontalAlignment.Left,
                    indent, hanging);
            }

            AppendSpacer();

            // Show the end first, then pull the start of this message into view.
            chat.Select(chat.TextLength, 0);
            chat.ScrollToCaret();
            chat.Select(messageStart, 0);
            chat.ScrollToCaret();
            chat.Select(chat.TextLength, 0);
        }

        /// <summary>Adds one paragraph. Text between ** ** is bold.</summary>
        private void AppendLine(string text, Font font, Font bold, Color color,
                                HorizontalAlignment align, int indent, int hanging)
        {
            int lineStart = chat.TextLength;

            string[] parts = text.Split(new[] { "**" }, StringSplitOptions.None);
            for (int i = 0; i < parts.Length; i++)
            {
                if (parts[i].Length == 0) continue;
                AppendRun(parts[i], i % 2 == 1 ? bold : font, color);
            }

            chat.Select(lineStart, chat.TextLength - lineStart);
            chat.SelectionAlignment = align;
            chat.SelectionIndent = indent;
            chat.SelectionHangingIndent = hanging;
            chat.SelectionRightIndent = align == HorizontalAlignment.Right ? 12 : 16;

            AppendRun("\n", font, color);
        }

        private void AppendSpacer()
        {
            AppendRun("\n", spacerFont, Color.Gainsboro);
        }

        private void AppendRun(string text, Font font, Color color)
        {
            int start = chat.TextLength;
            chat.AppendText(text);
            chat.Select(start, text.Length);
            chat.SelectionFont = font;
            chat.SelectionColor = color;
        }
    }
}
