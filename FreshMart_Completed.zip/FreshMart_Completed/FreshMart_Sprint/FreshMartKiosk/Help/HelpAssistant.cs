using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace FreshMartKiosk
{
    /// <summary>
    /// Puts a small round "?" help button in the bottom-left corner of a screen.
    /// Tapping it (or pressing F1) opens the help chat on top of that screen.
    /// One line in a form's constructor is all it takes:
    ///     HelpAssistant.Attach(this, HelpKnowledge.Shopping);
    /// </summary>
    internal static class HelpAssistant
    {
        private const int EdgeMargin = 10;
        private static bool isOpen;

        /// <param name="form">The screen to add the button to.</param>
        /// <param name="startTopic">Which help topic the chat opens on (a HelpKnowledge category).</param>
        public static void Attach(Form form, string startTopic)
        {
            if (form == null) return;

            var button = new HelpFab();
            button.Click += (s, e) => Open(form, startTopic);

            form.Controls.Add(button);
            button.BringToFront();

            Action place = () =>
                button.Location = new Point(EdgeMargin, Math.Max(EdgeMargin, form.ClientSize.Height - button.Height - EdgeMargin));
            place();

            // Smooth scrolling: double-buffer this screen's panels (now, and again once it is shown).
            Smoothing.Apply(form);

            form.Resize += (s, e) => place();
            form.Shown += (s, e) => { place(); button.BringToFront(); Smoothing.Apply(form); };

            // Some screens call BringToFront() on their own panels; keep the help button on top.
            form.Layout += (s, e) =>
            {
                if (form.Controls.Contains(button) && form.Controls.GetChildIndex(button) != 0)
                    button.BringToFront();
            };

            // F1 does the same as tapping the button.
            form.HelpRequested += (s, e) =>
            {
                Open(form, startTopic);
                e.Handled = true;
            };
        }

        private static void Open(Form owner, string startTopic)
        {
            if (isOpen) return;
            isOpen = true;
            try
            {
                using (var help = new HelpChatForm(startTopic))
                    help.ShowDialog(owner);
            }
            finally
            {
                isOpen = false;
            }
        }
    }

    /// <summary>The round green "?" button itself.</summary>
    internal sealed class HelpFab : Control
    {
        public const int Diameter = 44;

        private static readonly Color Normal = Color.FromArgb(46, 175, 84);
        private static readonly Color Hover = Color.FromArgb(60, 205, 105);

        private readonly Font glyphFont = new Font("Segoe UI", 17F, FontStyle.Bold);
        private readonly ToolTip tip = new ToolTip { InitialDelay = 400 };
        private bool hovering;

        public HelpFab()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            SetStyle(ControlStyles.Selectable, false);   // never steals keyboard focus from the screen

            TabStop = false;
            Size = new Size(Diameter, Diameter);
            Cursor = Cursors.Hand;
            AccessibleName = "Help";
            AccessibleRole = AccessibleRole.PushButton;

            using (var circle = new GraphicsPath())
            {
                circle.AddEllipse(0, 0, Diameter, Diameter);
                Region = new Region(circle);
            }

            tip.SetToolTip(this, "Need help? Tap here");
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            hovering = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            hovering = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(hovering ? Hover : Normal);
            g.SmoothingMode = SmoothingMode.AntiAlias;

            using (var ring = new Pen(Color.White, 2f))
                g.DrawEllipse(ring, 2, 2, Diameter - 5, Diameter - 5);

            TextRenderer.DrawText(g, "?", glyphFont, new Rectangle(0, 0, Diameter, Diameter), Color.White,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                glyphFont.Dispose();
                tip.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
