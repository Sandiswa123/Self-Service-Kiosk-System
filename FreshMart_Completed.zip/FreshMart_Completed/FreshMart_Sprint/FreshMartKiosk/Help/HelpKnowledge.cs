using System.Collections.Generic;

namespace FreshMartKiosk
{
    /// <summary>One question the help assistant can answer.</summary>
    internal sealed class HelpTopic
    {
        public string Category { get; }
        public string Question { get; }
        public string[] Keywords { get; }

        /// <summary>
        /// Answer text. One line per row. "- " starts a bullet, "1. " a numbered step,
        /// and **text** is shown in bold.
        /// </summary>
        public string Answer { get; }

        public HelpTopic(string category, string question, string[] keywords, string answer)
        {
            Category = category;
            Question = question;
            Keywords = keywords;
            Answer = answer;
        }
    }

    /// <summary>
    /// Everything the help assistant knows. It only covers features that exist in the kiosk:
    /// sign-in, shopping, cart, checkout, receipts and the admin tools.
    /// </summary>
    internal static class HelpKnowledge
    {
        public const string AllTopics = "All topics";
        public const string GettingStarted = "Getting started";
        public const string Shopping = "Shopping";
        public const string Checkout = "Checkout & receipt";
        public const string Staff = "Staff / Admin";

        public static readonly string[] Categories = { AllTopics, GettingStarted, Shopping, Checkout, Staff };

        private static string Lines(params string[] lines)
        {
            return string.Join("\n", lines);
        }

        public static readonly List<HelpTopic> Topics = new List<HelpTopic>
        {
            // ---------------------------------------------------------------- Getting started
            new HelpTopic(GettingStarted, "How do I start shopping?",
                new[] { "start", "begin", "tap", "welcome", "sign in & start" },
                Lines(
                    "1. On the welcome screen, tap **TAP TO SIGN IN & START SHOPPING**.",
                    "2. Log in, or create an account if you are new.",
                    "3. The shopping screen opens once you are signed in.")),

            new HelpTopic(GettingStarted, "How do I create an account?",
                new[] { "create", "sign up", "signup", "register", "new customer", "account" },
                Lines(
                    "On the login screen tap **NEW CUSTOMER? CREATE AN ACCOUNT** and fill in:",
                    "- Full name",
                    "- Email address (must be valid and not already used)",
                    "- Username (at least 3 characters, no spaces, not already taken)",
                    "- Password (at least 6 characters), then confirm it",
                    "Tap **CREATE ACCOUNT** and you are signed in straight away. **Back to login** takes you back to the login screen.")),

            new HelpTopic(GettingStarted, "How do I log in?",
                new[] { "log in", "login", "password", "username", "email", "incorrect", "forgot" },
                Lines(
                    "Enter your **username or email** and your password, then tap **LOG IN**.",
                    "If you see \"Incorrect username/email or password\", check both and try again.",
                    "Your session ends automatically when you finish, cancel or close the shopping screen, so you log in again next time.")),

            // ---------------------------------------------------------------- Shopping
            new HelpTopic(Shopping, "How do I add an item to my cart?",
                new[] { "add", "scan", "code", "barcode", "search", "p001", "item", "product", "cart" },
                Lines(
                    "There are two ways:",
                    "- **Tap a product** card to add it.",
                    "- **Type a product code** (for example P001) in the search bar and press Enter, or tap **Add Item** or **Scan**.",
                    "If the code is not recognised you will see \"No product found\". If the item is already in your cart, use the **+** button in the cart instead.")),

            new HelpTopic(Shopping, "How do I browse by category?",
                new[] { "category", "categories", "browse", "filter", "dairy", "bakery", "produce", "meat", "seafood", "beverage", "pantry", "snack" },
                Lines(
                    "Use the buttons under the search bar: **All, Dairy, Bakery, Produce, Meat, Seafood, Beverages, Pantry, Snacks**.",
                    "The selected category turns green.")),

            new HelpTopic(Shopping, "How do I change quantity or remove an item?",
                new[] { "quantity", "remove", "delete", "plus", "minus", "increase", "decrease", "change", "more", "less" },
                Lines(
                    "Each row in your cart has three buttons:",
                    "- **+** adds one more (you are asked to confirm).",
                    "- **\u2212** removes one unit (you are asked to confirm).",
                    "- **X** removes that whole line from the cart.")),

            new HelpTopic(Shopping, "Why does it say 'Cart limit reached'?",
                new[] { "limit", "max", "10", "full", "too many", "only" },
                Lines(
                    "Your cart holds a maximum of **10 items in total**. The counter at the top of the cart shows how many you have, for example 3/10 items.",
                    "Remove something with **\u2212** or **X** to make room.",
                    "You may also see \"Sorry, only N of this item in stock\" if you ask for more than is on the shelf.")),

            new HelpTopic(Shopping, "What does SOLD OUT mean?",
                new[] { "sold out", "unavailable", "out of stock", "stock", "grey", "gray", "nearest store" },
                Lines(
                    "A greyed-out product with a red **SOLD OUT** tag cannot be bought right now. Tap it to open a pop-up with:",
                    "- **Find This Product at a Nearest Store** opens a map search for supermarkets near you.",
                    "- **Continue Shopping** closes the pop-up.")),

            new HelpTopic(Shopping, "How is VAT calculated?",
                new[] { "vat", "tax", "15", "price", "total", "subtotal", "cost" },
                Lines(
                    "Shelf prices exclude VAT. **15% VAT** is added to your subtotal.",
                    "The cart shows **Subtotal**, **Tax (15% VAT)** and **Total** in rands as you shop.")),

            new HelpTopic(Shopping, "How do I cancel my shopping?",
                new[] { "cancel", "stop", "quit", "leave", "exit", "empty" },
                Lines(
                    "Tap **X Cancel Transaction** at the top right.",
                    "If your cart has items you are asked to confirm. Then the cart is emptied, you are signed out, and the welcome screen returns.")),

            // ---------------------------------------------------------------- Checkout & receipt
            new HelpTopic(Checkout, "How do I check out?",
                new[] { "checkout", "check out", "pay", "proceed", "complete", "finish", "buy" },
                Lines(
                    "1. Tap **Proceed to Checkout** in the cart (it needs at least one item).",
                    "2. Review your items, subtotal, VAT and total.",
                    "3. Tap the payment box to **add a card**.",
                    "4. Optionally enter an email address or phone number for your receipt.",
                    "5. Tap **Complete Transaction**.",
                    "**Back** returns to shopping with your cart kept. **Cancel** ends the transaction.")),

            new HelpTopic(Checkout, "How do I add a card?",
                new[] { "card", "cvv", "expiry", "visa", "debit", "credit", "number", "payment" },
                Lines(
                    "Tap the payment box at checkout and enter:",
                    "- Cardholder name",
                    "- A valid 16-digit card number",
                    "- Expiry date as **MM/YY** (it must not be in the past)",
                    "- A 3-digit CVV",
                    "Once accepted, the box shows \"Card ending in ####\". Payment is simulated, so no real money is taken.")),

            new HelpTopic(Checkout, "How do I get my receipt?",
                new[] { "receipt", "pdf", "email", "sms", "phone", "text", "send", "save" },
                Lines(
                    "After payment is approved, tap **Save PDF & Send Receipt** and choose where to save the PDF.",
                    "- **Email address** entered: the PDF is emailed to you.",
                    "- **Phone number** entered (10 to 12 digits): the receipt is sent by SMS.",
                    "- **Box left empty**: your account email address is used.",
                    "The receipt lists every product, quantity, unit price, line total, VAT and the grand total.")),

            new HelpTopic(Checkout, "Why can't I complete my payment or receipt?",
                new[] { "error", "problem", "fail", "failed", "not working", "cannot", "can't", "cant", "wont", "won't", "issue", "invalid" },
                Lines(
                    "- **\"Please add a card\u2026\"**: add a valid card first.",
                    "- **\"Please enter a valid email address or phone number\"**: fix the receipt box, or leave it empty.",
                    "- **\"Item Unavailable\"**: an item sold out in the meantime. Go **Back** and adjust your cart.",
                    "- **Receipt delivery failed**: your payment is already recorded and the PDF is saved. Tap **Save PDF & Send Receipt** again to retry, or ask staff to check the email and SMS settings.")),

            // ---------------------------------------------------------------- Staff / Admin
            new HelpTopic(Staff, "How do staff open the admin area?",
                new[] { "admin", "staff", "manager", "dashboard", "change password", "locked", "change now" },
                Lines(
                    "1. On the welcome screen tap **Admin Access** (bottom right).",
                    "2. Enter the admin username and password.",
                    "Five wrong attempts close the login screen.",
                    "To change a password tap **Change now**. You must enter the current password, and the new one must be at least 6 characters.")),

            new HelpTopic(Staff, "How do I manage stock and availability?",
                new[] { "manage", "stock management", "availability", "available", "inventory", "restock", "switch off" },
                Lines(
                    "Open **Stock Management** in the admin dashboard. Each product row shows its code, stock, price and status.",
                    "- Change the **stock number** (0 to 1000). It saves immediately.",
                    "- Click **Available / Unavailable** to switch a product on or off. Unavailable products show SOLD OUT in the kiosk.",
                    "- Switching a product back on while its stock is 0 sets the stock to 1.")),

            new HelpTopic(Staff, "How do I view sales analytics?",
                new[] { "analytics", "sales", "revenue", "report", "transactions", "hour", "day", "month", "average" },
                Lines(
                    "Click **Analytics**, then choose **By Hour**, **By Day** or **By Month**.",
                    "Each view shows the number of transactions, revenue, the average sale and a list of recent transactions.",
                    "The dashboard also shows the total products, how many are out of stock, and the overall transactions and revenue.")),

            new HelpTopic(Staff, "What do Restart, Shut Down and Exit do?",
                new[] { "restart", "shutdown", "shut down", "system control", "exit admin", "return to kiosk", "open system" },
                Lines(
                    "Under **System Control**:",
                    "- **Restart System** shows a 3-second restart screen, then reloads all data.",
                    "- **Shut Down** shows the shutdown screen. **Open System** returns to the welcome screen.",
                    "- **Exit Admin** or **Return to kiosk** closes the dashboard."))
        };

        /// <summary>Finds the best matching topic for free text, or null if nothing relevant.</summary>
        public static HelpTopic Find(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return null;

            string t = text.ToLowerInvariant().Replace('\u2019', '\'');
            HelpTopic best = null;
            int bestScore = 0;

            foreach (HelpTopic topic in Topics)
            {
                int score = 0;
                foreach (string keyword in topic.Keywords)
                {
                    if (t.Contains(keyword))
                        score += keyword.Length > 3 ? 2 : 1;
                }

                if (score > bestScore)
                {
                    bestScore = score;
                    best = topic;
                }
            }

            return best;
        }
    }
}
