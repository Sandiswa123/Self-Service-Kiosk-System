using System.Reflection;
using System.Windows.Forms;

namespace FreshMartKiosk
{
    /// <summary>
    /// Turns on double buffering for a screen's panels so scrolling does not flicker or leave trails.
    /// WinForms hides the DoubleBuffered property on panels, so it is switched on with reflection.
    /// </summary>
    internal static class Smoothing
    {
        private static readonly PropertyInfo DoubleBufferedProperty =
            typeof(Control).GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);

        public static void Apply(Control root)
        {
            if (root == null || DoubleBufferedProperty == null) return;

            // Forms, Panels, FlowLayoutPanels and TableLayoutPanels only (text boxes etc. are left alone).
            if (root is ScrollableControl)
                DoubleBufferedProperty.SetValue(root, true, null);

            foreach (Control child in root.Controls)
                Apply(child);
        }
    }
}
