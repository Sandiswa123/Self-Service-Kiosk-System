using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;

namespace FreshMartKiosk
{
    /// <summary>
    /// All reads and writes of products and sales. The kiosk and the Admin screens both
    /// go through this class, so they always see the same data.
    /// </summary>
    public static class DataStore
    {
        public const int DefaultStock = 50;

        /// <summary>Folder that holds freshmart.db.</summary>
        public static string DataFolder => Database.DataFolder;

        // ------------------------------------------------------------------
        // Products
        // ------------------------------------------------------------------

        /// <summary>
        /// The starting product list. Used only to fill the Products table the first time
        /// (and to add any product that is missing). After that the database is the source of truth.
        /// </summary>
        internal static List<Product> DefaultCatalog()
        {
            return new List<Product>
            {
                P("P001", "Coca-Cola Original 1.5L x2",     32.99m, "Beverages"),
                P("P002", "Top Red Apples 1.5kg",           39.99m, "Produce"),
                P("P003", "Albany Low GI Brown Bread 700g", 19.99m, "Bakery"),
                P("P004", "Nulaid 18 Jumbo Eggs",           89.99m, "Dairy"),
                P("P005", "Clover Cheddar Cheese 100g",     22.99m, "Dairy"),
                P("P006", "Tastic Long Grain Rice 2kg",     55.99m, "Pantry"),
                P("P007", "B-well Canola Oil 750ml",        45.99m, "Pantry"),
                P("P008", "Fresh Chicken Braai Pack",       79.99m, "Meat"),
                P("P009", "Huletts Brown Sugar 500g",       18.99m, "Pantry"),
                P("P010", "Bananas 1kg",                    24.99m, "Produce"),
                P("P011", "Oranges 1.5kg",                  29.99m, "Produce"),
                P("P012", "Clover Tropika 2L",              38.99m, "Beverages"),
                P("P013", "Butchers Best Steak Pack",      129.99m, "Meat"),
                P("P014", "Simba Tomato Sauce Chips 120g",  21.99m, "Snacks"),
                P("P015", "Vanilla Cream Cake",            149.99m, "Bakery"),
                P("P016", "Seafood Platter Mix",           199.99m, "Seafood"),
            };
        }

        private static Product P(string id, string name, decimal price, string category)
        {
            return new Product
            {
                ProductId = id,
                ProductName = name,
                Price = price,
                Category = category,
                Barcode = id,
                Stock = DefaultStock,
                IsAvailable = true
            };
        }

        /// <summary>All products with their current stock and availability, ordered by code.</summary>
        public static List<Product> LoadCatalog()
        {
            var products = new List<Product>();

            using (DbConnection connection = Database.Open())
            using (DbCommand command = Database.Command(connection, null,
                "SELECT ProductId, ProductName, Category, PriceCents, Barcode, Stock, IsAvailable FROM Products ORDER BY ProductId"))
            using (DbDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    products.Add(new Product
                    {
                        ProductId = reader.GetString(0),
                        ProductName = reader.GetString(1),
                        Category = reader.GetString(2),
                        Price = Database.FromCents(Convert.ToInt64(reader.GetValue(3))),
                        Barcode = reader.GetString(4),
                        Stock = Convert.ToInt32(reader.GetValue(5)),
                        IsAvailable = Convert.ToInt64(reader.GetValue(6)) == 1
                    });
                }
            }

            return products;
        }

        /// <summary>Saves one product's stock and availability (used by Admin).</summary>
        public static void UpdateProduct(Product product)
        {
            using (DbConnection connection = Database.Open())
            {
                Database.Execute(connection, null,
                    "UPDATE Products SET Stock = @stock, IsAvailable = @available WHERE ProductId = @id",
                    "@stock", Math.Max(0, product.Stock),
                    "@available", product.IsAvailable ? 1 : 0,
                    "@id", product.ProductId);
            }
        }

        /// <summary>Saves stock and availability for many products in one database transaction.</summary>
        public static void SaveInventory(IEnumerable<Product> products)
        {
            using (DbConnection connection = Database.Open())
            using (DbTransaction transaction = connection.BeginTransaction())
            {
                foreach (Product product in products)
                {
                    Database.Execute(connection, transaction,
                        "UPDATE Products SET Stock = @stock, IsAvailable = @available WHERE ProductId = @id",
                        "@stock", Math.Max(0, product.Stock),
                        "@available", product.IsAvailable ? 1 : 0,
                        "@id", product.ProductId);
                }
                transaction.Commit();
            }
        }

        // ------------------------------------------------------------------
        // Sales
        // ------------------------------------------------------------------

        /// <summary>
        /// Records a completed sale. Everything happens inside ONE database transaction:
        ///   1. take each item off the shelf (only if it is still available and in stock)
        ///   2. save the sale
        ///   3. save each line item
        /// If any step fails, nothing is saved (the transaction is rolled back).
        /// </summary>
        /// <exception cref="SaleFailedException">An item sold out or was switched off meanwhile.</exception>
        public static TransactionRecord CompleteSale(ShoppingCart cart, string receiptContact = null)
        {
            if (cart.Items.Count == 0)
                throw new SaleFailedException("The cart is empty.");

            DateTime now = DateTime.Now;
            long subtotalCents = cart.Items.Sum(i => Database.ToCents(i.Product.Price) * i.Quantity);
            long vatCents = (long)Math.Round(subtotalCents * ShoppingCart.VatRate, MidpointRounding.AwayFromZero);

            using (DbConnection connection = Database.Open())
            using (DbTransaction transaction = connection.BeginTransaction())
            {
                // 1. Reduce stock. The WHERE clause refuses to sell what isn't there.
                foreach (CartItem item in cart.Items)
                {
                    int updated = Database.Execute(connection, transaction,
                        @"UPDATE Products SET Stock = Stock - @qty
                          WHERE ProductId = @id AND IsAvailable = 1 AND Stock >= @qty",
                        "@qty", item.Quantity, "@id", item.Product.ProductId);

                    if (updated == 0)
                    {
                        transaction.Rollback();
                        throw new SaleFailedException(
                            $"Sorry, \"{item.Product.ProductName}\" is no longer available in that quantity. " +
                            "Please go back to your cart and remove it.");
                    }
                }

                // 2. Save the sale. A temporary unique number is replaced with a readable one
                //    built from the new row's ID, e.g. TXN-20260922-00042.
                Database.Execute(connection, transaction,
                    @"INSERT INTO Transactions (TransactionNumber, CreatedAt, SubtotalCents, VatCents, TotalCents, ItemCount, ReceiptContact)
                      VALUES (@temp, @date, @subtotal, @vat, @total, @items, @contact)",
                    "@temp", Guid.NewGuid().ToString("N"),
                    "@date", now.ToString(Database.DateFormat, Database.Invariant),
                    "@subtotal", subtotalCents,
                    "@vat", vatCents,
                    "@total", subtotalCents + vatCents,
                    "@items", cart.ItemCount,
                    "@contact", string.IsNullOrWhiteSpace(receiptContact) ? null : receiptContact.Trim());

                long transactionId = Database.ScalarLong(connection, transaction, "SELECT last_insert_rowid()");
                string number = "TXN-" + now.ToString("yyyyMMdd", Database.Invariant) + "-" + transactionId.ToString("00000", Database.Invariant);

                Database.Execute(connection, transaction,
                    "UPDATE Transactions SET TransactionNumber = @number WHERE TransactionId = @id",
                    "@number", number, "@id", transactionId);

                // 3. Save the line items.
                foreach (CartItem item in cart.Items)
                {
                    Database.Execute(connection, transaction,
                        @"INSERT INTO TransactionItems (TransactionId, ProductId, Quantity, UnitPriceCents)
                          VALUES (@tid, @pid, @qty, @price)",
                        "@tid", transactionId, "@pid", item.Product.ProductId,
                        "@qty", item.Quantity, "@price", Database.ToCents(item.Product.Price));
                }

                transaction.Commit();

                return new TransactionRecord
                {
                    Number = number,
                    Date = now,
                    Subtotal = Database.FromCents(subtotalCents),
                    Vat = Database.FromCents(vatCents),
                    Total = Database.FromCents(subtotalCents + vatCents),
                    ItemCount = cart.ItemCount
                };
            }
        }

        /// <summary>All saved sales, newest first.</summary>
        public static List<TransactionRecord> LoadTransactions()
        {
            var list = new List<TransactionRecord>();

            using (DbConnection connection = Database.Open())
            using (DbCommand command = Database.Command(connection, null,
                @"SELECT TransactionNumber, CreatedAt, SubtotalCents, VatCents, TotalCents, ItemCount
                  FROM Transactions ORDER BY CreatedAt DESC, TransactionId DESC"))
            using (DbDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (!DateTime.TryParseExact(reader.GetString(1), Database.DateFormat, Database.Invariant,
                                                System.Globalization.DateTimeStyles.None, out DateTime date))
                        continue;

                    list.Add(new TransactionRecord
                    {
                        Number = reader.GetString(0),
                        Date = date,
                        Subtotal = Database.FromCents(Convert.ToInt64(reader.GetValue(2))),
                        Vat = Database.FromCents(Convert.ToInt64(reader.GetValue(3))),
                        Total = Database.FromCents(Convert.ToInt64(reader.GetValue(4))),
                        ItemCount = Convert.ToInt32(reader.GetValue(5))
                    });
                }
            }

            return list;
        }
    }

    public class TransactionRecord
    {
        public string Number { get; set; }
        public DateTime Date { get; set; }
        public decimal Subtotal { get; set; }
        public decimal Vat { get; set; }
        public decimal Total { get; set; }
        public int ItemCount { get; set; }
    }

    /// <summary>Thrown when a sale can't be completed; the message is safe to show the customer.</summary>
    public class SaleFailedException : Exception
    {
        public SaleFailedException(string message) : base(message) { }
    }
}
