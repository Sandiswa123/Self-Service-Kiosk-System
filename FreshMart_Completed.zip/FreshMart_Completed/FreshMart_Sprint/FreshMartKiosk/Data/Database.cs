﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Globalization;
using System.IO;

namespace FreshMartKiosk
{
    /// <summary>
    /// Opens the SQLite database and makes sure its tables exist.
    ///
    /// Database file:  Documents\FreshMart\freshmart.db
    /// (Documents is used because Program Files is read-only for normal users.)
    ///
    /// Tables
    ///   Products          one row per product (stock + availability set by Admin)
    ///   Transactions      one row per completed sale
    ///   TransactionItems  the products in each sale (FK -> Transactions, Products)
    ///   Users             admin logins (salted PBKDF2 hashes, never plain passwords)
    ///   CustomerAccounts  customer sign-up/login accounts (salted PBKDF2 hashes)
    ///
    /// Money is stored as INTEGER cents (R 32.99 -> 3299) because SQLite has no exact
    /// decimal type and REAL (floating point) can introduce rounding errors.
    /// </summary>
    public static class Database
    {
        public static readonly string DataFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "FreshMart");

        public static readonly string DatabasePath = Path.Combine(DataFolder, "freshmart.db");

        internal const string DateFormat = "yyyy-MM-dd HH:mm:ss";
        internal static readonly CultureInfo Invariant = CultureInfo.InvariantCulture;

        private static bool initialised;
        private static readonly object initLock = new object();

        private const string Schema = @"
CREATE TABLE IF NOT EXISTS Products (
    ProductId    TEXT    PRIMARY KEY,
    ProductName  TEXT    NOT NULL,
    Category     TEXT    NOT NULL,
    PriceCents   INTEGER NOT NULL CHECK (PriceCents >= 0),
    Barcode      TEXT    NOT NULL UNIQUE,
    Stock        INTEGER NOT NULL DEFAULT 50 CHECK (Stock >= 0),
    IsAvailable  INTEGER NOT NULL DEFAULT 1  CHECK (IsAvailable IN (0, 1))
);

CREATE TABLE IF NOT EXISTS Transactions (
    TransactionId     INTEGER PRIMARY KEY AUTOINCREMENT,
    TransactionNumber TEXT    NOT NULL UNIQUE,
    CreatedAt         TEXT    NOT NULL,          -- 'yyyy-MM-dd HH:mm:ss' local time
    SubtotalCents     INTEGER NOT NULL,
    VatCents          INTEGER NOT NULL,
    TotalCents        INTEGER NOT NULL,
    ItemCount         INTEGER NOT NULL CHECK (ItemCount >= 0),
    ReceiptContact    TEXT    NULL
);

CREATE INDEX IF NOT EXISTS IX_Transactions_CreatedAt ON Transactions (CreatedAt);

CREATE TABLE IF NOT EXISTS TransactionItems (
    TransactionId  INTEGER NOT NULL REFERENCES Transactions (TransactionId) ON DELETE CASCADE,
    ProductId      TEXT    NOT NULL REFERENCES Products (ProductId),
    Quantity       INTEGER NOT NULL CHECK (Quantity > 0),
    UnitPriceCents INTEGER NOT NULL,
    PRIMARY KEY (TransactionId, ProductId)
);

CREATE TABLE IF NOT EXISTS Users (
    Username     TEXT PRIMARY KEY COLLATE NOCASE,
    PasswordSalt TEXT NOT NULL,
    PasswordHash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS CustomerAccounts (
    CustomerId   INTEGER PRIMARY KEY AUTOINCREMENT,
    FullName     TEXT    NOT NULL,
    Email        TEXT    NOT NULL COLLATE NOCASE UNIQUE,
    Username     TEXT    NOT NULL COLLATE NOCASE UNIQUE,
    PasswordSalt TEXT    NOT NULL,
    PasswordHash TEXT    NOT NULL,
    CreatedAt    TEXT    NOT NULL,
    LastLoginAt  TEXT    NULL
);";

        // ------------------------------------------------------------------
        // Connections and command helpers
        // ------------------------------------------------------------------

        /// <summary>Opens a connection (creating the database on first use). Always wrap in "using".</summary>
        public static DbConnection Open()
        {
            EnsureCreated();
            return OpenRaw();
        }

        private static DbConnection OpenRaw()
        {
            Directory.CreateDirectory(DataFolder);

            var builder = new DbConnectionStringBuilder();
            builder["Data Source"] = DatabasePath;
            builder["Version"] = 3;

            DbConnection connection = SqliteProvider.CreateConnection(builder.ConnectionString);
            connection.Open();

            // SQLite switches foreign-key checking off by default; turn it on for every connection.
            Execute(connection, null, "PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 3000;");
            return connection;
        }

        /// <summary>Creates a command with named parameters, e.g. ("@id", "P001").</summary>
        internal static DbCommand Command(DbConnection connection, DbTransaction transaction, string sql,
                                          params object[] nameValuePairs)
        {
            DbCommand command = connection.CreateCommand();
            command.CommandText = sql;
            command.Transaction = transaction;

            for (int i = 0; i + 1 < nameValuePairs.Length; i += 2)
            {
                DbParameter parameter = command.CreateParameter();
                parameter.ParameterName = (string)nameValuePairs[i];
                parameter.Value = nameValuePairs[i + 1] ?? DBNull.Value;
                command.Parameters.Add(parameter);
            }
            return command;
        }

        internal static int Execute(DbConnection connection, DbTransaction transaction, string sql,
                                    params object[] nameValuePairs)
        {
            using (DbCommand command = Command(connection, transaction, sql, nameValuePairs))
                return command.ExecuteNonQuery();
        }

        internal static long ScalarLong(DbConnection connection, DbTransaction transaction, string sql,
                                        params object[] nameValuePairs)
        {
            using (DbCommand command = Command(connection, transaction, sql, nameValuePairs))
            {
                object result = command.ExecuteScalar();
                return (result == null || result == DBNull.Value) ? 0 : Convert.ToInt64(result, Invariant);
            }
        }

        internal static long ToCents(decimal rands) => (long)Math.Round(rands * 100m, MidpointRounding.AwayFromZero);
        internal static decimal FromCents(long cents) => cents / 100m;

        // ------------------------------------------------------------------
        // Creating the database
        // ------------------------------------------------------------------

        /// <summary>
        /// Creates the tables if they don't exist, adds any missing products, and imports
        /// data from the old text files once. Safe to call many times.
        /// </summary>
        public static void EnsureCreated()
        {
            if (initialised) return;

            lock (initLock)
            {
                if (initialised) return;

                using (DbConnection connection = OpenRaw())
                using (DbTransaction transaction = connection.BeginTransaction())
                {
                    Execute(connection, transaction, Schema);

                    // INSERT OR IGNORE: adds new products but never overwrites Admin's stock changes.
                    foreach (Product p in DataStore.DefaultCatalog())
                    {
                        Execute(connection, transaction,
                            @"INSERT OR IGNORE INTO Products (ProductId, ProductName, Category, PriceCents, Barcode, Stock, IsAvailable)
                              VALUES (@id, @name, @category, @price, @barcode, @stock, 1)",
                            "@id", p.ProductId, "@name", p.ProductName, "@category", p.Category,
                            "@price", ToCents(p.Price), "@barcode", p.Barcode, "@stock", p.Stock);
                    }

                    transaction.Commit();
                }

                initialised = true;
            }

            ImportLegacyTextFiles();
        }

        // ------------------------------------------------------------------
        // One-time import from the previous (text file) version
        // ------------------------------------------------------------------

        /// <summary>
        /// The previous version kept its data in inventory.txt / availability.txt / transactions.txt.
        /// Import them once, then rename each file to *.imported so it is never read again.
        /// </summary>
        private static void ImportLegacyTextFiles()
        {
            try
            {
                ImportFile("inventory.txt", (connection, transaction, parts) =>
                {
                    if (parts.Length == 3 &&
                        int.TryParse(parts[1], NumberStyles.Integer, Invariant, out int stock) &&
                        bool.TryParse(parts[2], out bool available))
                    {
                        Execute(connection, transaction,
                            "UPDATE Products SET Stock = @stock, IsAvailable = @available WHERE ProductId = @id",
                            "@stock", Math.Max(0, stock), "@available", available ? 1 : 0, "@id", parts[0].Trim());
                    }
                });

                ImportFile("availability.txt", (connection, transaction, parts) =>
                {
                    // Lines are applied in order, so the LAST entry for a product wins.
                    if (parts.Length == 2 && bool.TryParse(parts[1], out bool available))
                    {
                        Execute(connection, transaction,
                            "UPDATE Products SET IsAvailable = @available WHERE ProductId = @id",
                            "@available", available ? 1 : 0, "@id", parts[0].Trim());
                    }
                });

                ImportFile("transactions.txt", (connection, transaction, parts) =>
                {
                    if (parts.Length != 4) return;
                    if (!TryParseLegacyDate(parts[1], out DateTime date)) return;
                    if (!TryParseLegacyMoney(parts[2], out decimal total)) return;
                    if (!int.TryParse(parts[3], NumberStyles.Integer, Invariant, out int items)) return;

                    // Old files only stored the total (which included 15% VAT).
                    long totalCents = ToCents(total);
                    long subtotalCents = (long)Math.Round(totalCents / (1 + ShoppingCart.VatRate), MidpointRounding.AwayFromZero);

                    Execute(connection, transaction,
                        @"INSERT OR IGNORE INTO Transactions
                              (TransactionNumber, CreatedAt, SubtotalCents, VatCents, TotalCents, ItemCount)
                          VALUES (@number, @date, @subtotal, @vat, @total, @items)",
                        "@number", parts[0].Trim(), "@date", date.ToString(DateFormat, Invariant),
                        "@subtotal", subtotalCents, "@vat", totalCents - subtotalCents,
                        "@total", totalCents, "@items", items);
                });
            }
            catch (IOException) { /* a locked or unreadable old file is not worth crashing for */ }
            catch (UnauthorizedAccessException) { }
        }

        private static void ImportFile(string fileName, Action<DbConnection, DbTransaction, string[]> importLine)
        {
            string path = Path.Combine(DataFolder, fileName);
            if (!File.Exists(path)) return;

            using (DbConnection connection = OpenRaw())
            using (DbTransaction transaction = connection.BeginTransaction())
            {
                foreach (string line in File.ReadAllLines(path))
                {
                    if (!string.IsNullOrWhiteSpace(line))
                        importLine(connection, transaction, line.Split('|'));
                }
                transaction.Commit();
            }

            File.Move(path, path + ".imported");
        }

        private static bool TryParseLegacyDate(string text, out DateTime date)
        {
            return DateTime.TryParseExact(text.Trim(), DateFormat, Invariant, DateTimeStyles.None, out date)
                || DateTime.TryParse(text, out date);
        }

        /// <summary>Accepts "123.45" and also "123,45" (written by the very first version on SA settings).</summary>
        private static bool TryParseLegacyMoney(string text, out decimal value)
        {
            const NumberStyles style = NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign;
            text = text.Trim();
            return decimal.TryParse(text, style, Invariant, out value)
                || decimal.TryParse(text.Replace(',', '.'), style, Invariant, out value);
        }

        /// <summary>Reads old user files so existing admin accounts keep working.</summary>
        internal static IEnumerable<string[]> ReadLegacyUserLines(string path)
        {
            if (!File.Exists(path)) yield break;
            foreach (string line in File.ReadAllLines(path))
                if (!string.IsNullOrWhiteSpace(line))
                    yield return line.Split('|');
        }
    }
}
