using System.Data.Common;
using System.Data.SQLite;

namespace FreshMartKiosk
{
    /// <summary>
    /// The ONLY file that refers to the SQLite library (NuGet package System.Data.SQLite.Core).
    /// Everything else talks to the database through the standard ADO.NET classes
    /// (DbConnection, DbCommand, DbDataReader), so swapping databases means changing one line.
    /// </summary>
    internal static class SqliteProvider
    {
        public static DbConnection CreateConnection(string connectionString)
        {
            return new SQLiteConnection(connectionString);
        }
    }
}
