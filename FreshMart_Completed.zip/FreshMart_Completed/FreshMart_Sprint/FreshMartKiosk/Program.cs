using System;
using System.Windows.Forms;

namespace FreshMartKiosk
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point. The welcome screen is the main form:
        /// when it closes, the whole application closes.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                // Creates Documents\FreshMart\freshmart.db, its tables, the products and the admin account.
                FreshmartAdminLogIn.DatabaseHelper.EnsureDatabaseExists();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "The kiosk database could not be opened, so the kiosk cannot start.\n\n" +
                    "Database: " + Database.DatabasePath + "\n\n" +
                    "If this is the first build, make sure the NuGet package 'System.Data.SQLite.Core' " +
                    "was restored (right-click the solution > Restore NuGet Packages), then rebuild.\n\n" +
                    "Details: " + ex.Message,
                    "FreshMart Kiosk", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Application.Run(new FormWelcome());
        }
    }
}
