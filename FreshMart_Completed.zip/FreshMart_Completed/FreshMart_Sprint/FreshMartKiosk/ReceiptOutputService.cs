using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FreshMartKiosk
{
    internal static class ReceiptOutputService
    {
        public static string SaveAsPdf(IWin32Window owner, string receiptText, string transactionNumber)
        {
            string receiptFolder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "FreshMart", "Receipts");
            Directory.CreateDirectory(receiptFolder);

            using (var dialog = new SaveFileDialog
            {
                AddExtension = true,
                DefaultExt = "pdf",
                FileName = "FreshMart-" + transactionNumber + ".pdf",
                Filter = "PDF files (*.pdf)|*.pdf",
                InitialDirectory = receiptFolder,
                OverwritePrompt = true
            })
            {
                if (dialog.ShowDialog(owner) != DialogResult.OK) return null;

                string printerName = null;
                foreach (string installedPrinter in PrinterSettings.InstalledPrinters)
                {
                    if (installedPrinter.IndexOf("Microsoft Print to PDF", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        printerName = installedPrinter;
                        break;
                    }
                }

                if (printerName == null)
                    throw new InvalidOperationException("Microsoft Print to PDF is not installed on this device.");

                using (var document = new PrintDocument())
                using (var font = new Font("Arial", 10))
                {
                    document.PrinterSettings.PrinterName = printerName;
                    document.PrinterSettings.PrintToFile = true;
                    document.PrinterSettings.PrintFileName = dialog.FileName;
                    document.DocumentName = "FreshMart Receipt " + transactionNumber;
                    document.DefaultPageSettings.Margins = new Margins(50, 50, 50, 50);

                    List<string> printableLines = null;
                    int lineIndex = 0;
                    document.PrintPage += (sender, args) =>
                    {
                        if (printableLines == null)
                            printableLines = WrapLines(receiptText, args.Graphics, font, args.MarginBounds.Width);

                        float y = args.MarginBounds.Top;
                        float lineHeight = font.GetHeight(args.Graphics) + 4;
                        while (lineIndex < printableLines.Count && y + lineHeight <= args.MarginBounds.Bottom)
                        {
                            args.Graphics.DrawString(printableLines[lineIndex], font, Brushes.Black,
                                args.MarginBounds.Left, y);
                            lineIndex++;
                            y += lineHeight;
                        }

                        args.HasMorePages = lineIndex < printableLines.Count;
                    };

                    document.Print();
                }

                if (!File.Exists(dialog.FileName) || new FileInfo(dialog.FileName).Length == 0)
                    throw new IOException("Windows did not create the PDF file.");

                return dialog.FileName;
            }
        }

        public static async Task SendEmailAsync(string recipient, string transactionNumber, string receiptText, string pdfPath)
        {
            string host = RequiredSetting("FRESHMART_SMTP_HOST");
            string username = RequiredSetting("FRESHMART_SMTP_USERNAME");
            string password = RequiredSetting("FRESHMART_SMTP_PASSWORD");
            string sender = RequiredSetting("FRESHMART_SMTP_FROM");
            int port = ReadPort("FRESHMART_SMTP_PORT", 587);
            bool enableSsl = ReadBoolean("FRESHMART_SMTP_SSL", true);

            using (var message = new MailMessage(sender, recipient))
            using (var attachment = new Attachment(pdfPath))
            using (var client = new SmtpClient(host, port))
            {
                message.Subject = "FreshMart receipt " + transactionNumber;
                message.Body = receiptText;
                message.Attachments.Add(attachment);
                client.EnableSsl = enableSsl;
                client.Credentials = new NetworkCredential(username, password);
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                await client.SendMailAsync(message);
            }
        }

        public static async Task<int> SendSmsAsync(string recipient, string receiptText, int alreadySentParts, Action<int> onPartSent)
        {
            string accountSid = RequiredSetting("TWILIO_ACCOUNT_SID");
            string authToken = RequiredSetting("TWILIO_AUTH_TOKEN");
            string sender = RequiredSetting("TWILIO_FROM_NUMBER");
            var parts = SplitSms(receiptText, 1300);

            using (var client = new HttpClient())
            {
                string credentials = Convert.ToBase64String(Encoding.ASCII.GetBytes(accountSid + ":" + authToken));
                client.DefaultRequestHeaders.Authorization =
                    new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", credentials);

                string endpoint = "https://api.twilio.com/2010-04-01/Accounts/" +
                    Uri.EscapeDataString(accountSid) + "/Messages.json";
                for (int index = alreadySentParts; index < parts.Count; index++)
                {
                    string messageBody = parts.Count == 1
                        ? parts[index]
                        : "Receipt part " + (index + 1) + "/" + parts.Count + "\n" + parts[index];
                    using (var content = new FormUrlEncodedContent(new[]
                    {
                        new System.Collections.Generic.KeyValuePair<string, string>("To", recipient),
                        new System.Collections.Generic.KeyValuePair<string, string>("From", sender),
                        new System.Collections.Generic.KeyValuePair<string, string>("Body", messageBody)
                    }))
                    using (HttpResponseMessage response = await client.PostAsync(endpoint, content))
                    {
                        if (!response.IsSuccessStatusCode)
                            throw new InvalidOperationException("SMS provider returned HTTP " + (int)response.StatusCode + ".");
                    }

                    onPartSent(index + 1);
                }
            }

            return parts.Count;
        }

        private static List<string> WrapLines(string text, Graphics graphics, Font font, float maxWidth)
        {
            var lines = new List<string>();
            foreach (string sourceLine in text.Replace("\r\n", "\n").Split('\n'))
            {
                if (sourceLine.Length == 0)
                {
                    lines.Add(string.Empty);
                    continue;
                }

                string remaining = sourceLine;
                while (remaining.Length > 0)
                {
                    int length = remaining.Length;
                    while (length > 1 && graphics.MeasureString(remaining.Substring(0, length), font).Width > maxWidth)
                        length--;

                    if (length < remaining.Length)
                    {
                        int lastSpace = remaining.LastIndexOf(' ', length - 1, length);
                        if (lastSpace > 0) length = lastSpace;
                    }

                    lines.Add(remaining.Substring(0, length).TrimEnd());
                    remaining = remaining.Substring(length).TrimStart();
                }
            }

            return lines;
        }

        private static System.Collections.Generic.List<string> SplitSms(string text, int maxLength)
        {
            var parts = new System.Collections.Generic.List<string>();
            var current = new StringBuilder();

            foreach (string sourceLine in text.Replace("\r\n", "\n").Split('\n'))
            {
                string remaining = sourceLine;
                do
                {
                    int available = maxLength - current.Length - (current.Length == 0 ? 0 : 1);
                    if (remaining.Length > available && current.Length > 0)
                    {
                        parts.Add(current.ToString());
                        current.Clear();
                        continue;
                    }

                    if (remaining.Length > maxLength)
                    {
                        parts.Add(remaining.Substring(0, maxLength));
                        remaining = remaining.Substring(maxLength);
                        continue;
                    }

                    if (current.Length > 0) current.AppendLine();
                    current.Append(remaining);
                    remaining = string.Empty;
                } while (remaining.Length > 0);
            }

            if (current.Length > 0 || parts.Count == 0) parts.Add(current.ToString());
            return parts;
        }

        private static string RequiredSetting(string name)
        {
            string value = Environment.GetEnvironmentVariable(name);
            if (string.IsNullOrWhiteSpace(value))
                throw new InvalidOperationException("Receipt delivery is not configured. Set the " + name + " environment variable and retry.");
            return value.Trim();
        }

        private static int ReadPort(string name, int defaultValue)
        {
            string value = Environment.GetEnvironmentVariable(name);
            if (string.IsNullOrWhiteSpace(value)) return defaultValue;
            if (int.TryParse(value, out int port) && port > 0 && port <= 65535) return port;
            throw new InvalidOperationException(name + " must be a valid TCP port number.");
        }

        private static bool ReadBoolean(string name, bool defaultValue)
        {
            string value = Environment.GetEnvironmentVariable(name);
            if (string.IsNullOrWhiteSpace(value)) return defaultValue;
            if (bool.TryParse(value, out bool enabled)) return enabled;
            throw new InvalidOperationException(name + " must be true or false.");
        }
    }
}