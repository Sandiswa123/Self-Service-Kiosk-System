using System;
using System.Drawing;
using System.Windows.Forms;
using FreshMartKiosk;

namespace Admin
{
    /// <summary>
    /// "Restarting..." animation. Opened with ShowDialog(); closes itself after 3 seconds.
    /// The dashboard then reloads all data from disk.
    /// </summary>
    public partial class frmRestart : Form
    {
        private const int DurationMs = 3000;
        private int elapsedTime = 0;
        private readonly Image spinnerImage;

        public frmRestart()
        {
            InitializeComponent();

            // FIX: the old code rotated the shared designer image, which left it
            // upside-down (30 x 90° turns) for the next restart.
            // Our own copy of the icon, which we are free to rotate.
            spinnerImage = AppImages.Load("Admin", "restart.png");
            picRestart.Image = spinnerImage;

            timerRestart.Interval = 100;
            CenterRestartContent();
        }

        private void CenterRestartContent()
        {
            pnlRestartContent.Left = (ClientSize.Width - pnlRestartContent.Width) / 2;
            pnlRestartContent.Top = (ClientSize.Height - pnlRestartContent.Height) / 2;
        }

        private void timerRestart_Tick(object sender, EventArgs e)
        {
            elapsedTime += timerRestart.Interval;

            if (spinnerImage != null)
            {
                spinnerImage.RotateFlip(RotateFlipType.Rotate90FlipNone);
                picRestart.Invalidate();
            }

            if (elapsedTime >= DurationMs)
            {
                timerRestart.Stop();
                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private void frmRestart_Resize(object sender, EventArgs e)
        {
            CenterRestartContent();
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            timerRestart.Stop();
            base.OnFormClosed(e);
        }
    }
}
