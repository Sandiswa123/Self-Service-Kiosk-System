using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using FreshMartKiosk;

namespace Admin
{
    /// <summary>
    /// Sales analytics for this hour / today / this month.
    /// Opened with ShowDialog() from the dashboard; "Back" simply closes it.
    /// </summary>
    public partial class frmAnalytics : Form
    {
        private static readonly Color TabOn = Color.FromArgb(0, 180, 100);
        private static readonly Color TabOff = Color.FromArgb(35, 53, 80);

        private List<TransactionRecord> allTransactions;

        public frmAnalytics()
        {
            InitializeComponent();
            allTransactions = DataStore.LoadTransactions();   // one read, newest first
            ShowHour();

            FreshMartKiosk.HelpAssistant.Attach(this, FreshMartKiosk.HelpKnowledge.Staff);
        }

        // ------------------------------------------------------------------
        // Tabs
        // ------------------------------------------------------------------

        private void btnByHour_Click(object sender, EventArgs e) => ShowHour();
        private void btnByDay_Click(object sender, EventArgs e) => ShowDay();
        private void btnByMonth_Click(object sender, EventArgs e) => ShowMonth();

        private void ShowHour()
        {
            SelectTab(btnByHour, pnlByHour, pnlRecentTransactions);

            DateTime hourStart = DateTime.Today.AddHours(DateTime.Now.Hour);
            Fill(allTransactions.Where(t => t.Date >= hourStart && t.Date < hourStart.AddHours(1)),
                 flpRecentTransactionsHour, lblHourTransactions, lblRevenueHour, lblHourTransaction);
        }

        private void ShowDay()
        {
            SelectTab(btnByDay, pnlByDay, pnlRecentTransactionDay);

            Fill(allTransactions.Where(t => t.Date.Date == DateTime.Today),
                 flpRecentTransactionDay, lblDayTransactions, lblDayRevenue, lblDayAverage);
        }

        private void ShowMonth()
        {
            SelectTab(btnByMonth, pnlByMonth, pnlMonthlyRecentTransactions);

            // FIX: the old code wrote the count, revenue AND average all into lblMontlyRevenue.
            Fill(allTransactions.Where(t => t.Date.Year == DateTime.Today.Year && t.Date.Month == DateTime.Today.Month),
                 flpRecentTransactionMonthly, lblTransactionsMonthly, lblMontlyRevenue, lblAvgTransactionMonthly);
        }

        private void SelectTab(Button tab, Panel summaryPanel, Panel listPanel)
        {
            foreach (Button b in new[] { btnByHour, btnByDay, btnByMonth })
                b.BackColor = (b == tab) ? TabOn : TabOff;

            foreach (Panel p in new[] { pnlByHour, pnlRecentTransactions, pnlByDay, pnlRecentTransactionDay, pnlByMonth, pnlMonthlyRecentTransactions })
                p.Visible = (p == summaryPanel || p == listPanel);

            summaryPanel.BringToFront();
            listPanel.BringToFront();
        }

        // ------------------------------------------------------------------
        // Shared fill logic (the old file had this copied three times)
        // ------------------------------------------------------------------

        private void Fill(IEnumerable<TransactionRecord> transactions, FlowLayoutPanel list,
                          Label countLabel, Label revenueLabel, Label averageLabel)
        {
            List<TransactionRecord> selected = transactions.ToList();

            list.SuspendLayout();
            list.Controls.Clear();
            foreach (TransactionRecord t in selected)
                list.Controls.Add(CreateTransactionRow(t, list));
            list.ResumeLayout();

            decimal revenue = selected.Sum(t => t.Total);
            decimal average = selected.Count > 0 ? revenue / selected.Count : 0m;

            countLabel.Text = selected.Count.ToString();
            revenueLabel.Text = "R " + revenue.ToString("0.00");
            averageLabel.Text = "R " + average.ToString("0.00");
        }

        private static Panel CreateTransactionRow(TransactionRecord t, FlowLayoutPanel list)
        {
            var row = new Panel
            {
                Width = Math.Max(300, list.ClientSize.Width - 25),
                Height = 80,
                BackColor = Color.FromArgb(31, 49, 75),
                Margin = new Padding(0, 0, 0, 5)
            };

            row.Controls.Add(new Label
            {
                Text = t.Number,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(10, 10)
            });
            row.Controls.Add(new Label
            {
                Text = t.Date.ToString("dddd, MMMM d, yyyy • hh:mm:ss tt"),
                ForeColor = Color.LightSteelBlue,
                Font = new Font("Segoe UI", 9),
                AutoSize = true,
                Location = new Point(10, 38)
            });
            row.Controls.Add(new Label
            {
                Text = "R " + t.Total.ToString("0.00"),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(row.Width - 140, 10),
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            });
            row.Controls.Add(new Label
            {
                Text = t.ItemCount == 1 ? "1 item" : t.ItemCount + " items",
                ForeColor = Color.LightSteelBlue,
                Font = new Font("Segoe UI", 9),
                AutoSize = true,
                Location = new Point(row.Width - 140, 38),
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            });

            return row;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            // FIX: used to create a brand-new dashboard each time, stacking hidden forms.
            Close();
        }

        private void pnlByDay_Paint(object sender, PaintEventArgs e) { }
    }
}
