using System;
using System.Windows.Forms;

namespace Admin
{
    /// <summary>
    /// "System shut down" screen. Opened with ShowDialog() from the dashboard.
    /// "Open System" closes it; the dashboard then closes too and the kiosk
    /// welcome screen comes back. (Alt+F4 on the welcome screen exits the app.)
    /// </summary>
    public partial class frmShutdown : Form
    {
        public frmShutdown()
        {
            InitializeComponent();
            picPowersign.Image = FreshMartKiosk.AppImages.Load("Admin", "power.jpg");
            WindowState = FormWindowState.Maximized;
            Resize += (s, e) => CenterContent();
        }

        private void frmShutdown_Load(object sender, EventArgs e)
        {
            CenterContent();
        }

        private void CenterContent()
        {
            btnOpenSytem.Left = (ClientSize.Width - btnOpenSytem.Width) / 2;
            btnOpenSytem.Top = (ClientSize.Height - btnOpenSytem.Height) / 2;

            lblSystemShut.Left = (ClientSize.Width - lblSystemShut.Width) / 2;
            lblSystemShut.Top = btnOpenSytem.Top - lblSystemShut.Height - 20;

            picPowersign.Left = (ClientSize.Width - picPowersign.Width) / 2;
            picPowersign.Top = lblSystemShut.Top - picPowersign.Height - 20;
        }

        private void btnOpenSytem_Click(object sender, EventArgs e)
        {
            // FIX: used to open a NEW welcome screen and hide this one, leaving
            // hidden forms (and the process) running forever.
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
