﻿namespace Admin
{
    partial class frmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblAdminIcon = new System.Windows.Forms.Label();
            this.lblSystemOnline = new System.Windows.Forms.Label();
            this.btnExitAdmin = new System.Windows.Forms.Button();
            this.lblDateTime = new System.Windows.Forms.Label();
            this.lblAdminTttle = new System.Windows.Forms.Label();
            this.pnlSummary = new System.Windows.Forms.Panel();
            this.pnlOutOfStock = new System.Windows.Forms.Panel();
            this.lblOutStockValue = new System.Windows.Forms.Label();
            this.lblOutofStock = new System.Windows.Forms.Label();
            this.pnlProductsList = new System.Windows.Forms.Panel();
            this.lblProductValue = new System.Windows.Forms.Label();
            this.lblProductListed = new System.Windows.Forms.Label();
            this.pnlRevenue = new System.Windows.Forms.Panel();
            this.lblRevenueValue = new System.Windows.Forms.Label();
            this.lblRevenue = new System.Windows.Forms.Label();
            this.pnlTransactions = new System.Windows.Forms.Panel();
            this.lblTransactionValue = new System.Windows.Forms.Label();
            this.lblTransactionTittle = new System.Windows.Forms.Label();
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.btnSystemControl = new System.Windows.Forms.Button();
            this.btnAnalytics = new System.Windows.Forms.Button();
            this.btnStockMangement = new System.Windows.Forms.Button();
            this.pnlProductMangement = new System.Windows.Forms.Panel();
            this.lblProductitem = new System.Windows.Forms.Label();
            this.lblCode = new System.Windows.Forms.Label();
            this.pnlHeaderLine = new System.Windows.Forms.Panel();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblStock = new System.Windows.Forms.Label();
            this.pnlSystemControl = new System.Windows.Forms.Panel();
            this.picExit = new System.Windows.Forms.PictureBox();
            this.lblExit = new System.Windows.Forms.Label();
            this.lblReturnKiosk = new System.Windows.Forms.Label();
            this.lblRestartDescription = new System.Windows.Forms.Label();
            this.picRestart = new System.Windows.Forms.PictureBox();
            this.lblPoweroff = new System.Windows.Forms.Label();
            this.lblShutdownSystem = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnShutdownSystem = new System.Windows.Forms.Button();
            this.pnlSystemStatus = new System.Windows.Forms.Panel();
            this.pnlCurrentTime = new System.Windows.Forms.Panel();
            this.lblCurrentTime = new System.Windows.Forms.Label();
            this.lblCurrentTimeTitle = new System.Windows.Forms.Label();
            this.pnlUptime = new System.Windows.Forms.Panel();
            this.lblUptime = new System.Windows.Forms.Label();
            this.lblUptimeTitle = new System.Windows.Forms.Label();
            this.lblKioskStatus = new System.Windows.Forms.Label();
            this.lblStatusDot = new System.Windows.Forms.Label();
            this.lblSystemStatus = new System.Windows.Forms.Label();
            this.lblRestartSystem = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.btnRestartSystem = new System.Windows.Forms.Button();
            this.btnReturnKiosk = new System.Windows.Forms.Button();
            this.pnlSystemCtrl = new System.Windows.Forms.Panel();
            this.flpProducts = new System.Windows.Forms.FlowLayoutPanel();
            this.timerClock = new System.Windows.Forms.Timer(this.components);
            this.pnlHeader.SuspendLayout();
            this.pnlSummary.SuspendLayout();
            this.pnlOutOfStock.SuspendLayout();
            this.pnlProductsList.SuspendLayout();
            this.pnlRevenue.SuspendLayout();
            this.pnlTransactions.SuspendLayout();
            this.pnlMenu.SuspendLayout();
            this.pnlProductMangement.SuspendLayout();
            this.pnlSystemControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRestart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.pnlSystemStatus.SuspendLayout();
            this.pnlCurrentTime.SuspendLayout();
            this.pnlUptime.SuspendLayout();
            this.flpProducts.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(42)))), ((int)(((byte)(65)))));
            this.pnlHeader.Controls.Add(this.lblAdminIcon);
            this.pnlHeader.Controls.Add(this.lblSystemOnline);
            this.pnlHeader.Controls.Add(this.btnExitAdmin);
            this.pnlHeader.Controls.Add(this.lblDateTime);
            this.pnlHeader.Controls.Add(this.lblAdminTttle);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(1812, 244);
            this.pnlHeader.TabIndex = 0;
            // 
            // lblAdminIcon
            // 
            this.lblAdminIcon.BackColor = System.Drawing.Color.Orange;
            this.lblAdminIcon.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminIcon.ForeColor = System.Drawing.Color.White;
            this.lblAdminIcon.Location = new System.Drawing.Point(3, 23);
            this.lblAdminIcon.Name = "lblAdminIcon";
            this.lblAdminIcon.Size = new System.Drawing.Size(45, 45);
            this.lblAdminIcon.TabIndex = 4;
            this.lblAdminIcon.Text = "A";
            // 
            // lblSystemOnline
            // 
            this.lblSystemOnline.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSystemOnline.AutoSize = true;
            this.lblSystemOnline.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSystemOnline.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblSystemOnline.Location = new System.Drawing.Point(1537, 31);
            this.lblSystemOnline.Name = "lblSystemOnline";
            this.lblSystemOnline.Size = new System.Drawing.Size(125, 23);
            this.lblSystemOnline.TabIndex = 3;
            this.lblSystemOnline.Text = "System Online";
            // 
            // btnExitAdmin
            // 
            this.btnExitAdmin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExitAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.btnExitAdmin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExitAdmin.FlatAppearance.BorderSize = 0;
            this.btnExitAdmin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnExitAdmin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnExitAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExitAdmin.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExitAdmin.ForeColor = System.Drawing.Color.White;
            this.btnExitAdmin.Location = new System.Drawing.Point(1679, 22);
            this.btnExitAdmin.Name = "btnExitAdmin";
            this.btnExitAdmin.Size = new System.Drawing.Size(125, 45);
            this.btnExitAdmin.TabIndex = 2;
            this.btnExitAdmin.Text = "Exit Admin";
            this.btnExitAdmin.UseVisualStyleBackColor = false;
            this.btnExitAdmin.Click += new System.EventHandler(this.btnExitAdmin_Click);
            // 
            // lblDateTime
            // 
            this.lblDateTime.AutoSize = true;
            this.lblDateTime.BackColor = System.Drawing.Color.Transparent;
            this.lblDateTime.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateTime.ForeColor = System.Drawing.Color.LightGray;
            this.lblDateTime.Location = new System.Drawing.Point(45, 68);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(0, 23);
            this.lblDateTime.TabIndex = 1;
            // 
            // lblAdminTttle
            // 
            this.lblAdminTttle.AutoSize = true;
            this.lblAdminTttle.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminTttle.ForeColor = System.Drawing.Color.White;
            this.lblAdminTttle.Location = new System.Drawing.Point(64, 22);
            this.lblAdminTttle.Name = "lblAdminTttle";
            this.lblAdminTttle.Size = new System.Drawing.Size(299, 45);
            this.lblAdminTttle.TabIndex = 0;
            this.lblAdminTttle.Text = "Admin Dashboard";
            // 
            // pnlSummary
            // 
            this.pnlSummary.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlSummary.Controls.Add(this.pnlOutOfStock);
            this.pnlSummary.Controls.Add(this.pnlProductsList);
            this.pnlSummary.Controls.Add(this.pnlRevenue);
            this.pnlSummary.Controls.Add(this.pnlTransactions);
            this.pnlSummary.Location = new System.Drawing.Point(0, 106);
            this.pnlSummary.Name = "pnlSummary";
            this.pnlSummary.Size = new System.Drawing.Size(1812, 141);
            this.pnlSummary.TabIndex = 1;
            // 
            // pnlOutOfStock
            // 
            this.pnlOutOfStock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(45)))), ((int)(((byte)(68)))));
            this.pnlOutOfStock.Controls.Add(this.lblOutStockValue);
            this.pnlOutOfStock.Controls.Add(this.lblOutofStock);
            this.pnlOutOfStock.Location = new System.Drawing.Point(1272, 21);
            this.pnlOutOfStock.Name = "pnlOutOfStock";
            this.pnlOutOfStock.Size = new System.Drawing.Size(360, 102);
            this.pnlOutOfStock.TabIndex = 3;
            // 
            // lblOutStockValue
            // 
            this.lblOutStockValue.AutoSize = true;
            this.lblOutStockValue.BackColor = System.Drawing.Color.Transparent;
            this.lblOutStockValue.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutStockValue.ForeColor = System.Drawing.Color.White;
            this.lblOutStockValue.Location = new System.Drawing.Point(36, 58);
            this.lblOutStockValue.Name = "lblOutStockValue";
            this.lblOutStockValue.Size = new System.Drawing.Size(33, 38);
            this.lblOutStockValue.TabIndex = 1;
            this.lblOutStockValue.Text = "0";
            // 
            // lblOutofStock
            // 
            this.lblOutofStock.AutoSize = true;
            this.lblOutofStock.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutofStock.ForeColor = System.Drawing.Color.White;
            this.lblOutofStock.Location = new System.Drawing.Point(3, 20);
            this.lblOutofStock.Name = "lblOutofStock";
            this.lblOutofStock.Size = new System.Drawing.Size(132, 23);
            this.lblOutofStock.TabIndex = 0;
            this.lblOutofStock.Text = "⚠️ Out of Stock";
            // 
            // pnlProductsList
            // 
            this.pnlProductsList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(45)))), ((int)(((byte)(68)))));
            this.pnlProductsList.Controls.Add(this.lblProductValue);
            this.pnlProductsList.Controls.Add(this.lblProductListed);
            this.pnlProductsList.Location = new System.Drawing.Point(834, 21);
            this.pnlProductsList.Name = "pnlProductsList";
            this.pnlProductsList.Size = new System.Drawing.Size(410, 102);
            this.pnlProductsList.TabIndex = 2;
            // 
            // lblProductValue
            // 
            this.lblProductValue.AutoSize = true;
            this.lblProductValue.BackColor = System.Drawing.Color.Transparent;
            this.lblProductValue.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductValue.ForeColor = System.Drawing.Color.White;
            this.lblProductValue.Location = new System.Drawing.Point(13, 58);
            this.lblProductValue.Name = "lblProductValue";
            this.lblProductValue.Size = new System.Drawing.Size(33, 38);
            this.lblProductValue.TabIndex = 1;
            this.lblProductValue.Text = "0";
            // 
            // lblProductListed
            // 
            this.lblProductListed.AutoSize = true;
            this.lblProductListed.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductListed.ForeColor = System.Drawing.Color.White;
            this.lblProductListed.Location = new System.Drawing.Point(3, 20);
            this.lblProductListed.Name = "lblProductListed";
            this.lblProductListed.Size = new System.Drawing.Size(149, 23);
            this.lblProductListed.TabIndex = 0;
            this.lblProductListed.Text = "📦Products Listed";
            // 
            // pnlRevenue
            // 
            this.pnlRevenue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(45)))), ((int)(((byte)(68)))));
            this.pnlRevenue.Controls.Add(this.lblRevenueValue);
            this.pnlRevenue.Controls.Add(this.lblRevenue);
            this.pnlRevenue.Location = new System.Drawing.Point(393, 21);
            this.pnlRevenue.Name = "pnlRevenue";
            this.pnlRevenue.Size = new System.Drawing.Size(413, 102);
            this.pnlRevenue.TabIndex = 1;
            // 
            // lblRevenueValue
            // 
            this.lblRevenueValue.AutoSize = true;
            this.lblRevenueValue.BackColor = System.Drawing.Color.Transparent;
            this.lblRevenueValue.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRevenueValue.ForeColor = System.Drawing.Color.White;
            this.lblRevenueValue.Location = new System.Drawing.Point(36, 58);
            this.lblRevenueValue.Name = "lblRevenueValue";
            this.lblRevenueValue.Size = new System.Drawing.Size(33, 38);
            this.lblRevenueValue.TabIndex = 1;
            this.lblRevenueValue.Text = "0";
            // 
            // lblRevenue
            // 
            this.lblRevenue.AutoSize = true;
            this.lblRevenue.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRevenue.ForeColor = System.Drawing.Color.White;
            this.lblRevenue.Location = new System.Drawing.Point(16, 20);
            this.lblRevenue.Name = "lblRevenue";
            this.lblRevenue.Size = new System.Drawing.Size(144, 23);
            this.lblRevenue.TabIndex = 0;
            this.lblRevenue.Text = " 💰Total Revenue";
            // 
            // pnlTransactions
            // 
            this.pnlTransactions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(45)))), ((int)(((byte)(68)))));
            this.pnlTransactions.Controls.Add(this.lblTransactionValue);
            this.pnlTransactions.Controls.Add(this.lblTransactionTittle);
            this.pnlTransactions.Location = new System.Drawing.Point(12, 20);
            this.pnlTransactions.Name = "pnlTransactions";
            this.pnlTransactions.Size = new System.Drawing.Size(351, 102);
            this.pnlTransactions.TabIndex = 0;
            // 
            // lblTransactionValue
            // 
            this.lblTransactionValue.AutoSize = true;
            this.lblTransactionValue.BackColor = System.Drawing.Color.Transparent;
            this.lblTransactionValue.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransactionValue.ForeColor = System.Drawing.Color.White;
            this.lblTransactionValue.Location = new System.Drawing.Point(3, 59);
            this.lblTransactionValue.Name = "lblTransactionValue";
            this.lblTransactionValue.Size = new System.Drawing.Size(33, 38);
            this.lblTransactionValue.TabIndex = 1;
            this.lblTransactionValue.Text = "0";
            // 
            // lblTransactionTittle
            // 
            this.lblTransactionTittle.AutoSize = true;
            this.lblTransactionTittle.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransactionTittle.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.lblTransactionTittle.Location = new System.Drawing.Point(3, 21);
            this.lblTransactionTittle.Name = "lblTransactionTittle";
            this.lblTransactionTittle.Size = new System.Drawing.Size(173, 23);
            this.lblTransactionTittle.TabIndex = 0;
            this.lblTransactionTittle.Text = "📊 Total Transactions";
            // 
            // pnlMenu
            // 
            this.pnlMenu.Controls.Add(this.btnSystemControl);
            this.pnlMenu.Controls.Add(this.btnAnalytics);
            this.pnlMenu.Controls.Add(this.btnStockMangement);
            this.pnlMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlMenu.Location = new System.Drawing.Point(0, 244);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(1812, 88);
            this.pnlMenu.TabIndex = 2;
            // 
            // btnSystemControl
            // 
            this.btnSystemControl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSystemControl.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSystemControl.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.btnSystemControl.Location = new System.Drawing.Point(640, 8);
            this.btnSystemControl.Name = "btnSystemControl";
            this.btnSystemControl.Size = new System.Drawing.Size(250, 45);
            this.btnSystemControl.TabIndex = 3;
            this.btnSystemControl.Text = "System Control";
            this.btnSystemControl.UseVisualStyleBackColor = true;
            this.btnSystemControl.Click += new System.EventHandler(this.btnSystemControl_Click);
            // 
            // btnAnalytics
            // 
            this.btnAnalytics.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnalytics.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnalytics.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.btnAnalytics.Location = new System.Drawing.Point(348, 8);
            this.btnAnalytics.Name = "btnAnalytics";
            this.btnAnalytics.Size = new System.Drawing.Size(257, 45);
            this.btnAnalytics.TabIndex = 1;
            this.btnAnalytics.Text = "Analytics";
            this.btnAnalytics.UseVisualStyleBackColor = true;
            this.btnAnalytics.Click += new System.EventHandler(this.btnAnalytics_Click);
            // 
            // btnStockMangement
            // 
            this.btnStockMangement.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(180)))), ((int)(((byte)(100)))));
            this.btnStockMangement.FlatAppearance.BorderSize = 0;
            this.btnStockMangement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStockMangement.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStockMangement.Location = new System.Drawing.Point(35, 9);
            this.btnStockMangement.Name = "btnStockMangement";
            this.btnStockMangement.Size = new System.Drawing.Size(269, 45);
            this.btnStockMangement.TabIndex = 0;
            this.btnStockMangement.Text = "Stock Management";
            this.btnStockMangement.UseVisualStyleBackColor = false;
            this.btnStockMangement.Click += new System.EventHandler(this.btnStockMangement_Click);
            // 
            // pnlProductMangement
            // 
            this.pnlProductMangement.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlProductMangement.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(26)))), ((int)(((byte)(45)))));
            this.pnlProductMangement.Controls.Add(this.lblProductitem);
            this.pnlProductMangement.Controls.Add(this.lblCode);
            this.pnlProductMangement.Controls.Add(this.pnlHeaderLine);
            this.pnlProductMangement.Controls.Add(this.lblStatus);
            this.pnlProductMangement.Controls.Add(this.lblPrice);
            this.pnlProductMangement.Controls.Add(this.lblStock);
            this.pnlProductMangement.Controls.Add(this.pnlSystemControl);
            this.pnlProductMangement.Controls.Add(this.pnlSystemCtrl);
            this.pnlProductMangement.Controls.Add(this.flpProducts);
            this.pnlProductMangement.Location = new System.Drawing.Point(0, 333);
            this.pnlProductMangement.Name = "pnlProductMangement";
            this.pnlProductMangement.Size = new System.Drawing.Size(1804, 496);
            this.pnlProductMangement.TabIndex = 3;
            // 
            // lblProductitem
            // 
            this.lblProductitem.AutoSize = true;
            this.lblProductitem.BackColor = System.Drawing.Color.Transparent;
            this.lblProductitem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductitem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(177)))), ((int)(((byte)(244)))));
            this.lblProductitem.Location = new System.Drawing.Point(30, 19);
            this.lblProductitem.Name = "lblProductitem";
            this.lblProductitem.Size = new System.Drawing.Size(73, 23);
            this.lblProductitem.TabIndex = 11;
            this.lblProductitem.Text = "Product";
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.BackColor = System.Drawing.Color.Transparent;
            this.lblCode.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(177)))), ((int)(((byte)(244)))));
            this.lblCode.Location = new System.Drawing.Point(419, 11);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(56, 23);
            this.lblCode.TabIndex = 10;
            this.lblCode.Text = "CODE";
            // 
            // pnlHeaderLine
            // 
            this.pnlHeaderLine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlHeaderLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(65)))), ((int)(((byte)(90)))));
            this.pnlHeaderLine.Location = new System.Drawing.Point(15, 55);
            this.pnlHeaderLine.Name = "pnlHeaderLine";
            this.pnlHeaderLine.Size = new System.Drawing.Size(2174, 1);
            this.pnlHeaderLine.TabIndex = 5;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(177)))), ((int)(((byte)(224)))));
            this.lblStatus.Location = new System.Drawing.Point(1321, 12);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(72, 23);
            this.lblStatus.TabIndex = 4;
            this.lblStatus.Text = "STATUS";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.Transparent;
            this.lblPrice.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(177)))), ((int)(((byte)(224)))));
            this.lblPrice.Location = new System.Drawing.Point(1036, 11);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(56, 23);
            this.lblPrice.TabIndex = 3;
            this.lblPrice.Text = "PRICE";
            // 
            // lblStock
            // 
            this.lblStock.AutoSize = true;
            this.lblStock.BackColor = System.Drawing.Color.Transparent;
            this.lblStock.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStock.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(177)))), ((int)(((byte)(224)))));
            this.lblStock.Location = new System.Drawing.Point(741, 11);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(64, 23);
            this.lblStock.TabIndex = 2;
            this.lblStock.Text = "STOCK";
            // 
            // pnlSystemControl
            // 
            this.pnlSystemControl.AutoScroll = true;
            this.pnlSystemControl.AutoSize = true;
            this.pnlSystemControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(29)))), ((int)(((byte)(50)))));
            this.pnlSystemControl.Controls.Add(this.picExit);
            this.pnlSystemControl.Controls.Add(this.lblExit);
            this.pnlSystemControl.Controls.Add(this.lblReturnKiosk);
            this.pnlSystemControl.Controls.Add(this.lblRestartDescription);
            this.pnlSystemControl.Controls.Add(this.picRestart);
            this.pnlSystemControl.Controls.Add(this.lblPoweroff);
            this.pnlSystemControl.Controls.Add(this.lblShutdownSystem);
            this.pnlSystemControl.Controls.Add(this.pictureBox4);
            this.pnlSystemControl.Controls.Add(this.btnShutdownSystem);
            this.pnlSystemControl.Controls.Add(this.pnlSystemStatus);
            this.pnlSystemControl.Controls.Add(this.lblRestartSystem);
            this.pnlSystemControl.Controls.Add(this.lblProduct);
            this.pnlSystemControl.Controls.Add(this.btnRestartSystem);
            this.pnlSystemControl.Controls.Add(this.btnReturnKiosk);
            this.pnlSystemControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSystemControl.Location = new System.Drawing.Point(0, 0);
            this.pnlSystemControl.Name = "pnlSystemControl";
            this.pnlSystemControl.Size = new System.Drawing.Size(1804, 496);
            this.pnlSystemControl.TabIndex = 11;
            this.pnlSystemControl.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlSystemControl_Paint);
            // 
            // picExit
            // 
            this.picExit.Location = new System.Drawing.Point(29, 616);
            this.picExit.Name = "picExit";
            this.picExit.Size = new System.Drawing.Size(57, 50);
            this.picExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picExit.TabIndex = 20;
            this.picExit.TabStop = false;
            // 
            // lblExit
            // 
            this.lblExit.AutoSize = true;
            this.lblExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(55)))), ((int)(((byte)(50)))));
            this.lblExit.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExit.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.lblExit.Location = new System.Drawing.Point(151, 658);
            this.lblExit.Name = "lblExit";
            this.lblExit.Size = new System.Drawing.Size(461, 23);
            this.lblExit.TabIndex = 19;
            this.lblExit.Text = "Exit admin panel and return to the customer-facing screen.";
            // 
            // lblReturnKiosk
            // 
            this.lblReturnKiosk.AutoSize = true;
            this.lblReturnKiosk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(55)))), ((int)(((byte)(50)))));
            this.lblReturnKiosk.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturnKiosk.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(230)))), ((int)(((byte)(135)))));
            this.lblReturnKiosk.Location = new System.Drawing.Point(152, 616);
            this.lblReturnKiosk.Name = "lblReturnKiosk";
            this.lblReturnKiosk.Size = new System.Drawing.Size(248, 31);
            this.lblReturnKiosk.TabIndex = 18;
            this.lblReturnKiosk.Text = "Return to Kiosk Mode";
            // 
            // lblRestartDescription
            // 
            this.lblRestartDescription.AutoSize = true;
            this.lblRestartDescription.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.lblRestartDescription.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRestartDescription.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.lblRestartDescription.Location = new System.Drawing.Point(154, 394);
            this.lblRestartDescription.Name = "lblRestartDescription";
            this.lblRestartDescription.Size = new System.Drawing.Size(369, 23);
            this.lblRestartDescription.TabIndex = 16;
            this.lblRestartDescription.Text = "Restart the kiosk application. Takes ~3 seconds.";
            // 
            // picRestart
            // 
            this.picRestart.Location = new System.Drawing.Point(29, 367);
            this.picRestart.Name = "picRestart";
            this.picRestart.Size = new System.Drawing.Size(57, 50);
            this.picRestart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picRestart.TabIndex = 15;
            this.picRestart.TabStop = false;
            // 
            // lblPoweroff
            // 
            this.lblPoweroff.AutoSize = true;
            this.lblPoweroff.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(28)))), ((int)(((byte)(35)))));
            this.lblPoweroff.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPoweroff.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.lblPoweroff.Location = new System.Drawing.Point(151, 536);
            this.lblPoweroff.Name = "lblPoweroff";
            this.lblPoweroff.Size = new System.Drawing.Size(564, 23);
            this.lblPoweroff.TabIndex = 14;
            this.lblPoweroff.Text = "Power off the kiosk. Use \"Open System\" from shutdown screen to restart.";
            // 
            // lblShutdownSystem
            // 
            this.lblShutdownSystem.AutoSize = true;
            this.lblShutdownSystem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(28)))), ((int)(((byte)(35)))));
            this.lblShutdownSystem.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShutdownSystem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(75)))), ((int)(((byte)(85)))));
            this.lblShutdownSystem.Location = new System.Drawing.Point(149, 493);
            this.lblShutdownSystem.Name = "lblShutdownSystem";
            this.lblShutdownSystem.Size = new System.Drawing.Size(215, 31);
            this.lblShutdownSystem.TabIndex = 13;
            this.lblShutdownSystem.Text = "Shut Down System";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(29, 500);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(57, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            // 
            // btnShutdownSystem
            // 
            this.btnShutdownSystem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(28)))), ((int)(((byte)(35)))));
            this.btnShutdownSystem.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(45)))), ((int)(((byte)(55)))));
            this.btnShutdownSystem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShutdownSystem.ForeColor = System.Drawing.Color.White;
            this.btnShutdownSystem.Location = new System.Drawing.Point(13, 469);
            this.btnShutdownSystem.Name = "btnShutdownSystem";
            this.btnShutdownSystem.Size = new System.Drawing.Size(819, 101);
            this.btnShutdownSystem.TabIndex = 10;
            this.btnShutdownSystem.UseVisualStyleBackColor = false;
            this.btnShutdownSystem.Click += new System.EventHandler(this.btnShutdownSystem_Click);
            // 
            // pnlSystemStatus
            // 
            this.pnlSystemStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(49)))), ((int)(((byte)(76)))));
            this.pnlSystemStatus.Controls.Add(this.pnlCurrentTime);
            this.pnlSystemStatus.Controls.Add(this.pnlUptime);
            this.pnlSystemStatus.Controls.Add(this.lblKioskStatus);
            this.pnlSystemStatus.Controls.Add(this.lblStatusDot);
            this.pnlSystemStatus.Controls.Add(this.lblSystemStatus);
            this.pnlSystemStatus.Location = new System.Drawing.Point(16, -3);
            this.pnlSystemStatus.Name = "pnlSystemStatus";
            this.pnlSystemStatus.Size = new System.Drawing.Size(482, 210);
            this.pnlSystemStatus.TabIndex = 0;
            // 
            // pnlCurrentTime
            // 
            this.pnlCurrentTime.Controls.Add(this.lblCurrentTime);
            this.pnlCurrentTime.Controls.Add(this.lblCurrentTimeTitle);
            this.pnlCurrentTime.Location = new System.Drawing.Point(267, 106);
            this.pnlCurrentTime.Name = "pnlCurrentTime";
            this.pnlCurrentTime.Size = new System.Drawing.Size(208, 98);
            this.pnlCurrentTime.TabIndex = 5;
            // 
            // lblCurrentTime
            // 
            this.lblCurrentTime.AutoSize = true;
            this.lblCurrentTime.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentTime.ForeColor = System.Drawing.Color.White;
            this.lblCurrentTime.Location = new System.Drawing.Point(22, 53);
            this.lblCurrentTime.Name = "lblCurrentTime";
            this.lblCurrentTime.Size = new System.Drawing.Size(94, 28);
            this.lblCurrentTime.TabIndex = 1;
            this.lblCurrentTime.Text = "00:00:00";
            // 
            // lblCurrentTimeTitle
            // 
            this.lblCurrentTimeTitle.AutoSize = true;
            this.lblCurrentTimeTitle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentTimeTitle.ForeColor = System.Drawing.Color.Gray;
            this.lblCurrentTimeTitle.Location = new System.Drawing.Point(23, 14);
            this.lblCurrentTimeTitle.Name = "lblCurrentTimeTitle";
            this.lblCurrentTimeTitle.Size = new System.Drawing.Size(94, 20);
            this.lblCurrentTimeTitle.TabIndex = 0;
            this.lblCurrentTimeTitle.Text = "Current Time";
            // 
            // pnlUptime
            // 
            this.pnlUptime.Controls.Add(this.lblUptime);
            this.pnlUptime.Controls.Add(this.lblUptimeTitle);
            this.pnlUptime.Location = new System.Drawing.Point(9, 108);
            this.pnlUptime.Name = "pnlUptime";
            this.pnlUptime.Size = new System.Drawing.Size(220, 96);
            this.pnlUptime.TabIndex = 4;
            // 
            // lblUptime
            // 
            this.lblUptime.AutoSize = true;
            this.lblUptime.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUptime.ForeColor = System.Drawing.Color.White;
            this.lblUptime.Location = new System.Drawing.Point(16, 44);
            this.lblUptime.Name = "lblUptime";
            this.lblUptime.Size = new System.Drawing.Size(84, 28);
            this.lblUptime.TabIndex = 4;
            this.lblUptime.Text = "0h 00m";
            // 
            // lblUptimeTitle
            // 
            this.lblUptimeTitle.AutoSize = true;
            this.lblUptimeTitle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUptimeTitle.ForeColor = System.Drawing.Color.Gray;
            this.lblUptimeTitle.Location = new System.Drawing.Point(17, 12);
            this.lblUptimeTitle.Name = "lblUptimeTitle";
            this.lblUptimeTitle.Size = new System.Drawing.Size(58, 20);
            this.lblUptimeTitle.TabIndex = 3;
            this.lblUptimeTitle.Text = "Uptime";
            // 
            // lblKioskStatus
            // 
            this.lblKioskStatus.AutoSize = true;
            this.lblKioskStatus.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKioskStatus.ForeColor = System.Drawing.Color.White;
            this.lblKioskStatus.Location = new System.Drawing.Point(32, 69);
            this.lblKioskStatus.Name = "lblKioskStatus";
            this.lblKioskStatus.Size = new System.Drawing.Size(211, 25);
            this.lblKioskStatus.TabIndex = 2;
            this.lblKioskStatus.Text = "Kiosk is running normally";
            // 
            // lblStatusDot
            // 
            this.lblStatusDot.AutoSize = true;
            this.lblStatusDot.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatusDot.ForeColor = System.Drawing.Color.Lime;
            this.lblStatusDot.Location = new System.Drawing.Point(4, 42);
            this.lblStatusDot.Name = "lblStatusDot";
            this.lblStatusDot.Size = new System.Drawing.Size(32, 54);
            this.lblStatusDot.TabIndex = 1;
            this.lblStatusDot.Text = ".";
            // 
            // lblSystemStatus
            // 
            this.lblSystemStatus.AutoSize = true;
            this.lblSystemStatus.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSystemStatus.ForeColor = System.Drawing.Color.White;
            this.lblSystemStatus.Location = new System.Drawing.Point(3, 9);
            this.lblSystemStatus.Name = "lblSystemStatus";
            this.lblSystemStatus.Size = new System.Drawing.Size(162, 31);
            this.lblSystemStatus.TabIndex = 0;
            this.lblSystemStatus.Text = "System Status";
            // 
            // lblRestartSystem
            // 
            this.lblRestartSystem.AutoSize = true;
            this.lblRestartSystem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.lblRestartSystem.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRestartSystem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(190)))), ((int)(((byte)(0)))));
            this.lblRestartSystem.Location = new System.Drawing.Point(152, 356);
            this.lblRestartSystem.Name = "lblRestartSystem";
            this.lblRestartSystem.Size = new System.Drawing.Size(172, 31);
            this.lblRestartSystem.TabIndex = 2;
            this.lblRestartSystem.Text = "Restart System";
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.BackColor = System.Drawing.Color.Transparent;
            this.lblProduct.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(177)))), ((int)(((byte)(224)))));
            this.lblProduct.Location = new System.Drawing.Point(14, 12);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(90, 23);
            this.lblProduct.TabIndex = 9;
            this.lblProduct.Text = "PRODUCT";
            // 
            // btnRestartSystem
            // 
            this.btnRestartSystem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.btnRestartSystem.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(78)))), ((int)(((byte)(15)))));
            this.btnRestartSystem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRestartSystem.ForeColor = System.Drawing.Color.White;
            this.btnRestartSystem.Location = new System.Drawing.Point(16, 342);
            this.btnRestartSystem.Name = "btnRestartSystem";
            this.btnRestartSystem.Size = new System.Drawing.Size(816, 96);
            this.btnRestartSystem.TabIndex = 1;
            this.btnRestartSystem.UseVisualStyleBackColor = false;
            this.btnRestartSystem.Click += new System.EventHandler(this.btnRestartSystem_Click);
            // 
            // btnReturnKiosk
            // 
            this.btnReturnKiosk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(55)))), ((int)(((byte)(50)))));
            this.btnReturnKiosk.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(75)))));
            this.btnReturnKiosk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReturnKiosk.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturnKiosk.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(230)))), ((int)(((byte)(135)))));
            this.btnReturnKiosk.Location = new System.Drawing.Point(13, 591);
            this.btnReturnKiosk.Name = "btnReturnKiosk";
            this.btnReturnKiosk.Size = new System.Drawing.Size(811, 111);
            this.btnReturnKiosk.TabIndex = 11;
            this.btnReturnKiosk.UseVisualStyleBackColor = false;
            this.btnReturnKiosk.Click += new System.EventHandler(this.btnReturnKiosk_Click);
            // 
            // pnlSystemCtrl
            // 
            this.pnlSystemCtrl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlSystemCtrl.AutoScroll = true;
            this.pnlSystemCtrl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(25)))), ((int)(((byte)(45)))));
            this.pnlSystemCtrl.Location = new System.Drawing.Point(1, 0);
            this.pnlSystemCtrl.Name = "pnlSystemCtrl";
            this.pnlSystemCtrl.Size = new System.Drawing.Size(1811, 437);
            this.pnlSystemCtrl.TabIndex = 0;
            // 
            // flpProducts
            // 
            this.flpProducts.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpProducts.AutoScroll = true;
            this.flpProducts.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpProducts.Location = new System.Drawing.Point(14, 64);
            this.flpProducts.Name = "flpProducts";
            this.flpProducts.Size = new System.Drawing.Size(1787, 331);
            this.flpProducts.TabIndex = 8;
            this.flpProducts.WrapContents = false;
            // 
            // timerClock
            // 
            this.timerClock.Enabled = true;
            this.timerClock.Interval = 1000;
            this.timerClock.Tick += new System.EventHandler(this.timerClock_Tick);
            // 
            // frmAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(25)))), ((int)(((byte)(45)))));
            this.ClientSize = new System.Drawing.Size(1812, 772);
            this.Controls.Add(this.pnlProductMangement);
            this.Controls.Add(this.pnlMenu);
            this.Controls.Add(this.pnlSummary);
            this.Controls.Add(this.pnlHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.pnlSummary.ResumeLayout(false);
            this.pnlOutOfStock.ResumeLayout(false);
            this.pnlOutOfStock.PerformLayout();
            this.pnlProductsList.ResumeLayout(false);
            this.pnlProductsList.PerformLayout();
            this.pnlRevenue.ResumeLayout(false);
            this.pnlRevenue.PerformLayout();
            this.pnlTransactions.ResumeLayout(false);
            this.pnlTransactions.PerformLayout();
            this.pnlMenu.ResumeLayout(false);
            this.pnlProductMangement.ResumeLayout(false);
            this.pnlProductMangement.PerformLayout();
            this.pnlSystemControl.ResumeLayout(false);
            this.pnlSystemControl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRestart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.pnlSystemStatus.ResumeLayout(false);
            this.pnlSystemStatus.PerformLayout();
            this.pnlCurrentTime.ResumeLayout(false);
            this.pnlCurrentTime.PerformLayout();
            this.pnlUptime.ResumeLayout(false);
            this.pnlUptime.PerformLayout();
            this.flpProducts.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblAdminTttle;
        private System.Windows.Forms.Label lblDateTime;
        private System.Windows.Forms.Button btnExitAdmin;
        private System.Windows.Forms.Label lblSystemOnline;
        private System.Windows.Forms.Label lblAdminIcon;
        private System.Windows.Forms.Panel pnlSummary;
        private System.Windows.Forms.Panel pnlTransactions;
        private System.Windows.Forms.Label lblTransactionTittle;
        private System.Windows.Forms.Label lblTransactionValue;
        private System.Windows.Forms.Panel pnlRevenue;
        private System.Windows.Forms.Label lblRevenueValue;
        private System.Windows.Forms.Label lblRevenue;
        private System.Windows.Forms.Panel pnlOutOfStock;
        private System.Windows.Forms.Label lblOutStockValue;
        private System.Windows.Forms.Label lblOutofStock;
        private System.Windows.Forms.Panel pnlProductsList;
        private System.Windows.Forms.Label lblProductValue;
        private System.Windows.Forms.Label lblProductListed;
        private System.Windows.Forms.Panel pnlMenu;
        private System.Windows.Forms.Button btnSystemControl;
        private System.Windows.Forms.Button btnAnalytics;
        private System.Windows.Forms.Button btnStockMangement;
        private System.Windows.Forms.Panel pnlProductMangement;
        private System.Windows.Forms.Label lblStock;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Panel pnlHeaderLine;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.FlowLayoutPanel flpProducts;
        private System.Windows.Forms.Label lblCode;
        private System.Windows.Forms.Panel pnlSystemControl;
        private System.Windows.Forms.Panel pnlSystemStatus;
        private System.Windows.Forms.Label lblSystemStatus;
        private System.Windows.Forms.Label lblKioskStatus;
        private System.Windows.Forms.Label lblStatusDot;
        private System.Windows.Forms.Panel pnlUptime;
        private System.Windows.Forms.Label lblUptimeTitle;
        private System.Windows.Forms.Panel pnlCurrentTime;
        private System.Windows.Forms.Label lblUptime;
        private System.Windows.Forms.Label lblCurrentTime;
        private System.Windows.Forms.Label lblCurrentTimeTitle;
        private System.Windows.Forms.Timer timerClock;
        private System.Windows.Forms.Button btnRestartSystem;
        private System.Windows.Forms.Label lblRestartSystem;
        private System.Windows.Forms.Button btnReturnKiosk;
        private System.Windows.Forms.Button btnShutdownSystem;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label lblPoweroff;
        private System.Windows.Forms.Label lblShutdownSystem;
        private System.Windows.Forms.PictureBox picRestart;
        private System.Windows.Forms.Label lblRestartDescription;
        private System.Windows.Forms.Label lblReturnKiosk;
        private System.Windows.Forms.Label lblExit;
        private System.Windows.Forms.PictureBox picExit;
        private System.Windows.Forms.Label lblProductitem;
        private System.Windows.Forms.Panel pnlSystemCtrl;
    }
}

