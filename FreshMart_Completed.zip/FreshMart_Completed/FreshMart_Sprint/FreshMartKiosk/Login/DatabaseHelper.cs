using System;
using System.Data.Common;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;
using FreshMartKiosk;

namespace FreshmartAdminLogIn
{
    /// <summary>
    /// Admin logins, stored in the Users table of the SQLite database.
    ///
    /// Passwords are NEVER saved as plain text. Each user has a random salt and
    /// hash = PBKDF2(password, salt, 10 000 rounds). To check a login we hash what
    /// was typed with the same salt and compare the two hashes.
    ///
    /// Default account: Admin / 12345
    /// </summary>
    public static class DatabaseHelper
    {
        private const int SaltBytes = 16;
        private const int HashBytes = 32;
        private const int Iterations = 10000;
        private const int AdminCredentialsMigrationVersion = 1;
        private const string DefaultAdminUsername = "Admin";
        private const string DefaultAdminPassword = "12345";

        /// <summary>Plain-text file from the very first version (next to the .exe).</summary>
        private static string LegacyPlainFile => Path.Combine(Application.StartupPath, "FreshMartDataBase.txt");

        /// <summary>Hashed file from the text-file version (username|salt|hash).</summary>
        private static string LegacyHashedFile => Path.Combine(Database.DataFolder, "users.txt");

        /// <summary>Creates the database and makes sure at least one admin account exists.</summary>
        public static void EnsureDatabaseExists()
        {
            bool usersExisted;
            using (DbConnection connection = Database.Open())
            {
                using (DbTransaction transaction = connection.BeginTransaction())
                {
                    usersExisted = Database.ScalarLong(connection, transaction, "SELECT COUNT(*) FROM Users") > 0;
                    if (!usersExisted)
                    {
                        // Bring across accounts from the older versions, if there are any.
                        foreach (string[] parts in Database.ReadLegacyUserLines(LegacyHashedFile))
                            if (parts.Length == 3 && parts[0].Trim().Length > 0)
                                InsertUser(connection, transaction, parts[0].Trim(), parts[1], parts[2]);

                        foreach (string[] parts in Database.ReadLegacyUserLines(LegacyPlainFile))
                            if (parts.Length == 2 && parts[0].Trim().Length > 0)
                                InsertUser(connection, transaction, parts[0].Trim(), parts[1]);

                        if (Database.ScalarLong(connection, transaction, "SELECT COUNT(*) FROM Users") == 0)
                            InsertUser(connection, transaction, DefaultAdminUsername, DefaultAdminPassword);
                    }

                    if (Database.ScalarLong(connection, transaction, "PRAGMA user_version") < AdminCredentialsMigrationVersion)
                    {
                        byte[] salt = NewSalt();
                        int updated = Database.Execute(connection, transaction,
                            "UPDATE Users SET Username = @user, PasswordSalt = @salt, PasswordHash = @hash WHERE Username = @user",
                            "@user", DefaultAdminUsername,
                            "@salt", Convert.ToBase64String(salt),
                            "@hash", HashPassword(DefaultAdminPassword, salt));

                        if (updated == 0)
                            InsertUser(connection, transaction, DefaultAdminUsername, DefaultAdminPassword);

                        Database.Execute(connection, transaction, "PRAGMA user_version = " + AdminCredentialsMigrationVersion);
                    }

                    transaction.Commit();
                }
            }

            if (!usersExisted && File.Exists(LegacyHashedFile))
                File.Move(LegacyHashedFile, LegacyHashedFile + ".imported");
        }

        public static bool CheckLogin(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || password == null) return false;

            using (DbConnection connection = Database.Open())
            using (DbCommand command = Database.Command(connection, null,
                "SELECT PasswordSalt, PasswordHash FROM Users WHERE Username = @user", "@user", username.Trim()))
            using (DbDataReader reader = command.ExecuteReader())
            {
                if (!reader.Read()) return false;

                byte[] salt;
                try { salt = Convert.FromBase64String(reader.GetString(0)); }
                catch (FormatException) { return false; }

                return SlowEquals(HashPassword(password, salt), reader.GetString(1));
            }
        }

        public static bool UsernameExists(string username)
        {
            using (DbConnection connection = Database.Open())
                return Database.ScalarLong(connection, null,
                    "SELECT COUNT(*) FROM Users WHERE Username = @user", "@user", username.Trim()) > 0;
        }

        /// <summary>Changes the password of an EXISTING user. Returns false if there is no such user.</summary>
        public static bool UpdatePassword(string username, string newPassword)
        {
            byte[] salt = NewSalt();

            using (DbConnection connection = Database.Open())
            {
                int updated = Database.Execute(connection, null,
                    "UPDATE Users SET PasswordSalt = @salt, PasswordHash = @hash WHERE Username = @user",
                    "@salt", Convert.ToBase64String(salt),
                    "@hash", HashPassword(newPassword, salt),
                    "@user", username.Trim());
                return updated == 1;
            }
        }

        // ------------------------------------------------------------------

        private static void InsertUser(DbConnection connection, DbTransaction transaction, string username, string password)
        {
            byte[] salt = NewSalt();
            InsertUser(connection, transaction, username, Convert.ToBase64String(salt), HashPassword(password, salt));
        }

        private static void InsertUser(DbConnection connection, DbTransaction transaction, string username, string salt, string hash)
        {
            Database.Execute(connection, transaction,
                "INSERT OR IGNORE INTO Users (Username, PasswordSalt, PasswordHash) VALUES (@user, @salt, @hash)",
                "@user", username, "@salt", salt, "@hash", hash);
        }

        private static byte[] NewSalt()
        {
            byte[] salt = new byte[SaltBytes];
            using (var rng = RandomNumberGenerator.Create())
                rng.GetBytes(salt);
            return salt;
        }

        private static string HashPassword(string password, byte[] salt)
        {
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, Iterations))
                return Convert.ToBase64String(pbkdf2.GetBytes(HashBytes));
        }

        /// <summary>Compares every character so the time taken doesn't reveal how much matched.</summary>
        private static bool SlowEquals(string a, string b)
        {
            int diff = a.Length ^ b.Length;
            for (int i = 0; i < a.Length && i < b.Length; i++)
                diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }
}
