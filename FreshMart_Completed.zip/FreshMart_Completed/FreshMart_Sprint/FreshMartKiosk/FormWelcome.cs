﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;
using FreshMartKiosk.CustomerAuth;

namespace FreshMartKiosk
{
    /// <summary>
    /// Customer-facing start screen. This is the application's MAIN form:
    /// every other screen is opened from here and hands control back here when it closes.
    /// </summary>
    public partial class FormWelcome : Form
    {
        private Timer clockTimer;
        private Timer bannerTimer;
        private Panel headerPanel;
        private Label clockLabel;
        private Label dateLabel;
        private PictureBox bannerPicture;
        private Label highlightTag;
        private Label headlineLabel;
        private Label subtextLabel;
        private Label dotsLabel;
        private Button startButton;
        private Label adminAccessLabel;

        private Image[] bannerImages;
        private readonly string[] bannerHeadlines = { "Farm-Fresh Produce", "Weekend Specials", "Butchery && Seafood", "Premium Bakery" };
        private readonly string[] bannerSubtext =
        {
            "Delivered daily from local farms",
            "Up to 40% off selected items this weekend only",
            "Hand-selected premium cuts and fresh catch",
            "Freshly baked breads & pastries from 6AM"
        };
        private int currentBanner = 0;

        public FormWelcome()
        {
            InitializeComponent();

            SetupHeader();
            LoadBannerImages();
            SetupBanner();

            Resize += (s, e) => LayoutControls();
            LayoutControls();

            // Small "?" help button, available on every screen.
            HelpAssistant.Attach(this, HelpKnowledge.GettingStarted);
        }

        // ------------------------------------------------------------------
        // Header (logo + live clock)
        // ------------------------------------------------------------------

        private void SetupHeader()
        {
            headerPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 90,
                BackColor = Color.FromArgb(20, 20, 20)
            };
            Controls.Add(headerPanel);

            headerPanel.Controls.Add(new Label
            {
                Text = "F",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(46, 175, 84),
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(46, 46),
                Location = new Point(24, 22)
            });

            headerPanel.Controls.Add(new Label
            {
                Text = "FreshMart Supermarket",
                Font = new Font("Segoe UI", 13, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(84, 18)
            });

            headerPanel.Controls.Add(new Label
            {
                Text = "Self-Service Kiosk",
                Font = new Font("Segoe UI", 9.5f),
                ForeColor = Color.Gainsboro,
                AutoSize = true,
                Location = new Point(84, 44)
            });

            clockLabel = new Label
            {
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Top = 16
            };
            headerPanel.Controls.Add(clockLabel);

            dateLabel = new Label
            {
                Font = new Font("Segoe UI", 9.5f),
                ForeColor = Color.Gainsboro,
                AutoSize = true,
                Top = 50
            };
            headerPanel.Controls.Add(dateLabel);

            headerPanel.Resize += (s, e) => PositionClock();

            clockTimer = new Timer { Interval = 1000 };
            clockTimer.Tick += (s, e) => UpdateClock();
            clockTimer.Start();
            UpdateClock();
        }

        private void UpdateClock()
        {
            clockLabel.Text = DateTime.Now.ToString("hh:mm:ss tt");
            dateLabel.Text = DateTime.Now.ToString("dddd, MMMM d, yyyy");
            PositionClock();
        }

        /// <summary>Keeps the clock right-aligned on any screen width.</summary>
        private void PositionClock()
        {
            if (clockLabel == null) return;
            clockLabel.Left = headerPanel.ClientSize.Width - clockLabel.Width - 24;
            dateLabel.Left = headerPanel.ClientSize.Width - dateLabel.Width - 24;
        }

        // ------------------------------------------------------------------
        // Rotating banner
        // ------------------------------------------------------------------

        private void LoadBannerImages()
        {
            string[] fileNames = { "produce.jpg", "specials.jpg", "butcher.jpg", "bakery.jpg" };
            bannerImages = new Image[fileNames.Length];

            for (int i = 0; i < fileNames.Length; i++)
            {
                string path = Path.Combine(Application.StartupPath, "Images", fileNames[i]);
                if (!File.Exists(path)) continue;

                try
                {
                    // Copy into memory so the .jpg file is not locked while the app runs.
                    using (var fromDisk = new Bitmap(path))
                        bannerImages[i] = new Bitmap(fromDisk);
                }
                catch (ArgumentException) { /* not a valid image - skip it */ }
            }
        }

        private void SetupBanner()
        {
            bannerPicture = new PictureBox
            {
                Dock = DockStyle.Fill,
                SizeMode = PictureBoxSizeMode.StretchImage,
                BackColor = Color.FromArgb(20, 40, 30)
            };
            bannerPicture.Paint += BannerPicture_Paint;
            Controls.Add(bannerPicture);
            bannerPicture.BringToFront();

            highlightTag = MakeBannerLabel(new Font("Segoe UI", 9, FontStyle.Bold), Color.White);
            highlightTag.Text = "TODAY'S HIGHLIGHT";
            headlineLabel = MakeBannerLabel(new Font("Segoe UI", 32, FontStyle.Bold), Color.White);
            subtextLabel = MakeBannerLabel(new Font("Segoe UI", 12), Color.Gainsboro);
            dotsLabel = MakeBannerLabel(new Font("Segoe UI", 12), Color.White);

            startButton = new Button
            {
                Text = "TAP TO SIGN IN & START SHOPPING",
                Font = new Font("Segoe UI", 13, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(46, 175, 84),
                FlatStyle = FlatStyle.Flat,
                Size = new Size(360, 55),
                Cursor = Cursors.Hand
            };
            startButton.FlatAppearance.BorderSize = 0;
            startButton.Click += StartButton_Click;
            bannerPicture.Controls.Add(startButton);

            adminAccessLabel = MakeBannerLabel(new Font("Segoe UI", 9.5f), Color.Gainsboro);
            adminAccessLabel.Text = "Admin Access";
            adminAccessLabel.Cursor = Cursors.Hand;
            adminAccessLabel.Click += AdminAccess_Click;

            ShowBanner(currentBanner);

            bannerTimer = new Timer { Interval = 4000 };
            bannerTimer.Tick += (s, e) =>
            {
                currentBanner = (currentBanner + 1) % bannerImages.Length;
                ShowBanner(currentBanner);
            };
            bannerTimer.Start();
        }

        private Label MakeBannerLabel(Font font, Color color)
        {
            var label = new Label
            {
                Font = font,
                ForeColor = color,
                AutoSize = true,
                BackColor = Color.Transparent
            };
            bannerPicture.Controls.Add(label);
            return label;
        }

        /// <summary>
        /// Positions everything relative to the banner's real size, so the layout
        /// works on any monitor (the old version used fixed pixel positions).
        /// </summary>
        private void LayoutControls()
        {
            if (bannerPicture == null) return;

            int w = bannerPicture.ClientSize.Width;
            int h = bannerPicture.ClientSize.Height;

            highlightTag.Location = new Point(60, h - 355);
            headlineLabel.Location = new Point(60, h - 330);
            subtextLabel.Location = new Point(60, h - 250);

            startButton.Location = new Point((w - startButton.Width) / 2, h - 150);
            dotsLabel.Location = new Point((w - dotsLabel.Width) / 2, h - 70);

            adminAccessLabel.Location = new Point(w - adminAccessLabel.Width - 24, h - adminAccessLabel.Height - 24);

            bannerPicture.Invalidate();
        }

        private void ShowBanner(int index)
        {
            bannerPicture.Image = bannerImages[index];
            headlineLabel.Text = bannerHeadlines[index];
            subtextLabel.Text = bannerSubtext[index];

            string dots = "";
            for (int i = 0; i < bannerImages.Length; i++)
                dots += (i == index) ? "● " : "○ ";
            dotsLabel.Text = dots.TrimEnd();

            LayoutControls();
        }

        private void BannerPicture_Paint(object sender, PaintEventArgs e)
        {
            int width = bannerPicture.Width;
            int height = bannerPicture.Height;
            if (width <= 0 || height <= 0) return;

            int bottomHeight = Math.Min(400, height);
            using (var bottomBrush = new LinearGradientBrush(
                new Point(0, height - bottomHeight - 1), new Point(0, height),
                Color.FromArgb(0, 0, 0, 0), Color.FromArgb(180, 0, 0, 0)))
            {
                e.Graphics.FillRectangle(bottomBrush, 0, height - bottomHeight, width, bottomHeight);
            }

            using (var topBrush = new LinearGradientBrush(
                new Point(0, 0), new Point(0, 151),
                Color.FromArgb(120, 0, 0, 0), Color.FromArgb(0, 0, 0, 0)))
            {
                e.Graphics.FillRectangle(topBrush, 0, 0, width, 150);
            }
        }

        // ------------------------------------------------------------------
        // Navigation
        // ------------------------------------------------------------------

        private void StartButton_Click(object sender, EventArgs e)
        {
            // Customer access is deliberately kept separate from Admin Access.
            // Sign-up/login uses the same SQLite database, but a dedicated CustomerAccounts table.
            CustomerSession.SignOut();
            using (var login = new CustomerLoginForm())
            {
                if (login.ShowDialog(this) != DialogResult.OK || !CustomerSession.IsSignedIn)
                    return;
            }

            var kioskForm = new FormKiosk();

            // However the shopping screen closes (checkout done, cancelled, or the X button),
            // the customer session ends and the welcome screen comes back.
            kioskForm.FormClosed += (s, args) =>
            {
                CustomerSession.SignOut();
                Show();
            };

            kioskForm.Show();
            Hide();
        }

        private void AdminAccess_Click(object sender, EventArgs e)
        {
            using (var login = new FreshmartAdminLogIn.frmFreshmartAdminLogin())
            {
                if (login.ShowDialog(this) != DialogResult.OK)
                    return;
            }

            Hide();
            using (var admin = new Admin.frmAdmin())
            {
                admin.ShowDialog();
            }
            Show();
        }

        private void FormWelcome_Load(object sender, EventArgs e)
        {
            LayoutControls();
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            clockTimer.Stop();
            bannerTimer.Stop();
            base.OnFormClosed(e);
        }
    }
}
