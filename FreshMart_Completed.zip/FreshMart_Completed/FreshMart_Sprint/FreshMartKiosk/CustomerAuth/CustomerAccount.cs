using System;

namespace FreshMartKiosk.CustomerAuth
{
    public sealed class CustomerAccount
    {
        public long CustomerId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Username { get; set; }
        public DateTime CreatedAt { get; set; }

        public string DisplayName
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(FullName))
                {
                    string[] parts = FullName.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length > 0) return parts[0];
                }
                return Username;
            }
        }
    }
}
