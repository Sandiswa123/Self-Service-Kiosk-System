namespace FreshMartKiosk.CustomerAuth
{
    public static class CustomerSession
    {
        public static CustomerAccount CurrentCustomer { get; private set; }

        public static bool IsSignedIn => CurrentCustomer != null;

        public static void SignIn(CustomerAccount customer)
        {
            CurrentCustomer = customer;
        }

        public static void SignOut()
        {
            CurrentCustomer = null;
        }
    }
}
