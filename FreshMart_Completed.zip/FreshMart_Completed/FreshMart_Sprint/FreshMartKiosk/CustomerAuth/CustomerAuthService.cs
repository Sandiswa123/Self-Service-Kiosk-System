using System;
using System.Data.Common;
using System.Net.Mail;
using System.Security.Cryptography;

namespace FreshMartKiosk.CustomerAuth
{
    public static class CustomerAuthService
    {
        private const int SaltBytes = 16;
        private const int HashBytes = 32;
        private const int Iterations = 10000;
        public const int MinPasswordLength = 6;

        public static bool TryCreateAccount(
            string fullName,
            string email,
            string username,
            string password,
            out CustomerAccount customer,
            out string errorMessage)
        {
            customer = null;
            errorMessage = null;

            fullName = (fullName ?? string.Empty).Trim();
            email = (email ?? string.Empty).Trim();
            username = (username ?? string.Empty).Trim();
            password = password ?? string.Empty;

            if (fullName.Length < 2)
            {
                errorMessage = "Please enter your full name.";
                return false;
            }

            if (!IsValidEmail(email))
            {
                errorMessage = "Please enter a valid email address.";
                return false;
            }

            if (username.Length < 3)
            {
                errorMessage = "Username must contain at least 3 characters.";
                return false;
            }

            if (username.Contains(" "))
            {
                errorMessage = "Username cannot contain spaces.";
                return false;
            }

            if (password.Length < MinPasswordLength)
            {
                errorMessage = "Password must contain at least " + MinPasswordLength + " characters.";
                return false;
            }

            using (DbConnection connection = Database.Open())
            {
                if (Database.ScalarLong(connection, null,
                    "SELECT COUNT(*) FROM CustomerAccounts WHERE Username = @username",
                    "@username", username) > 0)
                {
                    errorMessage = "That username is already in use. Please choose another one.";
                    return false;
                }

                if (Database.ScalarLong(connection, null,
                    "SELECT COUNT(*) FROM CustomerAccounts WHERE Email = @email",
                    "@email", email) > 0)
                {
                    errorMessage = "An account already exists for that email address.";
                    return false;
                }

                byte[] salt = NewSalt();
                string saltText = Convert.ToBase64String(salt);
                string hash = HashPassword(password, salt);
                string createdAt = DateTime.Now.ToString(Database.DateFormat, Database.Invariant);

                Database.Execute(connection, null,
                    @"INSERT INTO CustomerAccounts
                      (FullName, Email, Username, PasswordSalt, PasswordHash, CreatedAt)
                      VALUES (@name, @email, @username, @salt, @hash, @createdAt)",
                    "@name", fullName,
                    "@email", email,
                    "@username", username,
                    "@salt", saltText,
                    "@hash", hash,
                    "@createdAt", createdAt);

                long id = Database.ScalarLong(connection, null, "SELECT last_insert_rowid()");
                customer = new CustomerAccount
                {
                    CustomerId = id,
                    FullName = fullName,
                    Email = email,
                    Username = username,
                    CreatedAt = DateTime.Now
                };
                return true;
            }
        }

        public static CustomerAccount Authenticate(string usernameOrEmail, string password)
        {
            usernameOrEmail = (usernameOrEmail ?? string.Empty).Trim();
            password = password ?? string.Empty;
            if (usernameOrEmail.Length == 0 || password.Length == 0) return null;

            using (DbConnection connection = Database.Open())
            using (DbCommand command = Database.Command(connection, null,
                @"SELECT CustomerId, FullName, Email, Username, PasswordSalt, PasswordHash, CreatedAt
                  FROM CustomerAccounts
                  WHERE Username = @login OR Email = @login
                  LIMIT 1",
                "@login", usernameOrEmail))
            using (DbDataReader reader = command.ExecuteReader())
            {
                if (!reader.Read()) return null;

                byte[] salt;
                try { salt = Convert.FromBase64String(reader.GetString(4)); }
                catch (FormatException) { return null; }

                if (!SlowEquals(HashPassword(password, salt), reader.GetString(5)))
                    return null;

                DateTime createdAt;
                if (!DateTime.TryParseExact(reader.GetString(6), Database.DateFormat, Database.Invariant,
                    System.Globalization.DateTimeStyles.None, out createdAt))
                    createdAt = DateTime.Now;

                var customer = new CustomerAccount
                {
                    CustomerId = Convert.ToInt64(reader.GetValue(0), Database.Invariant),
                    FullName = reader.GetString(1),
                    Email = reader.GetString(2),
                    Username = reader.GetString(3),
                    CreatedAt = createdAt
                };

                reader.Close();
                Database.Execute(connection, null,
                    "UPDATE CustomerAccounts SET LastLoginAt = @time WHERE CustomerId = @id",
                    "@time", DateTime.Now.ToString(Database.DateFormat, Database.Invariant),
                    "@id", customer.CustomerId);

                return customer;
            }
        }

        private static bool IsValidEmail(string email)
        {
            try
            {
                var parsed = new MailAddress(email);
                return string.Equals(parsed.Address, email, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        private static byte[] NewSalt()
        {
            byte[] salt = new byte[SaltBytes];
            using (var rng = RandomNumberGenerator.Create())
                rng.GetBytes(salt);
            return salt;
        }

        private static string HashPassword(string password, byte[] salt)
        {
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, Iterations))
                return Convert.ToBase64String(pbkdf2.GetBytes(HashBytes));
        }

        private static bool SlowEquals(string a, string b)
        {
            if (a == null || b == null) return false;
            int diff = a.Length ^ b.Length;
            for (int i = 0; i < a.Length && i < b.Length; i++)
                diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }
}
