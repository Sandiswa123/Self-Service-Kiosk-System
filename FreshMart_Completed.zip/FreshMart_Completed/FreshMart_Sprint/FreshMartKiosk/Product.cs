namespace FreshMartKiosk
{
    public class Product
    {
        public string ProductId { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public string Category { get; set; }
        public string Barcode { get; set; }
        public int Stock { get; set; }

        /// <summary>False when Admin has switched the product off.</summary>
        public bool IsAvailable { get; set; } = true;

        /// <summary>A product can only be sold if Admin allows it AND there is stock.</summary>
        public bool CanBeSold => IsAvailable && Stock > 0;
    }
}
