using System.Collections.Generic;
using System.Linq;

namespace FreshMartKiosk
{
    public enum AddResult
    {
        Added,
        NotFound,
        Unavailable,
        CartFull,
        NotEnoughStock
    }

    public class ShoppingCart
    {
        public const int MaxItems = 10;
        public const decimal VatRate = 0.15m;

        public List<CartItem> Items { get; } = new List<CartItem>();

        /// <summary>Products (with current stock/availability) loaded from the database.</summary>
        public List<Product> Catalog { get; private set; } = DataStore.LoadCatalog();

        /// <summary>Re-reads stock and availability changes made in Admin.</summary>
        public void LoadProductAvailability()
        {
            Catalog = DataStore.LoadCatalog();
        }

        public int ItemCount => Items.Sum(i => i.Quantity);

        public Product FindProductByBarcode(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return null;

            string c = code.Trim();
            return Catalog.FirstOrDefault(p =>
                string.Equals(p.Barcode, c, System.StringComparison.OrdinalIgnoreCase) ||
                string.Equals(p.ProductId, c, System.StringComparison.OrdinalIgnoreCase));
        }

        public AddResult AddProduct(Product product, int quantity = 1)
        {
            if (product == null) return AddResult.NotFound;
            if (!product.CanBeSold) return AddResult.Unavailable;
            if (ItemCount + quantity > MaxItems) return AddResult.CartFull;

            CartItem existing = Items.FirstOrDefault(i => i.Product.ProductId == product.ProductId);
            int alreadyInCart = existing?.Quantity ?? 0;

            if (alreadyInCart + quantity > product.Stock) return AddResult.NotEnoughStock;

            if (existing != null)
                existing.Quantity += quantity;
            else
                Items.Add(new CartItem { Product = product, Quantity = quantity });

            return AddResult.Added;
        }

        /// <summary>Removes ONE unit of a product (removes the line when it reaches 0).</summary>
        public void RemoveOne(string productId)
        {
            CartItem item = Items.FirstOrDefault(i => i.Product.ProductId == productId);
            if (item == null) return;

            item.Quantity--;
            if (item.Quantity <= 0) Items.Remove(item);
        }

        /// <summary>Removes the whole line for a product.</summary>
        public void RemoveProduct(string productId)
        {
            Items.RemoveAll(i => i.Product.ProductId == productId);
        }

        public void ClearCart()
        {
            Items.Clear();
        }

        public decimal CalculateSubtotal() => Items.Sum(i => i.TotalPrice);
        /// <summary>VAT rounded to the cent, exactly as it is saved in the database.</summary>
        public decimal CalculateVat() => System.Math.Round(CalculateSubtotal() * VatRate, 2, System.MidpointRounding.AwayFromZero);
        public decimal CalculateTotal() => CalculateSubtotal() + CalculateVat();
    }
}
